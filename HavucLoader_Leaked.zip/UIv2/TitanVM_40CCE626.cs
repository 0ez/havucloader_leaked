﻿using System;
using System.Collections;
using System.Reflection;
using System.Reflection.Emit;

// Token: 0x0200008E RID: 142
internal static class TitanVM_40CCE626
{
	// Token: 0x060001E4 RID: 484 RVA: 0x0000BAA4 File Offset: 0x00009CA4
	static TitanVM_40CCE626()
	{
		foreach (MethodInfo methodInfo in typeof(TitanVM).GetMethods(BindingFlags.Static | BindingFlags.NonPublic))
		{
			if (methodInfo.ReturnType != typeof(void) && methodInfo.GetParameters().Length > 4)
			{
				TitanVM_40CCE626.TitanVM_4B9833FC = methodInfo;
			}
			else
			{
				TitanVM_40CCE626.TitanVM_CB7BFF2B = methodInfo;
			}
		}
		TitanVM_40CCE626.TitanVM_2854B0D1 = (TitanVM_40CCE626.TitanVM_DA471095)Delegate.CreateDelegate(typeof(TitanVM_40CCE626.TitanVM_DA471095), typeof(DynamicMethod).GetMethod("GetMethodDescriptor", BindingFlags.Instance | BindingFlags.NonPublic));
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x0000BB3C File Offset: 0x00009D3C
	public static IntPtr TitanVM_A43FC74D(Module A_0, ulong A_1, uint A_2, TitanVM_4B300368 A_3, uint A_4)
	{
		object obj = TitanVM_40CCE626.TitanVM_E4990A8E[A_1];
		if (obj != null)
		{
			return TitanVM_40CCE626.TitanVM_2854B0D1((DynamicMethod)obj).GetFunctionPointer();
		}
		Hashtable titanVM_E4990A8E = TitanVM_40CCE626.TitanVM_E4990A8E;
		IntPtr functionPointer;
		lock (titanVM_E4990A8E)
		{
			obj = (DynamicMethod)TitanVM_40CCE626.TitanVM_E4990A8E[A_1];
			if (obj != null)
			{
				functionPointer = TitanVM_40CCE626.TitanVM_2854B0D1((DynamicMethod)obj).GetFunctionPointer();
			}
			else
			{
				if (TitanVM_40CCE626.TitanVM_7399C048(A_3))
				{
					obj = TitanVM_40CCE626.TitanVM_60A9F8BA(TitanVM_CD86A4D4.TitanVM_72CF2926(A_0), A_1, A_2, A_3, A_4);
				}
				else
				{
					obj = TitanVM_40CCE626.TitanVM_24E26707(TitanVM_CD86A4D4.TitanVM_72CF2926(A_0), A_1, A_2, A_3, A_4);
				}
				TitanVM_40CCE626.TitanVM_E4990A8E[A_1] = obj;
				functionPointer = TitanVM_40CCE626.TitanVM_2854B0D1((DynamicMethod)obj).GetFunctionPointer();
			}
		}
		return functionPointer;
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x0000BC28 File Offset: 0x00009E28
	private static bool TitanVM_7399C048(TitanVM_4B300368 A_0)
	{
		Type[] array = A_0.TitanVM_84628FA7();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].IsByRef)
			{
				return true;
			}
		}
		return A_0.TitanVM_41FBC8DA().IsByRef;
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x0000BC64 File Offset: 0x00009E64
	private static DynamicMethod TitanVM_24E26707(int A_0, ulong A_1, uint A_2, TitanVM_4B300368 A_3, uint A_4)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", A_3.TitanVM_41FBC8DA(), A_3.TitanVM_84628FA7(), TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldc_I4, A_0);
		ilgenerator.Emit(OpCodes.Ldc_I8, (long)A_1);
		ilgenerator.Emit(OpCodes.Ldc_I4, (int)A_2);
		ilgenerator.Emit(OpCodes.Ldc_I4, (int)A_4);
		ilgenerator.Emit(OpCodes.Ldc_I4, A_3.TitanVM_84628FA7().Length);
		ilgenerator.Emit(OpCodes.Newarr, typeof(object));
		for (int i = 0; i < A_3.TitanVM_84628FA7().Length; i++)
		{
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldc_I4, i);
			ilgenerator.Emit(OpCodes.Ldarg, i);
			if (A_3.TitanVM_84628FA7()[i].IsValueType)
			{
				ilgenerator.Emit(OpCodes.Box, A_3.TitanVM_84628FA7()[i]);
			}
			ilgenerator.Emit(OpCodes.Stelem_Ref);
		}
		ilgenerator.Emit(OpCodes.Call, TitanVM_40CCE626.TitanVM_4B9833FC);
		if (A_3.TitanVM_41FBC8DA() == typeof(void))
		{
			ilgenerator.Emit(OpCodes.Pop);
		}
		else if (A_3.TitanVM_41FBC8DA().IsValueType)
		{
			ilgenerator.Emit(OpCodes.Unbox_Any, A_3.TitanVM_41FBC8DA());
		}
		else
		{
			ilgenerator.Emit(OpCodes.Castclass, A_3.TitanVM_41FBC8DA());
		}
		ilgenerator.Emit(OpCodes.Ret);
		return dynamicMethod;
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x0000BDC0 File Offset: 0x00009FC0
	private unsafe static DynamicMethod TitanVM_60A9F8BA(int A_0, ulong A_1, uint A_2, TitanVM_4B300368 A_3, uint A_4)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", A_3.TitanVM_41FBC8DA(), A_3.TitanVM_84628FA7(), TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldc_I4, A_0);
		ilgenerator.Emit(OpCodes.Ldc_I8, (long)A_1);
		ilgenerator.Emit(OpCodes.Ldc_I4, (int)A_2);
		ilgenerator.Emit(OpCodes.Ldc_I4, (int)A_4);
		ilgenerator.Emit(OpCodes.Ldc_I4, A_3.TitanVM_84628FA7().Length);
		ilgenerator.Emit(OpCodes.Newarr, typeof(void*));
		for (int i = 0; i < A_3.TitanVM_84628FA7().Length; i++)
		{
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldc_I4, i);
			if (A_3.TitanVM_84628FA7()[i].IsByRef)
			{
				ilgenerator.Emit(OpCodes.Ldarg, i);
				ilgenerator.Emit(OpCodes.Mkrefany, A_3.TitanVM_84628FA7()[i].GetElementType());
			}
			else
			{
				ilgenerator.Emit(OpCodes.Ldarga, i);
				ilgenerator.Emit(OpCodes.Mkrefany, A_3.TitanVM_84628FA7()[i]);
			}
			LocalBuilder local = ilgenerator.DeclareLocal(typeof(TypedReference));
			ilgenerator.Emit(OpCodes.Stloc, local);
			ilgenerator.Emit(OpCodes.Ldloca, local);
			ilgenerator.Emit(OpCodes.Conv_I);
			ilgenerator.Emit(OpCodes.Stelem_I);
		}
		if (A_3.TitanVM_41FBC8DA() != typeof(void))
		{
			LocalBuilder local2 = ilgenerator.DeclareLocal(A_3.TitanVM_41FBC8DA());
			LocalBuilder local3 = ilgenerator.DeclareLocal(typeof(TypedReference));
			ilgenerator.Emit(OpCodes.Ldloca, local2);
			ilgenerator.Emit(OpCodes.Mkrefany, A_3.TitanVM_41FBC8DA());
			ilgenerator.Emit(OpCodes.Stloc, local3);
			ilgenerator.Emit(OpCodes.Ldloca, local3);
			ilgenerator.Emit(OpCodes.Call, TitanVM_40CCE626.TitanVM_CB7BFF2B);
			ilgenerator.Emit(OpCodes.Ldloc, local2);
		}
		else
		{
			ilgenerator.Emit(OpCodes.Ldnull);
			ilgenerator.Emit(OpCodes.Call, TitanVM_40CCE626.TitanVM_CB7BFF2B);
		}
		ilgenerator.Emit(OpCodes.Ret);
		return dynamicMethod;
	}

	// Token: 0x040000A9 RID: 169
	private static readonly TitanVM_40CCE626.TitanVM_DA471095 TitanVM_2854B0D1;

	// Token: 0x040000AA RID: 170
	private static readonly MethodInfo TitanVM_4B9833FC;

	// Token: 0x040000AB RID: 171
	private static readonly MethodInfo TitanVM_CB7BFF2B;

	// Token: 0x040000AC RID: 172
	private static readonly Hashtable TitanVM_E4990A8E = new Hashtable();

	// Token: 0x0200008F RID: 143
	// (Invoke) Token: 0x060001EA RID: 490
	private delegate RuntimeMethodHandle TitanVM_DA471095(DynamicMethod);
}
