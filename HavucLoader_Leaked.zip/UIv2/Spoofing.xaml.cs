﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace UIv2
{
	// Token: 0x02000009 RID: 9
	public partial class Spoofing : Window
	{
		// Token: 0x06000016 RID: 22 RVA: 0x00002210 File Offset: 0x00000410
		public Spoofing()
		{
			TitanVM.TitanVM(21, new object[]
			{
				this
			});
		}

		// Token: 0x04000037 RID: 55
		internal Image Image;

		// Token: 0x04000038 RID: 56
		internal TextBlock Lbael1;

		// Token: 0x04000039 RID: 57
		private bool _contentLoaded;
	}
}
