﻿using System;

// Token: 0x0200004D RID: 77
internal class TitanVM_1E64E5D5 : TitanVM_300B3806
{
	// Token: 0x060000F5 RID: 245 RVA: 0x000026A0 File Offset: 0x000008A0
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_E579FE7B;
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00007DE8 File Offset: 0x00005FE8
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		byte b = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		if (((int)b & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			titanVM_25A0D8C3.TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746() % titanVM_25A0D8C2.TitanVM_6702A746());
		}
		else
		{
			titanVM_25A0D8C3.TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746() % titanVM_25A0D8C2.TitanVM_6702A746());
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b2 = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_E316D143);
		TitanVM_54A70E05.TitanVM_80151D2(titanVM_25A0D8C.TitanVM_6702A746(), titanVM_25A0D8C2.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), ref b, b2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b);
		A_2 = (TitanVM_887DE97C)0;
	}
}
