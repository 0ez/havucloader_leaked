﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection.Emit;

// Token: 0x02000083 RID: 131
internal class TitanVM_EC931000
{
	// Token: 0x060001B4 RID: 436 RVA: 0x0000AA28 File Offset: 0x00008C28
	public static void TitanVM_95B551D0(Array A_0, int A_1, object A_2, Type A_3, Type A_4)
	{
		KeyValuePair<Type, Type> keyValuePair = new KeyValuePair<Type, Type>(A_3, A_4);
		object obj = TitanVM_EC931000.TitanVM_CE25B932[keyValuePair];
		if (obj == null)
		{
			Hashtable titanVM_CE25B = TitanVM_EC931000.TitanVM_CE25B932;
			lock (titanVM_CE25B)
			{
				obj = TitanVM_EC931000.TitanVM_CE25B932[keyValuePair];
				if (obj == null)
				{
					obj = TitanVM_EC931000.TitanVM_6846C35F(A_3, A_4);
					TitanVM_EC931000.TitanVM_CE25B932[keyValuePair] = obj;
				}
			}
		}
		((TitanVM_EC931000.TitanVM_D20546E9)obj)(A_0, A_1, A_2);
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x0000AAB4 File Offset: 0x00008CB4
	private static TitanVM_EC931000.TitanVM_D20546E9 TitanVM_6846C35F(Type A_0, Type A_1)
	{
		Type[] parameterTypes = new Type[]
		{
			typeof(Array),
			typeof(int),
			typeof(object)
		};
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), parameterTypes, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldarg_0);
		ilgenerator.Emit(OpCodes.Ldarg_1);
		ilgenerator.Emit(OpCodes.Ldarg_2);
		if (A_1.IsValueType)
		{
			ilgenerator.Emit(OpCodes.Unbox_Any, A_0);
		}
		ilgenerator.Emit(OpCodes.Stelem, A_1);
		ilgenerator.Emit(OpCodes.Ret);
		return (TitanVM_EC931000.TitanVM_D20546E9)dynamicMethod.CreateDelegate(typeof(TitanVM_EC931000.TitanVM_D20546E9));
	}

	// Token: 0x0400009B RID: 155
	private static Hashtable TitanVM_CE25B932 = new Hashtable();

	// Token: 0x02000084 RID: 132
	// (Invoke) Token: 0x060001B9 RID: 441
	private delegate void TitanVM_D20546E9(Array, int, object);
}
