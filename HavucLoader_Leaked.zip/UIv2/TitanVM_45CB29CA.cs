﻿using System;

// Token: 0x02000058 RID: 88
internal class TitanVM_45CB29CA : TitanVM_300B3806
{
	// Token: 0x06000116 RID: 278 RVA: 0x000026ED File Offset: 0x000008ED
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_D4DF825A;
	}

	// Token: 0x06000117 RID: 279 RVA: 0x00008618 File Offset: 0x00006818
	public unsafe void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C2;
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			titanVM_25A0D8C2 = ((TitanVM_22F736AB)titanVM_25A0D8C.TitanVM_AE0B16C2()).TitanVM_A47D84F5(A_1, TitanVM_57B74FAC.TitanVM_8248871B ? ((TitanVM_D977DC0E)3) : ((TitanVM_D977DC0E)2));
		}
		else if (TitanVM_57B74FAC.TitanVM_8248871B)
		{
			ulong* ptr = titanVM_25A0D8C.TitanVM_6702A746();
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_DC0D55ED(*ptr);
			titanVM_25A0D8C2 = titanVM_25A0D8C3;
		}
		else
		{
			uint* ptr2 = titanVM_25A0D8C.TitanVM_6702A746();
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_6DD70EA7(*ptr2);
			titanVM_25A0D8C2 = titanVM_25A0D8C3;
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
		A_2 = (TitanVM_887DE97C)0;
	}
}
