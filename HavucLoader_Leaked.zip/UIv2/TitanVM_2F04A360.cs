﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

// Token: 0x0200007B RID: 123
internal class TitanVM_2F04A360
{
	// Token: 0x06000192 RID: 402 RVA: 0x0000A1E4 File Offset: 0x000083E4
	public TitanVM_25A0D8C3 TitanVM_6D237F3F(uint A_1)
	{
		if (A_1 > this.TitanVM_E1D26F08)
		{
			return TitanVM_25A0D8C3.TitanVM_2090C8C5;
		}
		uint index = A_1 >> 6;
		return this.TitanVM_59F0410D[(int)index][(int)(A_1 & 63U)];
	}

	// Token: 0x06000193 RID: 403 RVA: 0x0000A21C File Offset: 0x0000841C
	public void TitanVM_59168392(uint A_1, TitanVM_25A0D8C3 A_2)
	{
		if (A_1 > this.TitanVM_E1D26F08)
		{
			return;
		}
		uint index = A_1 >> 6;
		this.TitanVM_59F0410D[(int)index][(int)(A_1 & 63U)] = A_2;
	}

	// Token: 0x06000194 RID: 404 RVA: 0x0000A250 File Offset: 0x00008450
	public void TitanVM_9441CDC9(uint A_1)
	{
		if (A_1 > 2147483647U)
		{
			throw new StackOverflowException();
		}
		uint num = A_1 >> 6;
		if ((ulong)num >= (ulong)((long)this.TitanVM_59F0410D.Count))
		{
			do
			{
				this.TitanVM_59F0410D.Add(new TitanVM_25A0D8C3[64]);
			}
			while ((ulong)num >= (ulong)((long)this.TitanVM_59F0410D.Count));
		}
		else if ((ulong)num < (ulong)((long)(this.TitanVM_59F0410D.Count - 2)))
		{
			do
			{
				this.TitanVM_59F0410D.RemoveAt(this.TitanVM_59F0410D.Count - 1);
			}
			while ((ulong)num < (ulong)((long)(this.TitanVM_59F0410D.Count - 2)));
		}
		uint num2 = (A_1 & 63U) + 1U;
		TitanVM_25A0D8C3[] array = this.TitanVM_59F0410D[(int)num];
		while ((ulong)num2 < (ulong)((long)array.Length) && array[(int)num2].TitanVM_AE0B16C2() != null)
		{
			array[(int)num2++] = TitanVM_25A0D8C3.TitanVM_2090C8C5;
		}
		if ((ulong)num2 == (ulong)((long)array.Length) && (ulong)(num + 1U) < (ulong)((long)this.TitanVM_59F0410D.Count))
		{
			num2 = 0U;
			array = this.TitanVM_59F0410D[(int)(num + 1U)];
			while ((ulong)num2 < (ulong)((long)array.Length) && array[(int)num2].TitanVM_AE0B16C2() != null)
			{
				array[(int)num2++] = TitanVM_25A0D8C3.TitanVM_2090C8C5;
			}
		}
		this.TitanVM_E1D26F08 = A_1;
		this.TitanVM_14657C94();
	}

	// Token: 0x06000195 RID: 405 RVA: 0x000029D1 File Offset: 0x00000BD1
	private void TitanVM_14657C94()
	{
		while (this.TitanVM_6423C6C7 != null && this.TitanVM_6423C6C7.TitanVM_38226EBC > this.TitanVM_E1D26F08)
		{
			this.TitanVM_6423C6C7 = this.TitanVM_6423C6C7.TitanVM_9AE5E691();
		}
	}

	// Token: 0x06000196 RID: 406 RVA: 0x0000A37C File Offset: 0x0000857C
	public IntPtr TitanVM_E2EEA198(uint A_1, uint A_2)
	{
		TitanVM_2F04A360.TitanVM_FCE2557A titanVM_FCE2557A = new TitanVM_2F04A360.TitanVM_FCE2557A
		{
			TitanVM_38226EBC = A_1,
			TitanVM_9EA97AEB = Marshal.AllocHGlobal((int)A_2)
		};
		TitanVM_2F04A360.TitanVM_FCE2557A titanVM_FCE2557A2 = this.TitanVM_6423C6C7;
		while (titanVM_FCE2557A2 != null && titanVM_FCE2557A2.TitanVM_D2F6D34E != null && titanVM_FCE2557A2.TitanVM_D2F6D34E.TitanVM_38226EBC >= A_1)
		{
			titanVM_FCE2557A2 = titanVM_FCE2557A2.TitanVM_D2F6D34E;
		}
		if (titanVM_FCE2557A2 == null)
		{
			this.TitanVM_6423C6C7 = titanVM_FCE2557A;
		}
		else
		{
			titanVM_FCE2557A.TitanVM_D2F6D34E = titanVM_FCE2557A2.TitanVM_D2F6D34E;
			titanVM_FCE2557A2.TitanVM_D2F6D34E = titanVM_FCE2557A;
		}
		return titanVM_FCE2557A.TitanVM_9EA97AEB;
	}

	// Token: 0x06000197 RID: 407 RVA: 0x0000A3F0 File Offset: 0x000085F0
	public void TitanVM_DFAD3EE3()
	{
		for (TitanVM_2F04A360.TitanVM_FCE2557A titanVM_FCE2557A = this.TitanVM_6423C6C7; titanVM_FCE2557A != null; titanVM_FCE2557A = titanVM_FCE2557A.TitanVM_9AE5E691())
		{
		}
		this.TitanVM_6423C6C7 = null;
	}

	// Token: 0x06000198 RID: 408 RVA: 0x0000A418 File Offset: 0x00008618
	protected virtual void TitanVM_C37496E6()
	{
		try
		{
			this.TitanVM_DFAD3EE3();
		}
		finally
		{
			base.Finalize();
		}
	}

	// Token: 0x06000199 RID: 409 RVA: 0x0000A444 File Offset: 0x00008644
	public void TitanVM_DAE9EB82(uint A_1, TitanVM_505B4619 A_2, Type A_3)
	{
		if (A_1 > this.TitanVM_E1D26F08)
		{
			throw new ExecutionEngineException();
		}
		TitanVM_25A0D8C3[] array = this.TitanVM_59F0410D[(int)(A_1 >> 6)];
		uint num = A_1 & 63U;
		if (A_3.IsEnum)
		{
			A_3 = Enum.GetUnderlyingType(A_3);
		}
		if (A_3.IsPrimitive || A_3.IsPointer)
		{
			array[(int)num].TitanVM_A876C9D3(A_2);
			TitanVM_934F86EE.TitanVM_9479A175(A_2, A_3);
			return;
		}
		array[(int)num].TitanVM_D47C4516(A_2, A_3);
	}

	// Token: 0x04000091 RID: 145
	private List<TitanVM_25A0D8C3[]> TitanVM_59F0410D = new List<TitanVM_25A0D8C3[]>();

	// Token: 0x04000092 RID: 146
	private uint TitanVM_E1D26F08;

	// Token: 0x04000093 RID: 147
	private TitanVM_2F04A360.TitanVM_FCE2557A TitanVM_6423C6C7;

	// Token: 0x0200007C RID: 124
	private class TitanVM_FCE2557A
	{
		// Token: 0x0600019B RID: 411 RVA: 0x0000A4B8 File Offset: 0x000086B8
		protected virtual void TitanVM_C37496E6()
		{
			try
			{
				if (this.TitanVM_9EA97AEB != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(this.TitanVM_9EA97AEB);
					this.TitanVM_9EA97AEB = IntPtr.Zero;
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x0600019C RID: 412 RVA: 0x00002A14 File Offset: 0x00000C14
		public TitanVM_2F04A360.TitanVM_FCE2557A TitanVM_9AE5E691()
		{
			if (this.TitanVM_9EA97AEB != IntPtr.Zero)
			{
				Marshal.FreeHGlobal(this.TitanVM_9EA97AEB);
				this.TitanVM_9EA97AEB = IntPtr.Zero;
			}
			return this.TitanVM_D2F6D34E;
		}

		// Token: 0x04000094 RID: 148
		public uint TitanVM_38226EBC;

		// Token: 0x04000095 RID: 149
		public IntPtr TitanVM_9EA97AEB;

		// Token: 0x04000096 RID: 150
		public TitanVM_2F04A360.TitanVM_FCE2557A TitanVM_D2F6D34E;
	}
}
