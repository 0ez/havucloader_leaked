﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace UIv2
{
	// Token: 0x0200000E RID: 14
	public partial class App : Application
	{
		// Token: 0x06000026 RID: 38 RVA: 0x00002361 File Offset: 0x00000561
		public App()
		{
			TitanVM.TitanVM(35, new object[]
			{
				this
			});
		}
	}
}
