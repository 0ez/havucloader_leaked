﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x02000007 RID: 7
	public partial class MainSpoofer : Window
	{
		// Token: 0x0600000F RID: 15 RVA: 0x00002166 File Offset: 0x00000366
		public MainSpoofer()
		{
			TitanVM.TitanVM(14, new object[]
			{
				this
			});
		}

		// Token: 0x0400001D RID: 29
		internal Rectangle rectangle;

		// Token: 0x0400001E RID: 30
		internal Rectangle rectangle1;

		// Token: 0x0400001F RID: 31
		internal Button button;

		// Token: 0x04000020 RID: 32
		internal Rectangle rectangle2;

		// Token: 0x04000021 RID: 33
		internal Button button1;

		// Token: 0x04000022 RID: 34
		internal Rectangle rectangle3;

		// Token: 0x04000023 RID: 35
		internal Button button2;

		// Token: 0x04000024 RID: 36
		internal Rectangle rectangle4;

		// Token: 0x04000025 RID: 37
		internal Button button3;

		// Token: 0x04000026 RID: 38
		internal Rectangle rectangle5;

		// Token: 0x04000027 RID: 39
		internal Button button4;

		// Token: 0x04000028 RID: 40
		internal Image image;

		// Token: 0x04000029 RID: 41
		internal Image image_Copy;

		// Token: 0x0400002A RID: 42
		internal Image image_Copy1;

		// Token: 0x0400002B RID: 43
		internal Image image_Copy2;

		// Token: 0x0400002C RID: 44
		internal Image image_Copy3;

		// Token: 0x0400002D RID: 45
		private bool _contentLoaded;
	}
}
