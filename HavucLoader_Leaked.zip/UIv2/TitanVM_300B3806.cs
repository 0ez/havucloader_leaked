﻿using System;

// Token: 0x02000064 RID: 100
internal interface TitanVM_300B3806
{
	// Token: 0x0600013A RID: 314
	int TitanVM_64A7C2A2();

	// Token: 0x0600013B RID: 315
	void TitanVM_6966EBBA(TitanVM_B53A6BB3, out TitanVM_887DE97C);
}
