﻿using System;

// Token: 0x0200006E RID: 110
internal class TitanVM_F124833D : TitanVM_22F736AB
{
	// Token: 0x0600015D RID: 349 RVA: 0x000027C5 File Offset: 0x000009C5
	public TitanVM_F124833D(TitanVM_505B4619 A_1)
	{
		this.TitanVM_D888EB78 = new TitanVM_505B4619?(A_1);
	}

	// Token: 0x0600015E RID: 350 RVA: 0x000027D9 File Offset: 0x000009D9
	public unsafe TitanVM_F124833D(TypedReference A_1)
	{
		this.TitanVM_D888EB78 = null;
		this.TitanVM_C7ECB877 = *(TitanVM_F124833D.TitanVM_B892BB6A*)(&A_1);
	}

	// Token: 0x0600015F RID: 351 RVA: 0x0000928C File Offset: 0x0000748C
	public unsafe TitanVM_25A0D8C3 TitanVM_A47D84F5(TitanVM_B53A6BB3 A_1, TitanVM_D977DC0E A_2)
	{
		TypedReference typedReference;
		if (this.TitanVM_D888EB78 != null)
		{
			*(&typedReference) = *(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(this.TitanVM_D888EB78.Value);
		}
		else
		{
			*(TitanVM_F124833D.TitanVM_B892BB6A*)(&typedReference) = this.TitanVM_C7ECB877;
		}
		return TitanVM_25A0D8C3.TitanVM_913FE744(TypedReference.ToObject(typedReference), __reftype(typedReference));
	}

	// Token: 0x06000160 RID: 352 RVA: 0x000092E8 File Offset: 0x000074E8
	public unsafe void TitanVM_95B551D0(TitanVM_B53A6BB3 A_1, TitanVM_25A0D8C3 A_2, TitanVM_D977DC0E A_3)
	{
		TypedReference typedReference;
		if (this.TitanVM_D888EB78 != null)
		{
			*(&typedReference) = *(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(this.TitanVM_D888EB78.Value);
		}
		else
		{
			*(TitanVM_F124833D.TitanVM_B892BB6A*)(&typedReference) = this.TitanVM_C7ECB877;
		}
		Type typeFromHandle = __reftype(typedReference);
		TitanVM_934F86EE.TitanVM_2438202(A_2.TitanVM_496B397D(typeFromHandle), TitanVM_505B4619.TitanVM_877078A4((void*)(&typedReference)));
	}

	// Token: 0x06000161 RID: 353 RVA: 0x000027AD File Offset: 0x000009AD
	public TitanVM_22F736AB TitanVM_128CFAEF(uint A_1)
	{
		return this;
	}

	// Token: 0x06000162 RID: 354 RVA: 0x000027AD File Offset: 0x000009AD
	public TitanVM_22F736AB TitanVM_128CFAEF(ulong A_1)
	{
		return this;
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00009350 File Offset: 0x00007550
	public unsafe void TitanVM_DAE9EB82(TitanVM_B53A6BB3 A_1, TitanVM_505B4619 A_2, Type A_3)
	{
		if (this.TitanVM_D888EB78 != null)
		{
			*(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(A_2) = *(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(this.TitanVM_D888EB78.Value);
			return;
		}
		*(TitanVM_F124833D.TitanVM_B892BB6A*)TitanVM_505B4619.TitanVM_877078A4(A_2) = this.TitanVM_C7ECB877;
	}

	// Token: 0x0400006E RID: 110
	private TitanVM_505B4619? TitanVM_D888EB78;

	// Token: 0x0400006F RID: 111
	private TitanVM_F124833D.TitanVM_B892BB6A TitanVM_C7ECB877;

	// Token: 0x0200006F RID: 111
	private struct TitanVM_B892BB6A
	{
		// Token: 0x04000070 RID: 112
		public IntPtr TitanVM_5FE8B3C1;

		// Token: 0x04000071 RID: 113
		public IntPtr TitanVM_60B7FA2C;
	}
}
