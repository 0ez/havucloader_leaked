﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000076 RID: 118
internal class TitanVM_8690B415 : TitanVM_22F736AB
{
	// Token: 0x0600016A RID: 362 RVA: 0x000027FB File Offset: 0x000009FB
	public TitanVM_8690B415(uint A_1)
	{
		this.TitanVM_6526970F(A_1);
	}

	// Token: 0x0600016B RID: 363 RVA: 0x0000280A File Offset: 0x00000A0A
	public uint TitanVM_4F957670()
	{
		return this.TitanVM_800B9922;
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00002812 File Offset: 0x00000A12
	public void TitanVM_6526970F(uint A_1)
	{
		this.TitanVM_800B9922 = A_1;
	}

	// Token: 0x0600016D RID: 365 RVA: 0x0000939C File Offset: 0x0000759C
	public TitanVM_25A0D8C3 TitanVM_A47D84F5(TitanVM_B53A6BB3 A_1, TitanVM_D977DC0E A_2)
	{
		TitanVM_25A0D8C3 result = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(this.TitanVM_4F957670());
		if (A_2 == (TitanVM_D977DC0E)0)
		{
			result.TitanVM_DC0D55ED((ulong)result.TitanVM_7D2A041C());
		}
		else if (A_2 == (TitanVM_D977DC0E)1)
		{
			result.TitanVM_DC0D55ED((ulong)result.TitanVM_EE803BDA());
		}
		else if (A_2 == (TitanVM_D977DC0E)2)
		{
			result.TitanVM_DC0D55ED((ulong)result.TitanVM_1D7DBE68());
		}
		else if (result.TitanVM_AE0B16C2() is TitanVM_36689CB6)
		{
			result.TitanVM_B7026739(((TitanVM_36689CB6)result.TitanVM_AE0B16C2()).TitanVM_6C810558());
		}
		return result;
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00009420 File Offset: 0x00007620
	public void TitanVM_95B551D0(TitanVM_B53A6BB3 A_1, TitanVM_25A0D8C3 A_2, TitanVM_D977DC0E A_3)
	{
		if (A_3 == (TitanVM_D977DC0E)0)
		{
			A_2.TitanVM_DC0D55ED((ulong)A_2.TitanVM_7D2A041C());
		}
		else if (A_3 == (TitanVM_D977DC0E)1)
		{
			A_2.TitanVM_DC0D55ED((ulong)A_2.TitanVM_EE803BDA());
		}
		else if (A_3 == (TitanVM_D977DC0E)2)
		{
			A_2.TitanVM_DC0D55ED((ulong)A_2.TitanVM_1D7DBE68());
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(this.TitanVM_4F957670(), A_2);
	}

	// Token: 0x0600016F RID: 367 RVA: 0x0000281B File Offset: 0x00000A1B
	public TitanVM_22F736AB TitanVM_128CFAEF(uint A_1)
	{
		return new TitanVM_8690B415(this.TitanVM_4F957670() + A_1);
	}

	// Token: 0x06000170 RID: 368 RVA: 0x0000282A File Offset: 0x00000A2A
	public TitanVM_22F736AB TitanVM_128CFAEF(ulong A_1)
	{
		return new TitanVM_8690B415(this.TitanVM_4F957670() + (uint)A_1);
	}

	// Token: 0x06000171 RID: 369 RVA: 0x0000283A File Offset: 0x00000A3A
	public void TitanVM_DAE9EB82(TitanVM_B53A6BB3 A_1, TitanVM_505B4619 A_2, Type A_3)
	{
		A_1.TitanVM_A80DA418.TitanVM_DAE9EB82(this.TitanVM_4F957670(), A_2, A_3);
	}

	// Token: 0x04000081 RID: 129
	[CompilerGenerated]
	private uint TitanVM_800B9922;
}
