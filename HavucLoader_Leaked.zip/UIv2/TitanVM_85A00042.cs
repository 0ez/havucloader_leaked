﻿using System;

// Token: 0x02000031 RID: 49
internal class TitanVM_85A00042 : TitanVM_300B3806
{
	// Token: 0x060000A0 RID: 160 RVA: 0x000025D7 File Offset: 0x000007D7
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_20679228;
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00006600 File Offset: 0x00004800
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		int num2 = (int)A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C() & ~TitanVM_413328F0.TitanVM_26E47B9F;
		if (!TitanVM_57B74FAC.TitanVM_8248871B && titanVM_25A0D8C.TitanVM_6702A746() >> 32 != 0UL)
		{
			num2 |= TitanVM_413328F0.TitanVM_26E47B9F;
		}
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB((byte)num2);
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
