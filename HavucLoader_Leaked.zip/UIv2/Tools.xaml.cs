﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x0200000B RID: 11
	public partial class Tools : Window
	{
		// Token: 0x0600001B RID: 27 RVA: 0x00002267 File Offset: 0x00000467
		public Tools()
		{
			TitanVM.TitanVM(24, new object[]
			{
				this
			});
		}

		// Token: 0x0400003F RID: 63
		internal Tools window;

		// Token: 0x04000040 RID: 64
		internal Rectangle rectangle;

		// Token: 0x04000041 RID: 65
		internal Button button;

		// Token: 0x04000042 RID: 66
		internal Button button1;

		// Token: 0x04000043 RID: 67
		private bool _contentLoaded;
	}
}
