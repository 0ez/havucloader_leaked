﻿using System;
using System.Reflection;

// Token: 0x02000022 RID: 34
internal class TitanVM_56C7FD5E : TitanVM_BF67496D
{
	// Token: 0x0600006F RID: 111 RVA: 0x00002570 File Offset: 0x00000770
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_5644E93;
	}

	// Token: 0x06000070 RID: 112 RVA: 0x0000526C File Offset: 0x0000346C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		bool flag = (titanVM_25A0D8C.TitanVM_1D7DBE68() & 2147483648U) > 0U;
		FieldInfo fieldInfo = (FieldInfo)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68() & 2147483647U);
		if (!fieldInfo.IsStatic && titanVM_25A0D8C2.TitanVM_AE0B16C2() == null)
		{
			throw new NullReferenceException();
		}
		if (flag)
		{
			TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
			uint num2 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_B7026739(new TitanVM_ECF5A04(titanVM_25A0D8C2.TitanVM_AE0B16C2(), fieldInfo));
			titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C3);
		}
		else
		{
			object obj;
			if (fieldInfo.DeclaringType.IsValueType && titanVM_25A0D8C2.TitanVM_AE0B16C2() is TitanVM_22F736AB)
			{
				obj = ((TitanVM_22F736AB)titanVM_25A0D8C2.TitanVM_AE0B16C2()).TitanVM_A47D84F5(A_1, (TitanVM_D977DC0E)4).TitanVM_496B397D(fieldInfo.DeclaringType);
			}
			else
			{
				obj = titanVM_25A0D8C2.TitanVM_496B397D(fieldInfo.DeclaringType);
			}
			A_1.TitanVM_A80DA418.TitanVM_59168392(num, TitanVM_25A0D8C3.TitanVM_913FE744(fieldInfo.GetValue(obj), fieldInfo.FieldType));
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
