﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x0200000D RID: 13
	public partial class Warzone : Window
	{
		// Token: 0x06000021 RID: 33 RVA: 0x000022F9 File Offset: 0x000004F9
		public Warzone()
		{
			TitanVM.TitanVM(30, new object[]
			{
				this
			});
		}

		// Token: 0x0400004C RID: 76
		internal Rectangle rectangle;

		// Token: 0x0400004D RID: 77
		internal Button button;

		// Token: 0x0400004E RID: 78
		internal Button button1;

		// Token: 0x0400004F RID: 79
		internal Button button1_Copy;

		// Token: 0x04000050 RID: 80
		internal Button button1_Copy1;

		// Token: 0x04000051 RID: 81
		internal TextBlock textBlock;

		// Token: 0x04000052 RID: 82
		internal TextBlock textBlock1;

		// Token: 0x04000053 RID: 83
		internal TextBlock textBlock2;

		// Token: 0x04000054 RID: 84
		internal TextBlock textBlock3;

		// Token: 0x04000055 RID: 85
		private bool _contentLoaded;
	}
}
