﻿using System;

// Token: 0x02000036 RID: 54
internal class TitanVM_EA100CFD : TitanVM_300B3806
{
	// Token: 0x060000AF RID: 175 RVA: 0x000025FA File Offset: 0x000007FA
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_D6662D83;
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x000068D4 File Offset: 0x00004AD4
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		titanVM_25A0D8C.TitanVM_49F1432F((float)titanVM_25A0D8C.TitanVM_6BA6EFAE());
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
