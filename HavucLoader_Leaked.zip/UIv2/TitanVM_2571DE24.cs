﻿using System;

// Token: 0x02000018 RID: 24
internal class TitanVM_2571DE24 : TitanVM_BF67496D
{
	// Token: 0x06000051 RID: 81 RVA: 0x0000252A File Offset: 0x0000072A
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_2E779BEF;
	}

	// Token: 0x06000052 RID: 82 RVA: 0x000049A0 File Offset: 0x00002BA0
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		if (((int)A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C() & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			float f = titanVM_25A0D8C.TitanVM_66B6EB10();
			if (float.IsNaN(f) || float.IsInfinity(f))
			{
				throw new ArithmeticException();
			}
		}
		else
		{
			double d = titanVM_25A0D8C.TitanVM_6BA6EFAE();
			if (double.IsNaN(d) || double.IsInfinity(d))
			{
				throw new ArithmeticException();
			}
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
