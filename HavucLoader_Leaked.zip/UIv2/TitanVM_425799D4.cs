﻿using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Permissions;

// Token: 0x0200008D RID: 141
internal static class TitanVM_425799D4
{
	// Token: 0x060001E3 RID: 483 RVA: 0x0000B9F0 File Offset: 0x00009BF0
	static TitanVM_425799D4()
	{
		ModuleBuilder moduleBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(new AssemblyName("Fish"), AssemblyBuilderAccess.Run).DefineDynamicModule("Fish");
		CustomAttributeBuilder customAttribute = new CustomAttributeBuilder(typeof(SecurityPermissionAttribute).GetConstructor(new Type[]
		{
			typeof(SecurityAction)
		}), new object[]
		{
			SecurityAction.Assert
		}, new PropertyInfo[]
		{
			typeof(SecurityPermissionAttribute).GetProperty("SkipVerification")
		}, new object[]
		{
			true
		});
		moduleBuilder.SetCustomAttribute(customAttribute);
		TitanVM_425799D4.TitanVM_87E03B23 = moduleBuilder.DefineType(" ").CreateType().Module;
	}

	// Token: 0x040000A8 RID: 168
	public static readonly Module TitanVM_87E03B23;
}
