﻿using System;

// Token: 0x0200001A RID: 26
internal class TitanVM_BF30BEF6 : TitanVM_BF67496D
{
	// Token: 0x06000057 RID: 87 RVA: 0x00002538 File Offset: 0x00000738
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_8597FDF9;
	}

	// Token: 0x06000058 RID: 88 RVA: 0x00004ABC File Offset: 0x00002CBC
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		titanVM_25A0D8C.TitanVM_DC0D55ED((titanVM_25A0D8C.TitanVM_6702A746() > titanVM_25A0D8C2.TitanVM_6702A746() || titanVM_25A0D8C.TitanVM_6702A746() < titanVM_25A0D8C3.TitanVM_6702A746()) ? 1UL : 0UL);
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
