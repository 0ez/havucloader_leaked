﻿using System;

// Token: 0x02000013 RID: 19
internal static class TitanVM_54A70E05
{
	// Token: 0x06000033 RID: 51 RVA: 0x00003F30 File Offset: 0x00002130
	public unsafe static uint TitanVM_76FDA7A0(ref byte* A_0)
	{
		uint num = 0U;
		int num2 = 0;
		byte* ptr;
		do
		{
			num |= (uint)((uint)(*A_0 & 127) << num2);
			num2 += 7;
			ptr = A_0;
			A_0 = ptr + 1;
		}
		while ((*ptr & 128) != 0);
		return num;
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00003F68 File Offset: 0x00002168
	public static uint TitanVM_B6BA367F(uint A_0)
	{
		uint num = A_0 >> 3;
		switch (A_0 & 7U)
		{
		case 1U:
			return num | 33554432U;
		case 2U:
			return num | 16777216U;
		case 3U:
			return num | 452984832U;
		case 4U:
			return num | 167772160U;
		case 5U:
			return num | 100663296U;
		case 6U:
			return num | 67108864U;
		case 7U:
			return num | 721420288U;
		default:
			return num;
		}
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00003FDC File Offset: 0x000021DC
	public static void TitanVM_80151D2(uint A_0, uint A_1, uint A_2, uint A_3, ref byte A_4, byte A_5)
	{
		int num = 0;
		if (A_3 == 0U)
		{
			num |= TitanVM_413328F0.TitanVM_645AE929;
		}
		if (((ulong)A_3 & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_52F42074;
		}
		if (((ulong)((A_0 ^ A_2) & (A_1 ^ A_2)) & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_26E47B9F;
		}
		if (((ulong)(A_0 ^ ((A_0 ^ A_1) & (A_1 ^ A_2))) & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_51D19472;
		}
		A_4 = (byte)((int)(A_4 & ~(int)A_5) | (num & (int)A_5));
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00004050 File Offset: 0x00002250
	public static void TitanVM_80151D2(ulong A_0, ulong A_1, ulong A_2, ulong A_3, ref byte A_4, byte A_5)
	{
		int num = 0;
		if (A_3 == 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_645AE929;
		}
		if ((A_3 & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_52F42074;
		}
		if (((A_0 ^ A_2) & (A_1 ^ A_2) & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_26E47B9F;
		}
		if (((A_0 ^ ((A_0 ^ A_1) & (A_1 ^ A_2))) & (ulong)-2147483648) != 0UL)
		{
			num |= TitanVM_413328F0.TitanVM_51D19472;
		}
		A_4 = (byte)((int)(A_4 & ~(int)A_5) | (num & (int)A_5));
	}
}
