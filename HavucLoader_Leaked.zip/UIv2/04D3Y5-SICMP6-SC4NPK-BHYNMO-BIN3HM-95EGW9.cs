﻿using System;
using System.Reflection;

// Token: 0x02000002 RID: 2
internal class 04D3Y5-SICMP6-SC4NPK-BHYNMO-BIN3HM-95EGW9
{
	// Token: 0x06000002 RID: 2 RVA: 0x00002057 File Offset: 0x00000257
	[Obfuscation]
	public static string LFWQxqOSoVbMEKwzHNDypGKUsHGJBRoqjmKoyIrYcmUlWnQrYZBsDxPfVcyQKfqxGKCsahbYwEwcMyYeQpLCpWNMwEtvkAoXWwFlKyrQYDWYbNtwdtZuuNiKXQVvOFOVqzgpTNurYUELZOLJkXrQBTCioUnUCVcsObHCGeCqZHwzjwKjemlQnYuxWXaYzAPdSlWYhjcfvbRTwcYSkdPqJlfQGkFJeDQyStHYzLbVjfumgAaTYhOwKytGgfrXDtbRksadvatycUgEQSJgjMKWOuNuZaStuerQdCcOzXxYOqtQrPPnwlNRIedPEGdvhZdXDqAnQVGloMixaXckkEXiqzhZzmkTTcQOmwnaoCxAFBDWWFOHDSkDcVGdiBODLMslVtkEKbVIhwDOVlcTyCpbRnMrQjSNNTPSjraCukWCWCvFrRiXyUfixquIHTOAjiUnHKEDkzznFNeoRgaYbVpTNHvTXsVBwwsOIhYGmEMZvSCJmfRATPzoSaAapLGSDXRj(string A_0, int A_1)
	{
		return (string)TitanVM.TitanVM(2, new object[]
		{
			A_0,
			A_1
		});
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002077 File Offset: 0x00000277
	static void 04D3Y5-SICMP6-SC4NPK-BHYNMO-BIN3HM-95EGW9()
	{
		TitanVM.TitanVM(3, null);
	}
}
