﻿using System;

// Token: 0x0200001C RID: 28
internal class TitanVM_E2EEA198 : TitanVM_BF67496D
{
	// Token: 0x0600005D RID: 93 RVA: 0x00002546 File Offset: 0x00000746
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_C072809B;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00004BF4 File Offset: 0x00002DF4
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		uint num2 = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917].TitanVM_1D7DBE68();
		uint num3 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num).TitanVM_1D7DBE68();
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num4 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C.TitanVM_DC0D55ED((ulong)((long)A_1.TitanVM_A80DA418.TitanVM_E2EEA198(num2, num3)));
		titanVM_A80DA.TitanVM_59168392(num4, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
