﻿using System;

// Token: 0x02000068 RID: 104
internal class TitanVM_B1B7789A : TitanVM_300B3806
{
	// Token: 0x06000145 RID: 325 RVA: 0x00002756 File Offset: 0x00000956
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_C0CE6281;
	}

	// Token: 0x06000146 RID: 326 RVA: 0x00008F0C File Offset: 0x0000710C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		byte b = A_1.TitanVM_3BCABD76();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_8DBD965D[(int)b];
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num2 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C2.TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746());
		titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
