﻿using System;

// Token: 0x02000090 RID: 144
internal static class TitanVM_413328F0
{
	// Token: 0x060001ED RID: 493 RVA: 0x0000BFC0 File Offset: 0x0000A1C0
	// Note: this type is marked as 'beforefieldinit'.
	static TitanVM_413328F0()
	{
		null.TitanVM_D6662D83 = 127;
		null.TitanVM_B25BD91D = 243;
		null.TitanVM_56489A5E = 8;
		null.TitanVM_9F379454 = 0;
		null.TitanVM_20679228 = 43;
		null.TitanVM_32A9E230 = 172;
		null.TitanVM_C072809B = 106;
		null.TitanVM_209E8396 = 250;
		null.TitanVM_D8BF82DD = 11;
		null.TitanVM_989B36D0 = 103;
		null.TitanVM_3A2307FF = 0;
		null.TitanVM_E0F3D74C = 3;
		null.TitanVM_61A90F04 = 112;
		null.TitanVM_359D77A1 = 85;
		null.TitanVM_5908E19E = 61;
		null.TitanVM_8806C385 = 3;
		null.TitanVM_6FA8886A = 183;
		null.TitanVM_EEAADF20 = 2;
		null.TitanVM_24BE35E0 = 64;
		null.TitanVM_40FBC064 = 241;
		null.TitanVM_54D673DF = 97;
		null.TitanVM_74F6059A = 134;
		null.TitanVM_266EEFBF = 249;
		null.TitanVM_29F70FB5 = 77;
		null.TitanVM_28A28BB9 = 133;
		null.TitanVM_EDC7A78F = 13;
		null.TitanVM_D4826DF1 = 120;
		null.TitanVM_E8181489 = 5;
		null.TitanVM_77A693AF = 76;
		null.TitanVM_6BD54F67 = 195;
		null.TitanVM_60E593CD = 1;
		null.TitanVM_CD3E3A12 = 104;
		null.TitanVM_F76D33DC = 82;
		null.TitanVM_926B7763 = 160;
		null.TitanVM_5AAF44A6 = 3;
		null.TitanVM_26207566 = 168;
		null.TitanVM_F92A756E = 110;
		null.TitanVM_D4DF825A = 14;
		null.TitanVM_5B5C60E8 = 64;
		null.TitanVM_8597FDF9 = 188;
		null.TitanVM_2E779BEF = 146;
		null.TitanVM_52F42074 = 1;
		null.TitanVM_2150E957 = 136;
		null.TitanVM_394C6FA2 = 7;
		null.TitanVM_91D18D8D = 83;
		null.TitanVM_56E9DD90 = 218;
		null.TitanVM_913FBAE2 = 102;
		null.TitanVM_EF96937 = 60;
		null.TitanVM_E579FE7B = 215;
		null.TitanVM_A1A39073 = 205;
		null.TitanVM_1AD32D42 = 123;
		null.TitanVM_B56CC1C4 = 10;
		null.TitanVM_7B5D4747 = 238;
		null.TitanVM_8A2B7977 = 121;
		null.TitanVM_B2BB5E2E = 184;
		null.TitanVM_E0C259EC = 129;
		null.TitanVM_7432F714 = 93;
		null.TitanVM_BB658E9C = 54;
		null.TitanVM_9D9E81CE = 90;
		null.TitanVM_8B47D940 = 6;
		null.TitanVM_645AE929 = 16;
		null.TitanVM_DDFCDD61 = 2;
		null.TitanVM_DE2D8C5B = 9;
		null.TitanVM_41337CD9 = 128;
		null.TitanVM_F38EF3A3 = 2;
		null.TitanVM_5644E93 = 253;
		null.TitanVM_B44CE253 = 170;
		null.TitanVM_478C7506 = 201;
		null.TitanVM_176F87D8 = 109;
		null.TitanVM_42C748AD = 190;
		null.TitanVM_8C541324 = 10;
		null.TitanVM_7AFA1882 = 13;
		null.TitanVM_E68F65FD = 186;
		null.TitanVM_A0EEF38 = 135;
		null.TitanVM_A080DBFA = 239;
		null.TitanVM_60203D8B = 148;
		null.TitanVM_25644F27 = 72;
		null.TitanVM_809D2A99 = 14;
		null.TitanVM_53E1A698 = 1;
		null.TitanVM_EBC1DB4 = 196;
		null.TitanVM_303C626D = 4;
		null.TitanVM_ED4CF552 = 1;
		null.TitanVM_61D12C8C = 253;
		null.TitanVM_3609BB11 = 137;
		null.TitanVM_32BA8545 = 28;
		null.TitanVM_A564352A = 111;
		null.TitanVM_4E44AFB2 = 94;
		null.TitanVM_263082D6 = 145;
		null.TitanVM_D7052A3B = 5;
		null.TitanVM_5F8E55FE = 15;
		null.TitanVM_BAD84433 = 4;
		null.TitanVM_F53E5188 = 193;
		null.TitanVM_BC4ECB69 = 124;
		null.TitanVM_D865C38A = 15;
		null.TitanVM_47ECDC3D = 174;
		null.TitanVM_461EBDF5 = 142;
		null.TitanVM_51D19472 = 8;
		null.TitanVM_B8861B36 = 245;
		null.TitanVM_30A03D3E = 1;
		null.TitanVM_54355C65 = 63;
		null.TitanVM_E5AEC36B = 248;
		null.TitanVM_201F393C = 202;
		null.TitanVM_AC1CF917 = 0;
		null.TitanVM_1F7D1249 = 47;
		null.TitanVM_12519ED5 = 50;
		null.TitanVM_E316D143 = 32;
		null.TitanVM_9ECE3E25 = 9;
		null.TitanVM_CBD1E280 = 118;
		null.TitanVM_95DE8FCF = 143;
		null.TitanVM_F40276CA = 154;
		null.TitanVM_24A5594B = 36;
		null.TitanVM_60B21CC1 = 26;
		null.TitanVM_8D91BBF6 = 12;
		null.TitanVM_4B8345C6 = 128;
		null.TitanVM_C0CE6281 = 156;
		null.TitanVM_EBC84F2C = 229;
		null.TitanVM_26E47B9F = 2;
		null.TitanVM_C52B7078 = 216;
	}

	// Token: 0x040000AD RID: 173
	public static int TitanVM_EDC7A78F;

	// Token: 0x040000AE RID: 174
	public static int TitanVM_394C6FA2;

	// Token: 0x040000AF RID: 175
	public static int TitanVM_809D2A99;

	// Token: 0x040000B0 RID: 176
	public static int TitanVM_8C541324;

	// Token: 0x040000B1 RID: 177
	public static int TitanVM_BAD84433;

	// Token: 0x040000B2 RID: 178
	public static int TitanVM_8D91BBF6;

	// Token: 0x040000B3 RID: 179
	public static int TitanVM_D8BF82DD;

	// Token: 0x040000B4 RID: 180
	public static int TitanVM_53E1A698;

	// Token: 0x040000B5 RID: 181
	public static int TitanVM_AC1CF917;

	// Token: 0x040000B6 RID: 182
	public static int TitanVM_D865C38A;

	// Token: 0x040000B7 RID: 183
	public static int TitanVM_DDFCDD61;

	// Token: 0x040000B8 RID: 184
	public static int TitanVM_E0F3D74C;

	// Token: 0x040000B9 RID: 185
	public static int TitanVM_D7052A3B;

	// Token: 0x040000BA RID: 186
	public static int TitanVM_56489A5E;

	// Token: 0x040000BB RID: 187
	public static int TitanVM_9ECE3E25;

	// Token: 0x040000BC RID: 188
	public static int TitanVM_8B47D940;

	// Token: 0x040000BD RID: 189
	public static int TitanVM_26E47B9F;

	// Token: 0x040000BE RID: 190
	public static int TitanVM_51D19472;

	// Token: 0x040000BF RID: 191
	public static int TitanVM_645AE929;

	// Token: 0x040000C0 RID: 192
	public static int TitanVM_52F42074;

	// Token: 0x040000C1 RID: 193
	public static int TitanVM_E316D143;

	// Token: 0x040000C2 RID: 194
	public static int TitanVM_4B8345C6;

	// Token: 0x040000C3 RID: 195
	public static int TitanVM_303C626D;

	// Token: 0x040000C4 RID: 196
	public static int TitanVM_5B5C60E8;

	// Token: 0x040000C5 RID: 197
	public static int TitanVM_25644F27;

	// Token: 0x040000C6 RID: 198
	public static int TitanVM_D4DF825A;

	// Token: 0x040000C7 RID: 199
	public static int TitanVM_D4826DF1;

	// Token: 0x040000C8 RID: 200
	public static int TitanVM_BB658E9C;

	// Token: 0x040000C9 RID: 201
	public static int TitanVM_24A5594B;

	// Token: 0x040000CA RID: 202
	public static int TitanVM_B2BB5E2E;

	// Token: 0x040000CB RID: 203
	public static int TitanVM_29F70FB5;

	// Token: 0x040000CC RID: 204
	public static int TitanVM_56E9DD90;

	// Token: 0x040000CD RID: 205
	public static int TitanVM_77A693AF;

	// Token: 0x040000CE RID: 206
	public static int TitanVM_1AD32D42;

	// Token: 0x040000CF RID: 207
	public static int TitanVM_28A28BB9;

	// Token: 0x040000D0 RID: 208
	public static int TitanVM_B56CC1C4;

	// Token: 0x040000D1 RID: 209
	public static int TitanVM_B44CE253;

	// Token: 0x040000D2 RID: 210
	public static int TitanVM_209E8396;

	// Token: 0x040000D3 RID: 211
	public static int TitanVM_E68F65FD;

	// Token: 0x040000D4 RID: 212
	public static int TitanVM_A0EEF38;

	// Token: 0x040000D5 RID: 213
	public static int TitanVM_EF96937;

	// Token: 0x040000D6 RID: 214
	public static int TitanVM_A564352A;

	// Token: 0x040000D7 RID: 215
	public static int TitanVM_C0CE6281;

	// Token: 0x040000D8 RID: 216
	public static int TitanVM_E0C259EC;

	// Token: 0x040000D9 RID: 217
	public static int TitanVM_DE2D8C5B;

	// Token: 0x040000DA RID: 218
	public static int TitanVM_5F8E55FE;

	// Token: 0x040000DB RID: 219
	public static int TitanVM_32BA8545;

	// Token: 0x040000DC RID: 220
	public static int TitanVM_24BE35E0;

	// Token: 0x040000DD RID: 221
	public static int TitanVM_266EEFBF;

	// Token: 0x040000DE RID: 222
	public static int TitanVM_CD3E3A12;

	// Token: 0x040000DF RID: 223
	public static int TitanVM_1F7D1249;

	// Token: 0x040000E0 RID: 224
	public static int TitanVM_7432F714;

	// Token: 0x040000E1 RID: 225
	public static int TitanVM_926B7763;

	// Token: 0x040000E2 RID: 226
	public static int TitanVM_26207566;

	// Token: 0x040000E3 RID: 227
	public static int TitanVM_91D18D8D;

	// Token: 0x040000E4 RID: 228
	public static int TitanVM_F53E5188;

	// Token: 0x040000E5 RID: 229
	public static int TitanVM_7B5D4747;

	// Token: 0x040000E6 RID: 230
	public static int TitanVM_A080DBFA;

	// Token: 0x040000E7 RID: 231
	public static int TitanVM_3609BB11;

	// Token: 0x040000E8 RID: 232
	public static int TitanVM_201F393C;

	// Token: 0x040000E9 RID: 233
	public static int TitanVM_E5AEC36B;

	// Token: 0x040000EA RID: 234
	public static int TitanVM_9D9E81CE;

	// Token: 0x040000EB RID: 235
	public static int TitanVM_12519ED5;

	// Token: 0x040000EC RID: 236
	public static int TitanVM_32A9E230;

	// Token: 0x040000ED RID: 237
	public static int TitanVM_95DE8FCF;

	// Token: 0x040000EE RID: 238
	public static int TitanVM_913FBAE2;

	// Token: 0x040000EF RID: 239
	public static int TitanVM_41337CD9;

	// Token: 0x040000F0 RID: 240
	public static int TitanVM_40FBC064;

	// Token: 0x040000F1 RID: 241
	public static int TitanVM_A1A39073;

	// Token: 0x040000F2 RID: 242
	public static int TitanVM_B8861B36;

	// Token: 0x040000F3 RID: 243
	public static int TitanVM_B25BD91D;

	// Token: 0x040000F4 RID: 244
	public static int TitanVM_176F87D8;

	// Token: 0x040000F5 RID: 245
	public static int TitanVM_2150E957;

	// Token: 0x040000F6 RID: 246
	public static int TitanVM_F40276CA;

	// Token: 0x040000F7 RID: 247
	public static int TitanVM_359D77A1;

	// Token: 0x040000F8 RID: 248
	public static int TitanVM_61D12C8C;

	// Token: 0x040000F9 RID: 249
	public static int TitanVM_E579FE7B;

	// Token: 0x040000FA RID: 250
	public static int TitanVM_5908E19E;

	// Token: 0x040000FB RID: 251
	public static int TitanVM_54355C65;

	// Token: 0x040000FC RID: 252
	public static int TitanVM_CBD1E280;

	// Token: 0x040000FD RID: 253
	public static int TitanVM_54D673DF;

	// Token: 0x040000FE RID: 254
	public static int TitanVM_4E44AFB2;

	// Token: 0x040000FF RID: 255
	public static int TitanVM_BC4ECB69;

	// Token: 0x04000100 RID: 256
	public static int TitanVM_EBC1DB4;

	// Token: 0x04000101 RID: 257
	public static int TitanVM_D6662D83;

	// Token: 0x04000102 RID: 258
	public static int TitanVM_478C7506;

	// Token: 0x04000103 RID: 259
	public static int TitanVM_42C748AD;

	// Token: 0x04000104 RID: 260
	public static int TitanVM_20679228;

	// Token: 0x04000105 RID: 261
	public static int TitanVM_6BD54F67;

	// Token: 0x04000106 RID: 262
	public static int TitanVM_74F6059A;

	// Token: 0x04000107 RID: 263
	public static int TitanVM_BF329831 = 212;

	// Token: 0x04000108 RID: 264
	public static int TitanVM_F76D33DC;

	// Token: 0x04000109 RID: 265
	public static int TitanVM_60203D8B;

	// Token: 0x0400010A RID: 266
	public static int TitanVM_F92A756E;

	// Token: 0x0400010B RID: 267
	public static int TitanVM_461EBDF5;

	// Token: 0x0400010C RID: 268
	public static int TitanVM_989B36D0;

	// Token: 0x0400010D RID: 269
	public static int TitanVM_2E779BEF;

	// Token: 0x0400010E RID: 270
	public static int TitanVM_7AFA1882;

	// Token: 0x0400010F RID: 271
	public static int TitanVM_8597FDF9;

	// Token: 0x04000110 RID: 272
	public static int TitanVM_61A90F04;

	// Token: 0x04000111 RID: 273
	public static int TitanVM_5644E93;

	// Token: 0x04000112 RID: 274
	public static int TitanVM_263082D6;

	// Token: 0x04000113 RID: 275
	public static int TitanVM_47ECDC3D;

	// Token: 0x04000114 RID: 276
	public static int TitanVM_C52B7078;

	// Token: 0x04000115 RID: 277
	public static int TitanVM_8A2B7977;

	// Token: 0x04000116 RID: 278
	public static int TitanVM_6FA8886A;

	// Token: 0x04000117 RID: 279
	public static int TitanVM_60B21CC1;

	// Token: 0x04000118 RID: 280
	public static int TitanVM_EBC84F2C;

	// Token: 0x04000119 RID: 281
	public static int TitanVM_C072809B;

	// Token: 0x0400011A RID: 282
	public static int TitanVM_30A03D3E;

	// Token: 0x0400011B RID: 283
	public static int TitanVM_8806C385;

	// Token: 0x0400011C RID: 284
	public static int TitanVM_EEAADF20;

	// Token: 0x0400011D RID: 285
	public static int TitanVM_3A2307FF;

	// Token: 0x0400011E RID: 286
	public static int TitanVM_ED4CF552;

	// Token: 0x0400011F RID: 287
	public static int TitanVM_E8181489;

	// Token: 0x04000120 RID: 288
	public static int TitanVM_9F379454;

	// Token: 0x04000121 RID: 289
	public static int TitanVM_F38EF3A3;

	// Token: 0x04000122 RID: 290
	public static int TitanVM_5AAF44A6;

	// Token: 0x04000123 RID: 291
	public static int TitanVM_60E593CD;
}
