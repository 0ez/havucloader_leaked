﻿using System;

// Token: 0x0200006B RID: 107
internal class TitanVM_16362C8B : TitanVM_300B3806
{
	// Token: 0x0600014E RID: 334 RVA: 0x0000276B File Offset: 0x0000096B
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_DE2D8C5B;
	}

	// Token: 0x0600014F RID: 335 RVA: 0x000090B4 File Offset: 0x000072B4
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		ulong num2 = (ulong)A_1.TitanVM_3BCABD76();
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 8;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 16;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 24;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 32;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 40;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 48;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 56;
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num3 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C.TitanVM_DC0D55ED(num2);
		titanVM_A80DA.TitanVM_59168392(num3, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
