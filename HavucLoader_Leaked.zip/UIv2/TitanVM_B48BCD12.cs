﻿using System;

// Token: 0x02000041 RID: 65
internal class TitanVM_B48BCD12 : TitanVM_300B3806
{
	// Token: 0x060000D0 RID: 208 RVA: 0x0000264C File Offset: 0x0000084C
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_F40276CA;
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00007100 File Offset: 0x00005300
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C3.TitanVM_49F1432F(titanVM_25A0D8C.TitanVM_66B6EB10() / titanVM_25A0D8C2.TitanVM_66B6EB10());
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074);
		int num2 = (int)(A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C() & ~(int)b);
		if (titanVM_25A0D8C3.TitanVM_66B6EB10() == 0f)
		{
			num2 |= TitanVM_413328F0.TitanVM_645AE929;
		}
		else if (titanVM_25A0D8C3.TitanVM_66B6EB10() < 0f)
		{
			num2 |= TitanVM_413328F0.TitanVM_52F42074;
		}
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB((byte)num2);
		A_2 = (TitanVM_887DE97C)0;
	}
}
