﻿using System;

// Token: 0x0200001B RID: 27
internal class TitanVM_404A9DD : TitanVM_BF67496D
{
	// Token: 0x0600005A RID: 90 RVA: 0x0000253F File Offset: 0x0000073F
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_8A2B7977;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00004B6C File Offset: 0x00002D6C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917].TitanVM_1D7DBE68();
		Type type = (Type)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num).TitanVM_1D7DBE68());
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num2 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C.TitanVM_6DD70EA7((uint)TitanVM_2A77C20C.TitanVM_F0095FB(type));
		titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
