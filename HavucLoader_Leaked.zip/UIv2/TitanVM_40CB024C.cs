﻿using System;
using System.Collections.Generic;
using System.Reflection;

// Token: 0x02000020 RID: 32
internal class TitanVM_40CB024C : TitanVM_BF67496D
{
	// Token: 0x06000069 RID: 105 RVA: 0x00002562 File Offset: 0x00000762
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_263082D6;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00004EA8 File Offset: 0x000030A8
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		if (titanVM_25A0D8C2.TitanVM_AE0B16C2() != null)
		{
			MethodInfo methodInfo = (MethodInfo)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68());
			Type type = titanVM_25A0D8C2.TitanVM_AE0B16C2().GetType();
			List<Type> list = new List<Type>();
			do
			{
				list.Add(type);
				type = type.BaseType;
			}
			while (type != null && type != methodInfo.DeclaringType);
			list.Reverse();
			MethodInfo methodInfo2 = methodInfo;
			foreach (Type type2 in list)
			{
				foreach (MethodInfo methodInfo3 in type2.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
				{
					if (methodInfo3.GetBaseDefinition() == methodInfo2)
					{
						methodInfo2 = methodInfo3;
						break;
					}
				}
			}
			TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
			uint num2 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_DC0D55ED((ulong)((long)methodInfo2.MethodHandle.GetFunctionPointer()));
			titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C3);
		}
		if (titanVM_25A0D8C2.TitanVM_6702A746() != 0UL)
		{
			uint num3 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num -= 1U).TitanVM_1D7DBE68();
			ulong num4 = titanVM_25A0D8C.TitanVM_6702A746();
			TitanVM_4B300368 titanVM_326DC9C = A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_AA6A4622(titanVM_25A0D8C2.TitanVM_1D7DBE68()).TitanVM_326DC9C3;
			IntPtr value = TitanVM_40CCE626.TitanVM_A43FC74D(A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_52F77E7C(), num4, num3, titanVM_326DC9C, titanVM_25A0D8C2.TitanVM_1D7DBE68());
			TitanVM_2F04A360 titanVM_A80DA2 = A_1.TitanVM_A80DA418;
			uint num5 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_DC0D55ED((ulong)((long)value));
			titanVM_A80DA2.TitanVM_59168392(num5, titanVM_25A0D8C3);
		}
		else
		{
			MethodBase methodBase = (MethodBase)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68());
			TitanVM_2F04A360 titanVM_A80DA3 = A_1.TitanVM_A80DA418;
			uint num6 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_DC0D55ED((ulong)((long)methodBase.MethodHandle.GetFunctionPointer()));
			titanVM_A80DA3.TitanVM_59168392(num6, titanVM_25A0D8C3);
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
