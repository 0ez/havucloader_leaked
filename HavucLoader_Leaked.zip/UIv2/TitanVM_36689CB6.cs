﻿using System;

// Token: 0x0200007F RID: 127
internal interface TitanVM_36689CB6
{
	// Token: 0x060001A7 RID: 423
	object TitanVM_A47D84F5();

	// Token: 0x060001A8 RID: 424
	Type TitanVM_FBF56C9D();

	// Token: 0x060001A9 RID: 425
	TitanVM_36689CB6 TitanVM_6C810558();
}
