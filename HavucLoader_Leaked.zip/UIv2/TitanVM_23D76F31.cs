﻿using System;

// Token: 0x02000069 RID: 105
internal class TitanVM_23D76F31 : TitanVM_300B3806
{
	// Token: 0x06000148 RID: 328 RVA: 0x0000275D File Offset: 0x0000095D
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_E68F65FD;
	}

	// Token: 0x06000149 RID: 329 RVA: 0x00008F90 File Offset: 0x00007190
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		byte b = A_1.TitanVM_3BCABD76();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_8DBD965D[(int)b];
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
