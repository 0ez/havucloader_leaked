﻿using System;

// Token: 0x0200003B RID: 59
internal class TitanVM_EA3704EC : TitanVM_300B3806
{
	// Token: 0x060000BE RID: 190 RVA: 0x00002622 File Offset: 0x00000822
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_32BA8545;
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00006BBC File Offset: 0x00004DBC
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		if ((titanVM_25A0D8C.TitanVM_EE803BDA() & 32768) != 0)
		{
			titanVM_25A0D8C.TitanVM_6DD70EA7((uint)titanVM_25A0D8C.TitanVM_EE803BDA() | 4294901760U);
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
