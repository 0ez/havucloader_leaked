﻿using System;

// Token: 0x02000081 RID: 129
internal static class TitanVM_B1328321
{
	// Token: 0x060001AE RID: 430 RVA: 0x00002A78 File Offset: 0x00000C78
	public static TitanVM_36689CB6 TitanVM_4F96868F(object A_0, Type A_1)
	{
		return (TitanVM_36689CB6)Activator.CreateInstance(typeof(TitanVM_ACB548D7<>).MakeGenericType(new Type[]
		{
			A_1
		}), new object[]
		{
			A_0
		});
	}

	// Token: 0x060001AF RID: 431 RVA: 0x00002AA7 File Offset: 0x00000CA7
	public static object TitanVM_11B84525(object A_0)
	{
		if (A_0 is TitanVM_36689CB6)
		{
			return ((TitanVM_36689CB6)A_0).TitanVM_A47D84F5();
		}
		return A_0;
	}
}
