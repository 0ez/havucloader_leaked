﻿using System;

// Token: 0x02000055 RID: 85
internal class TitanVM_3FD8001D : TitanVM_300B3806
{
	// Token: 0x0600010D RID: 269 RVA: 0x000026D8 File Offset: 0x000008D8
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_B2BB5E2E;
	}

	// Token: 0x0600010E RID: 270 RVA: 0x000084A4 File Offset: 0x000066A4
	public unsafe void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C2;
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			titanVM_25A0D8C2 = ((TitanVM_22F736AB)titanVM_25A0D8C.TitanVM_AE0B16C2()).TitanVM_A47D84F5(A_1, (TitanVM_D977DC0E)2);
		}
		else
		{
			uint* ptr = titanVM_25A0D8C.TitanVM_6702A746();
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C3.TitanVM_6DD70EA7(*ptr);
			titanVM_25A0D8C2 = titanVM_25A0D8C3;
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
		A_2 = (TitanVM_887DE97C)0;
	}
}
