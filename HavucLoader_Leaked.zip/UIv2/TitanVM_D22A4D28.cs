﻿using System;

// Token: 0x02000066 RID: 102
internal class TitanVM_D22A4D28 : TitanVM_300B3806
{
	// Token: 0x0600013F RID: 319 RVA: 0x00002748 File Offset: 0x00000948
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_EF96937;
	}

	// Token: 0x06000140 RID: 320 RVA: 0x00008DC8 File Offset: 0x00006FC8
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		byte b = A_1.TitanVM_3BCABD76();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_8DBD965D[(int)b];
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num2 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C2.TitanVM_4914D971(titanVM_25A0D8C.TitanVM_EE803BDA());
		titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
