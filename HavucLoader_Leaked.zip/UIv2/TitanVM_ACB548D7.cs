﻿using System;

// Token: 0x02000080 RID: 128
internal struct TitanVM_ACB548D7<<<EMPTY_NAME>>> : TitanVM_36689CB6
{
	// Token: 0x060001AA RID: 426 RVA: 0x00002A44 File Offset: 0x00000C44
	public TitanVM_ACB548D7(!0 A_1)
	{
		this.TitanVM_59A8504A = A_1;
	}

	// Token: 0x060001AB RID: 427 RVA: 0x00002A4D File Offset: 0x00000C4D
	public object TitanVM_A47D84F5()
	{
		return this.TitanVM_59A8504A;
	}

	// Token: 0x060001AC RID: 428 RVA: 0x00002A5A File Offset: 0x00000C5A
	public Type TitanVM_FBF56C9D()
	{
		return typeof(!0);
	}

	// Token: 0x060001AD RID: 429 RVA: 0x00002A66 File Offset: 0x00000C66
	public TitanVM_36689CB6 TitanVM_6C810558()
	{
		return new TitanVM_ACB548D7<!0>(this.TitanVM_59A8504A);
	}

	// Token: 0x04000099 RID: 153
	private !0 TitanVM_59A8504A;
}
