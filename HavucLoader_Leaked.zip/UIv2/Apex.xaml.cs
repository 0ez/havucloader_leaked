﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x02000003 RID: 3
	public partial class Apex : Window
	{
		// Token: 0x06000004 RID: 4 RVA: 0x00002081 File Offset: 0x00000281
		public Apex()
		{
			TitanVM.TitanVM(4, new object[]
			{
				this
			});
		}

		// Token: 0x04000001 RID: 1
		internal Rectangle rectangle;

		// Token: 0x04000002 RID: 2
		internal Button button;

		// Token: 0x04000003 RID: 3
		internal Button button1;

		// Token: 0x04000004 RID: 4
		internal Button button1_Copy;

		// Token: 0x04000005 RID: 5
		internal Button button1_Copy1;

		// Token: 0x04000006 RID: 6
		internal TextBlock textBlock;

		// Token: 0x04000007 RID: 7
		internal TextBlock textBlock1;

		// Token: 0x04000008 RID: 8
		internal TextBlock textBlock2;

		// Token: 0x04000009 RID: 9
		internal TextBlock textBlock3;

		// Token: 0x0400000A RID: 10
		private bool _contentLoaded;
	}
}
