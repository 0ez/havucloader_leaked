﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

// Token: 0x02000015 RID: 21
internal class TitanVM_CD86A4D4
{
	// Token: 0x0600003D RID: 61 RVA: 0x000040C0 File Offset: 0x000022C0
	public static TitanVM_CD86A4D4 TitanVM_6AA5CA23(Module A_0)
	{
		if (TitanVM_CD86A4D4.TitanVM_9DBF07D1 == null)
		{
			TitanVM_CD86A4D4.TitanVM_9DBF07D1 = new Dictionary<Module, TitanVM_CD86A4D4>();
		}
		TitanVM_CD86A4D4 titanVM_CD86A4D;
		if (!TitanVM_CD86A4D4.TitanVM_9DBF07D1.TryGetValue(A_0, out titanVM_CD86A4D))
		{
			titanVM_CD86A4D = new TitanVM_CD86A4D4(TitanVM_C6450551.TitanVM_6AA5CA23(A_0));
			TitanVM_CD86A4D4.TitanVM_9DBF07D1[A_0] = titanVM_CD86A4D;
			object titanVM_1FA89EFC = TitanVM_CD86A4D4.TitanVM_1FA89EFC;
			lock (titanVM_1FA89EFC)
			{
				if (!TitanVM_CD86A4D4.TitanVM_8DF36E2B.ContainsKey(A_0))
				{
					titanVM_CD86A4D.TitanVM_71D16607();
					TitanVM_CD86A4D4.TitanVM_8DF36E2B.Add(A_0, TitanVM_CD86A4D4.TitanVM_8DF36E2B.Count);
				}
			}
		}
		return titanVM_CD86A4D;
	}

	// Token: 0x0600003E RID: 62 RVA: 0x00004154 File Offset: 0x00002354
	public static TitanVM_CD86A4D4 TitanVM_6AA5CA23(int A_0)
	{
		foreach (KeyValuePair<Module, int> keyValuePair in TitanVM_CD86A4D4.TitanVM_8DF36E2B)
		{
			if (keyValuePair.Value == A_0)
			{
				return TitanVM_CD86A4D4.TitanVM_6AA5CA23(keyValuePair.Key);
			}
		}
		return null;
	}

	// Token: 0x0600003F RID: 63 RVA: 0x000024CE File Offset: 0x000006CE
	public static int TitanVM_72CF2926(Module A_0)
	{
		return TitanVM_CD86A4D4.TitanVM_8DF36E2B[A_0];
	}

	// Token: 0x06000040 RID: 64 RVA: 0x000024DB File Offset: 0x000006DB
	private TitanVM_CD86A4D4(TitanVM_C6450551 A_1)
	{
		this.TitanVM_EF2BFB48(A_1);
	}

	// Token: 0x06000041 RID: 65 RVA: 0x000024F5 File Offset: 0x000006F5
	public TitanVM_C6450551 TitanVM_A00F2E4D()
	{
		return this.TitanVM_C20CC3F0;
	}

	// Token: 0x06000042 RID: 66 RVA: 0x000024FD File Offset: 0x000006FD
	private void TitanVM_EF2BFB48(TitanVM_C6450551 A_1)
	{
		this.TitanVM_C20CC3F0 = A_1;
	}

	// Token: 0x06000043 RID: 67 RVA: 0x000041BC File Offset: 0x000023BC
	private void TitanVM_71D16607()
	{
		TitanVM_B6BF0AF2 titanVM_B6BF0AF = this.TitanVM_A00F2E4D().TitanVM_AA6A4622((uint)TitanVM_413328F0.TitanVM_30A03D3E);
		ulong num = this.TitanVM_A00F2E4D().TitanVM_CD47390E() + titanVM_B6BF0AF.TitanVM_B420EDA9;
		this.TitanVM_6966EBBA(num, titanVM_B6BF0AF.TitanVM_B64D5AF4, titanVM_B6BF0AF.TitanVM_326DC9C3, new object[0]);
	}

	// Token: 0x06000044 RID: 68 RVA: 0x0000420C File Offset: 0x0000240C
	public object TitanVM_6966EBBA(uint A_1, object[] A_2)
	{
		TitanVM_B6BF0AF2 titanVM_B6BF0AF = this.TitanVM_A00F2E4D().TitanVM_AA6A4622(A_1);
		ulong num = this.TitanVM_A00F2E4D().TitanVM_CD47390E() + titanVM_B6BF0AF.TitanVM_B420EDA9;
		return this.TitanVM_6966EBBA(num, titanVM_B6BF0AF.TitanVM_B64D5AF4, titanVM_B6BF0AF.TitanVM_326DC9C3, A_2);
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00004250 File Offset: 0x00002450
	public object TitanVM_6966EBBA(ulong A_1, uint A_2, uint A_3, object[] A_4)
	{
		TitanVM_4B300368 titanVM_326DC9C = this.TitanVM_A00F2E4D().TitanVM_AA6A4622(A_3).TitanVM_326DC9C3;
		return this.TitanVM_6966EBBA(A_1, A_2, titanVM_326DC9C, A_4);
	}

	// Token: 0x06000046 RID: 70 RVA: 0x0000427C File Offset: 0x0000247C
	public unsafe void TitanVM_6966EBBA(uint A_1, void*[] A_2, void* A_3)
	{
		TitanVM_B6BF0AF2 titanVM_B6BF0AF = this.TitanVM_A00F2E4D().TitanVM_AA6A4622(A_1);
		ulong num = this.TitanVM_A00F2E4D().TitanVM_CD47390E() + titanVM_B6BF0AF.TitanVM_B420EDA9;
		this.TitanVM_6966EBBA(num, titanVM_B6BF0AF.TitanVM_B64D5AF4, titanVM_B6BF0AF.TitanVM_326DC9C3, A_2, A_3);
	}

	// Token: 0x06000047 RID: 71 RVA: 0x000042C0 File Offset: 0x000024C0
	public unsafe void TitanVM_6966EBBA(ulong A_1, uint A_2, uint A_3, void*[] A_4, void* A_5)
	{
		TitanVM_4B300368 titanVM_326DC9C = this.TitanVM_A00F2E4D().TitanVM_AA6A4622(A_3).TitanVM_326DC9C3;
		this.TitanVM_6966EBBA(A_1, A_2, titanVM_326DC9C, A_4, A_5);
	}

	// Token: 0x06000048 RID: 72 RVA: 0x000042EC File Offset: 0x000024EC
	private object TitanVM_6966EBBA(ulong A_1, uint A_2, TitanVM_4B300368 A_3, object[] A_4)
	{
		if (A_4 == null)
		{
			A_4 = new object[0];
		}
		if (this.TitanVM_6F035795 != null)
		{
			this.TitanVM_31E3AD8E.Push(this.TitanVM_6F035795);
		}
		this.TitanVM_6F035795 = new TitanVM_B53A6BB3(this);
		object result;
		try
		{
			this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_9441CDC9((uint)(A_4.Length + 1));
			uint num = 0U;
			while ((ulong)num < (ulong)((long)A_4.Length))
			{
				this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_59168392(num + 1U, TitanVM_25A0D8C3.TitanVM_913FE744(A_4[(int)num], A_3.TitanVM_84628FA7()[(int)num]));
				num += 1U;
			}
			TitanVM_2F04A360 titanVM_A80DA = this.TitanVM_6F035795.TitanVM_A80DA418;
			uint num2 = (uint)(A_4.Length + 1);
			TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_DC0D55ED(1UL);
			titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C);
			TitanVM_25A0D8C3[] titanVM_8DBD965D = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_D7052A3B = TitanVM_413328F0.TitanVM_D7052A3B;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7(A_2);
			titanVM_8DBD965D[titanVM_D7052A3B] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D2 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_AC1CF = TitanVM_413328F0.TitanVM_AC1CF917;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7(0U);
			titanVM_8DBD965D2[titanVM_AC1CF] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D3 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_D865C38A = TitanVM_413328F0.TitanVM_D865C38A;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7((uint)(A_4.Length + 1));
			titanVM_8DBD965D3[titanVM_D865C38A] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D4 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_DDFCDD = TitanVM_413328F0.TitanVM_DDFCDD61;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_DC0D55ED(A_1);
			titanVM_8DBD965D4[titanVM_DDFCDD] = titanVM_25A0D8C;
			TitanVM_5CFE68E1.TitanVM_6966EBBA(this.TitanVM_6F035795);
			object obj = null;
			if (A_3.TitanVM_41FBC8DA() != typeof(void))
			{
				TitanVM_25A0D8C3 titanVM_25A0D8C2 = this.TitanVM_6F035795.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_EDC7A78F];
				if (Type.GetTypeCode(A_3.TitanVM_41FBC8DA()) == TypeCode.String && titanVM_25A0D8C2.TitanVM_AE0B16C2() == null)
				{
					obj = this.TitanVM_A00F2E4D().TitanVM_EB79B80F(titanVM_25A0D8C2.TitanVM_1D7DBE68());
				}
				else
				{
					obj = titanVM_25A0D8C2.TitanVM_496B397D(A_3.TitanVM_41FBC8DA());
				}
			}
			result = obj;
		}
		finally
		{
			this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_DFAD3EE3();
			if (this.TitanVM_31E3AD8E.Count > 0)
			{
				this.TitanVM_6F035795 = this.TitanVM_31E3AD8E.Pop();
			}
		}
		return result;
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00004500 File Offset: 0x00002700
	private unsafe void TitanVM_6966EBBA(ulong A_1, uint A_2, TitanVM_4B300368 A_3, void*[] A_4, void* A_5)
	{
		if (this.TitanVM_6F035795 != null)
		{
			this.TitanVM_31E3AD8E.Push(this.TitanVM_6F035795);
		}
		this.TitanVM_6F035795 = new TitanVM_B53A6BB3(this);
		try
		{
			this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_9441CDC9((uint)(A_4.Length + 1));
			uint num = 0U;
			TitanVM_25A0D8C3 titanVM_25A0D8C;
			while ((ulong)num < (ulong)((long)A_4.Length))
			{
				if (A_3.TitanVM_84628FA7()[(int)num].IsByRef)
				{
					TitanVM_2F04A360 titanVM_A80DA = this.TitanVM_6F035795.TitanVM_A80DA418;
					uint num2 = num + 1U;
					titanVM_25A0D8C = default(TitanVM_25A0D8C3);
					titanVM_25A0D8C.TitanVM_B7026739(new TitanVM_F124833D(TitanVM_505B4619.TitanVM_877078A4(A_4[(int)num])));
					titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C);
				}
				else
				{
					TypedReference typedReference = *(TypedReference*)A_4[(int)num];
					this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_59168392(num + 1U, TitanVM_25A0D8C3.TitanVM_913FE744(TypedReference.ToObject(typedReference), __reftype(typedReference)));
				}
				num += 1U;
			}
			TitanVM_2F04A360 titanVM_A80DA2 = this.TitanVM_6F035795.TitanVM_A80DA418;
			uint num3 = (uint)(A_4.Length + 1);
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_DC0D55ED(1UL);
			titanVM_A80DA2.TitanVM_59168392(num3, titanVM_25A0D8C);
			TitanVM_25A0D8C3[] titanVM_8DBD965D = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_D7052A3B = TitanVM_413328F0.TitanVM_D7052A3B;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7(A_2);
			titanVM_8DBD965D[titanVM_D7052A3B] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D2 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_AC1CF = TitanVM_413328F0.TitanVM_AC1CF917;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7(0U);
			titanVM_8DBD965D2[titanVM_AC1CF] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D3 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_D865C38A = TitanVM_413328F0.TitanVM_D865C38A;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_6DD70EA7((uint)(A_4.Length + 1));
			titanVM_8DBD965D3[titanVM_D865C38A] = titanVM_25A0D8C;
			TitanVM_25A0D8C3[] titanVM_8DBD965D4 = this.TitanVM_6F035795.TitanVM_8DBD965D;
			int titanVM_DDFCDD = TitanVM_413328F0.TitanVM_DDFCDD61;
			titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_DC0D55ED(A_1);
			titanVM_8DBD965D4[titanVM_DDFCDD] = titanVM_25A0D8C;
			TitanVM_5CFE68E1.TitanVM_6966EBBA(this.TitanVM_6F035795);
			if (A_3.TitanVM_41FBC8DA() != typeof(void))
			{
				if (A_3.TitanVM_41FBC8DA().IsByRef)
				{
					object obj = this.TitanVM_6F035795.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_EDC7A78F].TitanVM_AE0B16C2();
					if (!(obj is TitanVM_22F736AB))
					{
						throw new ExecutionEngineException();
					}
					((TitanVM_22F736AB)obj).TitanVM_DAE9EB82(this.TitanVM_6F035795, TitanVM_505B4619.TitanVM_877078A4(A_5), A_3.TitanVM_41FBC8DA().GetElementType());
				}
				else
				{
					TitanVM_25A0D8C3 titanVM_25A0D8C2 = this.TitanVM_6F035795.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_EDC7A78F];
					object obj2;
					if (Type.GetTypeCode(A_3.TitanVM_41FBC8DA()) == TypeCode.String && titanVM_25A0D8C2.TitanVM_AE0B16C2() == null)
					{
						obj2 = this.TitanVM_A00F2E4D().TitanVM_EB79B80F(titanVM_25A0D8C2.TitanVM_1D7DBE68());
					}
					else
					{
						obj2 = titanVM_25A0D8C2.TitanVM_496B397D(A_3.TitanVM_41FBC8DA());
					}
					TitanVM_934F86EE.TitanVM_2438202(obj2, TitanVM_505B4619.TitanVM_877078A4(A_5));
				}
			}
		}
		finally
		{
			this.TitanVM_6F035795.TitanVM_A80DA418.TitanVM_DFAD3EE3();
			if (this.TitanVM_31E3AD8E.Count > 0)
			{
				this.TitanVM_6F035795 = this.TitanVM_31E3AD8E.Pop();
			}
		}
	}

	// Token: 0x04000065 RID: 101
	[ThreadStatic]
	private static Dictionary<Module, TitanVM_CD86A4D4> TitanVM_9DBF07D1;

	// Token: 0x04000066 RID: 102
	private static readonly object TitanVM_1FA89EFC = new object();

	// Token: 0x04000067 RID: 103
	private static Dictionary<Module, int> TitanVM_8DF36E2B = new Dictionary<Module, int>();

	// Token: 0x04000068 RID: 104
	private Stack<TitanVM_B53A6BB3> TitanVM_31E3AD8E = new Stack<TitanVM_B53A6BB3>();

	// Token: 0x04000069 RID: 105
	private TitanVM_B53A6BB3 TitanVM_6F035795;

	// Token: 0x0400006A RID: 106
	[CompilerGenerated]
	private TitanVM_C6450551 TitanVM_C20CC3F0;
}
