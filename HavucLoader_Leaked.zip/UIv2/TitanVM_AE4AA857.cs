﻿using System;

// Token: 0x02000057 RID: 87
internal class TitanVM_AE4AA857 : TitanVM_300B3806
{
	// Token: 0x06000113 RID: 275 RVA: 0x000026E6 File Offset: 0x000008E6
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_D4826DF1;
	}

	// Token: 0x06000114 RID: 276 RVA: 0x000085AC File Offset: 0x000067AC
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			TitanVM_25A0D8C3 titanVM_25A0D8C2 = ((TitanVM_22F736AB)titanVM_25A0D8C.TitanVM_AE0B16C2()).TitanVM_A47D84F5(A_1, (TitanVM_D977DC0E)4);
			A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
			A_2 = (TitanVM_887DE97C)0;
			return;
		}
		throw new ExecutionEngineException();
	}
}
