﻿using System;

// Token: 0x02000051 RID: 81
internal class TitanVM_C2FB3D9 : TitanVM_300B3806
{
	// Token: 0x06000101 RID: 257 RVA: 0x000026BC File Offset: 0x000008BC
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_7432F714;
	}

	// Token: 0x06000102 RID: 258 RVA: 0x0000822C File Offset: 0x0000642C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C3.TitanVM_DC0D55ED(~(titanVM_25A0D8C.TitanVM_6702A746() | titanVM_25A0D8C2.TitanVM_6702A746()));
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074);
		byte b2 = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_54A70E05.TitanVM_80151D2(titanVM_25A0D8C.TitanVM_6702A746(), titanVM_25A0D8C2.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), ref b2, b);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b2);
		A_2 = (TitanVM_887DE97C)0;
	}
}
