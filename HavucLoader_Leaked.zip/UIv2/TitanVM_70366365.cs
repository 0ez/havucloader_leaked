﻿using System;

// Token: 0x0200005D RID: 93
internal class TitanVM_70366365 : TitanVM_300B3806
{
	// Token: 0x06000125 RID: 293 RVA: 0x00002710 File Offset: 0x00000910
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_77A693AF;
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000895C File Offset: 0x00006B5C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			((TitanVM_22F736AB)titanVM_25A0D8C.TitanVM_AE0B16C2()).TitanVM_95B551D0(A_1, titanVM_25A0D8C2, (TitanVM_D977DC0E)4);
			A_2 = (TitanVM_887DE97C)0;
			return;
		}
		throw new ExecutionEngineException();
	}
}
