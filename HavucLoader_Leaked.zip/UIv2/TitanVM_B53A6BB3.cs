﻿using System;
using System.Collections.Generic;

// Token: 0x02000078 RID: 120
internal class TitanVM_B53A6BB3
{
	// Token: 0x06000174 RID: 372 RVA: 0x00002857 File Offset: 0x00000A57
	public TitanVM_B53A6BB3(TitanVM_CD86A4D4 A_1)
	{
		this.TitanVM_6AA5CA23 = A_1;
	}

	// Token: 0x06000175 RID: 373 RVA: 0x0000949C File Offset: 0x0000769C
	public unsafe byte TitanVM_3BCABD76()
	{
		uint num = this.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3[] titanVM_8DBD965D = this.TitanVM_8DBD965D;
		int titanVM_DDFCDD = TitanVM_413328F0.TitanVM_DDFCDD61;
		ulong num2 = titanVM_8DBD965D[titanVM_DDFCDD].TitanVM_6702A746();
		titanVM_8DBD965D[titanVM_DDFCDD].TitanVM_DC0D55ED(num2 + 1UL);
		byte* ptr = num2;
		byte b = (byte)((uint)(*ptr) ^ num);
		num = num * 7U + (uint)b;
		this.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_6DD70EA7(num);
		return b;
	}

	// Token: 0x04000083 RID: 131
	public readonly TitanVM_25A0D8C3[] TitanVM_8DBD965D = new TitanVM_25A0D8C3[16];

	// Token: 0x04000084 RID: 132
	public readonly TitanVM_2F04A360 TitanVM_A80DA418 = new TitanVM_2F04A360();

	// Token: 0x04000085 RID: 133
	public readonly TitanVM_CD86A4D4 TitanVM_6AA5CA23;

	// Token: 0x04000086 RID: 134
	public readonly List<TitanVM_E1C02F9B> TitanVM_3AD9D897 = new List<TitanVM_E1C02F9B>();

	// Token: 0x04000087 RID: 135
	public readonly List<TitanVM_351C9F54> TitanVM_2C8A1D0A = new List<TitanVM_351C9F54>();
}
