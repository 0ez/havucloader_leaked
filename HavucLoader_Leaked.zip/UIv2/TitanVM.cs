﻿using System;
using System.Reflection;

// Token: 0x02000014 RID: 20
public class TitanVM
{
	// Token: 0x06000037 RID: 55 RVA: 0x00002463 File Offset: 0x00000663
	public static object TitanVM(int A_0, object[] A_1)
	{
		return TitanVM_CD86A4D4.TitanVM_6AA5CA23(global::TitanVM.TitanVM_289BC709).TitanVM_6966EBBA((uint)A_0, A_1);
	}

	// Token: 0x06000038 RID: 56 RVA: 0x00002476 File Offset: 0x00000676
	public unsafe static void TitanVM(int A_0, void*[] A_1, void* A_2)
	{
		TitanVM_CD86A4D4.TitanVM_6AA5CA23(global::TitanVM.TitanVM_289BC709).TitanVM_6966EBBA(Convert.ToUInt32(A_0), A_1, A_2);
	}

	// Token: 0x06000039 RID: 57 RVA: 0x0000248F File Offset: 0x0000068F
	internal static object RunInternal(int A_0, ulong A_1, uint A_2, uint A_3, object[] A_4)
	{
		return TitanVM_CD86A4D4.TitanVM_6AA5CA23(A_0).TitanVM_6966EBBA(A_1, A_2, A_3, A_4);
	}

	// Token: 0x0600003A RID: 58 RVA: 0x000024A1 File Offset: 0x000006A1
	internal unsafe static void RunInternal(int A_0, ulong A_1, uint A_2, uint A_3, void*[] A_4, void* A_5)
	{
		TitanVM_CD86A4D4.TitanVM_6AA5CA23(A_0).TitanVM_6966EBBA(A_1, A_2, A_3, A_4, A_5);
	}

	// Token: 0x04000064 RID: 100
	private static Module TitanVM_289BC709 = Assembly.GetExecutingAssembly().ManifestModule;
}
