﻿using System;

// Token: 0x02000045 RID: 69
internal class TitanVM_A3B5B866 : TitanVM_300B3806
{
	// Token: 0x060000DC RID: 220 RVA: 0x00002668 File Offset: 0x00000868
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_40FBC064;
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00007508 File Offset: 0x00005708
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		byte b = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		ulong num2 = (ulong)(titanVM_25A0D8C.TitanVM_1D7DBE68() * titanVM_25A0D8C2.TitanVM_1D7DBE68());
		titanVM_25A0D8C3.TitanVM_6DD70EA7((uint)num2);
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b2 = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_E316D143);
		byte b3 = (byte)(TitanVM_413328F0.TitanVM_51D19472 | TitanVM_413328F0.TitanVM_26E47B9F);
		byte b4 = 0;
		if (((int)b & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			if ((num2 & (ulong)-1) != 0UL)
			{
				b4 = b3;
			}
		}
		else
		{
			num2 = (ulong)((long)(titanVM_25A0D8C.TitanVM_1D7DBE68() * titanVM_25A0D8C2.TitanVM_1D7DBE68()));
			if (num2 >> 63 != (ulong)(titanVM_25A0D8C3.TitanVM_1D7DBE68() >> 31))
			{
				b4 = b3;
			}
		}
		b = ((b & ~b3) | b4);
		TitanVM_54A70E05.TitanVM_80151D2(titanVM_25A0D8C.TitanVM_1D7DBE68(), titanVM_25A0D8C2.TitanVM_1D7DBE68(), titanVM_25A0D8C3.TitanVM_1D7DBE68(), titanVM_25A0D8C3.TitanVM_1D7DBE68(), ref b, b2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b);
		A_2 = (TitanVM_887DE97C)0;
	}
}
