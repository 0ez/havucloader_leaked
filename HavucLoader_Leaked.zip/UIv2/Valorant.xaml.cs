﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x0200000C RID: 12
	public partial class Valorant : Window
	{
		// Token: 0x0600001E RID: 30 RVA: 0x000022B0 File Offset: 0x000004B0
		public Valorant()
		{
			TitanVM.TitanVM(27, new object[]
			{
				this
			});
		}

		// Token: 0x04000044 RID: 68
		internal Rectangle rectangle;

		// Token: 0x04000045 RID: 69
		internal Button button;

		// Token: 0x04000046 RID: 70
		internal Button button1_Copy1;

		// Token: 0x04000047 RID: 71
		internal TextBlock textBlock;

		// Token: 0x04000048 RID: 72
		internal TextBlock textBlock1;

		// Token: 0x04000049 RID: 73
		internal Button button1_Copy;

		// Token: 0x0400004A RID: 74
		internal Button button1_Copy2;

		// Token: 0x0400004B RID: 75
		private bool _contentLoaded;
	}
}
