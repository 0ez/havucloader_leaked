﻿using System;

// Token: 0x02000033 RID: 51
internal class TitanVM_FA780CC4 : TitanVM_300B3806
{
	// Token: 0x060000A6 RID: 166 RVA: 0x000025E5 File Offset: 0x000007E5
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_478C7506;
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00006794 File Offset: 0x00004994
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		titanVM_25A0D8C.TitanVM_49F1432F((float)titanVM_25A0D8C.TitanVM_6702A746());
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
