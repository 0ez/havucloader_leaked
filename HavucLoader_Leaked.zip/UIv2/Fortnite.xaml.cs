﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x02000004 RID: 4
	public partial class Fortnite : Window
	{
		// Token: 0x06000007 RID: 7 RVA: 0x000020C7 File Offset: 0x000002C7
		public Fortnite()
		{
			TitanVM.TitanVM(8, new object[]
			{
				this
			});
		}

		// Token: 0x0400000B RID: 11
		internal Rectangle rectangle;

		// Token: 0x0400000C RID: 12
		internal Button button;

		// Token: 0x0400000D RID: 13
		internal Button button1;

		// Token: 0x0400000E RID: 14
		internal Button button1_Copy;

		// Token: 0x0400000F RID: 15
		internal TextBlock textBlock;

		// Token: 0x04000010 RID: 16
		internal TextBlock textBlock1;

		// Token: 0x04000011 RID: 17
		internal TextBlock textBlock2;

		// Token: 0x04000012 RID: 18
		internal TextBlock textBlock3;

		// Token: 0x04000013 RID: 19
		internal Button button1_Copy3;

		// Token: 0x04000014 RID: 20
		private bool _contentLoaded;
	}
}
