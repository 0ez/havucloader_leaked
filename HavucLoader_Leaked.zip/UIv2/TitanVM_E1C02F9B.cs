﻿using System;

// Token: 0x02000070 RID: 112
internal struct TitanVM_E1C02F9B
{
	// Token: 0x04000072 RID: 114
	public byte TitanVM_EC4C203E;

	// Token: 0x04000073 RID: 115
	public ulong TitanVM_B7334A85;

	// Token: 0x04000074 RID: 116
	public ulong TitanVM_40B7BA20;

	// Token: 0x04000075 RID: 117
	public Type TitanVM_E70C26FF;

	// Token: 0x04000076 RID: 118
	public TitanVM_25A0D8C3 TitanVM_9E7D8852;

	// Token: 0x04000077 RID: 119
	public TitanVM_25A0D8C3 TitanVM_9D218B89;
}
