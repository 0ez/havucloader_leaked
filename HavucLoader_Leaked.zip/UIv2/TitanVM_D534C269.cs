﻿using System;

// Token: 0x02000061 RID: 97
internal class TitanVM_D534C269 : TitanVM_300B3806
{
	// Token: 0x06000131 RID: 305 RVA: 0x0000272C File Offset: 0x0000092C
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_3609BB11;
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00008B48 File Offset: 0x00006D48
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		num -= 2U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		if (titanVM_25A0D8C2.TitanVM_6702A746() != 0UL)
		{
			A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746());
		}
		A_2 = (TitanVM_887DE97C)0;
	}
}
