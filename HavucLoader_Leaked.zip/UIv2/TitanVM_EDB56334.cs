﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

// Token: 0x02000085 RID: 133
internal static class TitanVM_EDB56334
{
	// Token: 0x060001BC RID: 444 RVA: 0x0000AB74 File Offset: 0x00008D74
	static TitanVM_EDB56334()
	{
		foreach (MethodInfo methodInfo in typeof(TitanVM_22F736AB).GetMethods())
		{
			ParameterInfo[] parameters = methodInfo.GetParameters();
			for (int j = 0; j < parameters.Length; j++)
			{
				if (parameters[j].ParameterType == typeof(TitanVM_505B4619))
				{
					TitanVM_EDB56334.TitanVM_6783F1A = methodInfo;
					break;
				}
			}
			if (TitanVM_EDB56334.TitanVM_6783F1A != null)
			{
				break;
			}
		}
		foreach (MethodInfo methodInfo2 in typeof(TitanVM_934F86EE).GetMethods())
		{
			if (methodInfo2.GetParameters()[0].ParameterType == typeof(TitanVM_505B4619))
			{
				TitanVM_EDB56334.TitanVM_A33883B1 = methodInfo2;
				break;
			}
		}
		foreach (ConstructorInfo constructorInfo in typeof(TitanVM_F124833D).GetConstructors())
		{
			ParameterInfo[] parameters = constructorInfo.GetParameters();
			for (int j = 0; j < parameters.Length; j++)
			{
				if (parameters[j].ParameterType == typeof(TypedReference))
				{
					TitanVM_EDB56334.TitanVM_E70F295C = constructorInfo;
					break;
				}
			}
			if (TitanVM_EDB56334.TitanVM_E70F295C != null)
			{
				break;
			}
		}
	}

	// Token: 0x060001BD RID: 445 RVA: 0x0000ACAC File Offset: 0x00008EAC
	public static MethodBase TitanVM_443FB503(MethodBase A_0)
	{
		MethodBase methodBase = (MethodBase)TitanVM_EDB56334.TitanVM_1813BC2D[A_0];
		if (methodBase != null)
		{
			return methodBase;
		}
		Hashtable titanVM_1813BC2D = TitanVM_EDB56334.TitanVM_1813BC2D;
		MethodBase result;
		lock (titanVM_1813BC2D)
		{
			methodBase = (MethodBase)TitanVM_EDB56334.TitanVM_1813BC2D[A_0];
			if (methodBase != null)
			{
				result = methodBase;
			}
			else
			{
				ParameterInfo[] parameters = A_0.GetParameters();
				Type[] array = new Type[parameters.Length + (A_0.IsStatic ? 0 : 1)];
				for (int i = 0; i < array.Length; i++)
				{
					if (A_0.IsStatic)
					{
						array[i] = parameters[i].ParameterType;
					}
					else if (i == 0)
					{
						array[0] = A_0.DeclaringType;
					}
					else
					{
						array[i] = parameters[i - 1].ParameterType;
					}
				}
				Type returnType = (A_0 is MethodInfo) ? ((MethodInfo)A_0).ReturnType : typeof(void);
				DynamicMethod dynamicMethod = new DynamicMethod("", returnType, array, TitanVM_425799D4.TitanVM_87E03B23, true);
				ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
				for (int j = 0; j < array.Length; j++)
				{
					if (!A_0.IsStatic && j == 0 && array[0].IsValueType)
					{
						ilgenerator.Emit(OpCodes.Ldarga, j);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Ldarg, j);
					}
				}
				if (A_0 is MethodInfo)
				{
					ilgenerator.Emit(OpCodes.Call, (MethodInfo)A_0);
				}
				else
				{
					ilgenerator.Emit(OpCodes.Call, (ConstructorInfo)A_0);
				}
				ilgenerator.Emit(OpCodes.Ret);
				TitanVM_EDB56334.TitanVM_1813BC2D[A_0] = dynamicMethod;
				result = dynamicMethod;
			}
		}
		return result;
	}

	// Token: 0x060001BE RID: 446 RVA: 0x0000AE54 File Offset: 0x00009054
	public static TitanVM_EDB56334.TitanVM_CAAB50B TitanVM_C3155686(MethodBase A_0, OpCode A_1, Type A_2)
	{
		object key;
		Hashtable hashtable;
		if (A_2 == null)
		{
			key = new KeyValuePair<MethodBase, OpCode>(A_0, A_1);
			hashtable = TitanVM_EDB56334.TitanVM_B2CE6FA8;
		}
		else
		{
			key = new KeyValuePair<MethodBase, Type>(A_0, A_2);
			hashtable = TitanVM_EDB56334.TitanVM_78CF8EE7;
		}
		TitanVM_EDB56334.TitanVM_CAAB50B titanVM_CAAB50B = (TitanVM_EDB56334.TitanVM_CAAB50B)hashtable[key];
		if (titanVM_CAAB50B != null)
		{
			return titanVM_CAAB50B;
		}
		Hashtable titanVM_B2CE6FA = TitanVM_EDB56334.TitanVM_B2CE6FA8;
		TitanVM_EDB56334.TitanVM_CAAB50B result;
		lock (titanVM_B2CE6FA)
		{
			titanVM_CAAB50B = (TitanVM_EDB56334.TitanVM_CAAB50B)hashtable[key];
			if (titanVM_CAAB50B != null)
			{
				result = titanVM_CAAB50B;
			}
			else
			{
				ParameterInfo[] parameters = A_0.GetParameters();
				Type[] array;
				if (A_1 != OpCodes.Newobj)
				{
					array = new Type[parameters.Length + (A_0.IsStatic ? 0 : 1) + 1];
					for (int i = 0; i < array.Length - 1; i++)
					{
						if (A_0.IsStatic)
						{
							array[i] = parameters[i].ParameterType;
						}
						else if (i == 0)
						{
							if (A_2 != null)
							{
								array[0] = A_2.MakeByRefType();
							}
							else if (A_0.DeclaringType.IsValueType)
							{
								array[0] = A_0.DeclaringType.MakeByRefType();
							}
							else
							{
								array[0] = A_0.DeclaringType;
							}
						}
						else
						{
							array[i] = parameters[i - 1].ParameterType;
						}
					}
				}
				else
				{
					array = new Type[parameters.Length + 1];
					for (int j = 0; j < array.Length - 1; j++)
					{
						array[j] = parameters[j].ParameterType;
					}
				}
				Type type = (A_0 is MethodInfo) ? ((MethodInfo)A_0).ReturnType : typeof(void);
				if (A_1 == OpCodes.Newobj)
				{
					type = A_0.DeclaringType;
				}
				DynamicMethod dynamicMethod = new DynamicMethod("", typeof(object), new Type[]
				{
					typeof(TitanVM_B53A6BB3),
					typeof(TitanVM_22F736AB[]),
					typeof(Type[])
				}, TitanVM_425799D4.TitanVM_87E03B23, true);
				ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
				for (int k = 0; k < array.Length - 1; k++)
				{
					Type type2 = array[k];
					bool isByRef = type2.IsByRef;
					if (isByRef)
					{
						type2 = type2.GetElementType();
					}
					LocalBuilder local = ilgenerator.DeclareLocal(typeof(TypedReference));
					ilgenerator.Emit(OpCodes.Ldarg_1);
					ilgenerator.Emit(OpCodes.Ldc_I4, k);
					ilgenerator.Emit(OpCodes.Ldelem_Ref);
					ilgenerator.Emit(OpCodes.Ldarg_0);
					ilgenerator.Emit(OpCodes.Ldloca, local);
					ilgenerator.Emit(OpCodes.Ldarg_2);
					ilgenerator.Emit(OpCodes.Ldc_I4, k);
					ilgenerator.Emit(OpCodes.Ldelem_Ref);
					ilgenerator.Emit(OpCodes.Callvirt, TitanVM_EDB56334.TitanVM_6783F1A);
					ilgenerator.Emit(OpCodes.Ldloca, local);
					ilgenerator.Emit(OpCodes.Ldarg_2);
					ilgenerator.Emit(OpCodes.Ldc_I4, k);
					ilgenerator.Emit(OpCodes.Ldelem_Ref);
					ilgenerator.Emit(OpCodes.Call, TitanVM_EDB56334.TitanVM_A33883B1);
					ilgenerator.Emit(OpCodes.Ldloc, local);
					ilgenerator.Emit(OpCodes.Refanyval, type2);
					if (!isByRef)
					{
						ilgenerator.Emit(OpCodes.Ldobj, type2);
					}
				}
				if (A_2 != null)
				{
					ilgenerator.Emit(OpCodes.Constrained, A_2);
				}
				if (A_0 is MethodInfo)
				{
					ilgenerator.Emit(A_1, (MethodInfo)A_0);
				}
				else
				{
					ilgenerator.Emit(A_1, (ConstructorInfo)A_0);
				}
				if (type.IsByRef)
				{
					ilgenerator.Emit(OpCodes.Mkrefany, type.GetElementType());
					ilgenerator.Emit(OpCodes.Newobj, TitanVM_EDB56334.TitanVM_E70F295C);
				}
				else if (type == typeof(void))
				{
					ilgenerator.Emit(OpCodes.Ldnull);
				}
				else if (type.IsValueType)
				{
					ilgenerator.Emit(OpCodes.Box, type);
				}
				ilgenerator.Emit(OpCodes.Ret);
				titanVM_CAAB50B = (TitanVM_EDB56334.TitanVM_CAAB50B)dynamicMethod.CreateDelegate(typeof(TitanVM_EDB56334.TitanVM_CAAB50B));
				hashtable[key] = titanVM_CAAB50B;
				result = titanVM_CAAB50B;
			}
		}
		return result;
	}

	// Token: 0x0400009C RID: 156
	private static Hashtable TitanVM_1813BC2D = new Hashtable();

	// Token: 0x0400009D RID: 157
	private static Hashtable TitanVM_B2CE6FA8 = new Hashtable();

	// Token: 0x0400009E RID: 158
	private static Hashtable TitanVM_78CF8EE7 = new Hashtable();

	// Token: 0x0400009F RID: 159
	private static MethodInfo TitanVM_6783F1A;

	// Token: 0x040000A0 RID: 160
	private static MethodInfo TitanVM_A33883B1;

	// Token: 0x040000A1 RID: 161
	private static ConstructorInfo TitanVM_E70F295C;

	// Token: 0x02000086 RID: 134
	// (Invoke) Token: 0x060001C0 RID: 448
	public delegate object TitanVM_CAAB50B(TitanVM_B53A6BB3, TitanVM_22F736AB[], Type[]);
}
