﻿using System;

// Token: 0x02000062 RID: 98
internal class TitanVM_11D3A8B4 : TitanVM_300B3806
{
	// Token: 0x06000134 RID: 308 RVA: 0x00002733 File Offset: 0x00000933
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_E5AEC36B;
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00008BD8 File Offset: 0x00006DD8
	public unsafe void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		num -= 2U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		uint num2 = titanVM_25A0D8C2.TitanVM_1D7DBE68();
		ushort num3 = *(UIntPtr)(titanVM_25A0D8C.TitanVM_6702A746() - 2UL);
		if (num2 < (uint)num3)
		{
			TitanVM_25A0D8C3[] titanVM_8DBD965D = A_1.TitanVM_8DBD965D;
			int titanVM_DDFCDD = TitanVM_413328F0.TitanVM_DDFCDD61;
			titanVM_8DBD965D[titanVM_DDFCDD].TitanVM_DC0D55ED(titanVM_8DBD965D[titanVM_DDFCDD].TitanVM_6702A746() + (ulong)((long)(*((UIntPtr)titanVM_25A0D8C.TitanVM_6702A746() + (UIntPtr)((IntPtr)((ulong)num2 * 4UL))))));
		}
		A_2 = (TitanVM_887DE97C)0;
	}
}
