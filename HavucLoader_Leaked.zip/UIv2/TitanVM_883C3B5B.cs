﻿using System;

// Token: 0x0200003C RID: 60
internal class TitanVM_883C3B5B : TitanVM_300B3806
{
	// Token: 0x060000C1 RID: 193 RVA: 0x00002629 File Offset: 0x00000829
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_5F8E55FE;
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00006C20 File Offset: 0x00004E20
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		if ((titanVM_25A0D8C.TitanVM_7D2A041C() & 128) != 0)
		{
			titanVM_25A0D8C.TitanVM_6DD70EA7((uint)titanVM_25A0D8C.TitanVM_7D2A041C() | 4294967040U);
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
