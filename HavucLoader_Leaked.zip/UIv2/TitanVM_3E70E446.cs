﻿using System;
using System.Collections.Generic;

// Token: 0x02000096 RID: 150
internal static class TitanVM_3E70E446
{
	// Token: 0x060001FD RID: 509 RVA: 0x0000C62C File Offset: 0x0000A82C
	static TitanVM_3E70E446()
	{
		foreach (Type type in typeof(TitanVM_3E70E446).Assembly.GetTypes())
		{
			if (typeof(TitanVM_300B3806).IsAssignableFrom(type) && !type.IsAbstract)
			{
				TitanVM_300B3806 titanVM_300B = (TitanVM_300B3806)Activator.CreateInstance(type);
				TitanVM_3E70E446.TitanVM_ADF46EED[titanVM_300B.TitanVM_64A7C2A2()] = titanVM_300B;
			}
		}
	}

	// Token: 0x060001FE RID: 510 RVA: 0x00002BAB File Offset: 0x00000DAB
	public static TitanVM_300B3806 TitanVM_7FD46787(int A_0)
	{
		return TitanVM_3E70E446.TitanVM_ADF46EED[A_0];
	}

	// Token: 0x04000135 RID: 309
	private static readonly Dictionary<int, TitanVM_300B3806> TitanVM_ADF46EED = new Dictionary<int, TitanVM_300B3806>();
}
