﻿using System;

// Token: 0x02000012 RID: 18
internal static class TitanVM_57B74FAC
{
	// Token: 0x04000062 RID: 98
	public static readonly bool TitanVM_8248871B = IntPtr.Size == 8;

	// Token: 0x04000063 RID: 99
	public static readonly bool TitanVM_F19591BE = BitConverter.IsLittleEndian;
}
