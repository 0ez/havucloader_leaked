﻿using System;

// Token: 0x02000026 RID: 38
internal interface TitanVM_BF67496D
{
	// Token: 0x06000080 RID: 128
	int TitanVM_64A7C2A2();

	// Token: 0x06000081 RID: 129
	void TitanVM_6966EBBA(TitanVM_B53A6BB3, out TitanVM_887DE97C);
}
