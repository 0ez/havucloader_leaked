﻿using System;

// Token: 0x02000052 RID: 82
internal class TitanVM_6CB48B64 : TitanVM_300B3806
{
	// Token: 0x06000104 RID: 260 RVA: 0x000026C3 File Offset: 0x000008C3
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_CD3E3A12;
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00008324 File Offset: 0x00006524
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num -= 1U);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746());
		A_2 = (TitanVM_887DE97C)0;
	}
}
