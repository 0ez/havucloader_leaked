﻿using System;

// Token: 0x02000063 RID: 99
internal class TitanVM_F2FA3C83 : TitanVM_300B3806
{
	// Token: 0x06000137 RID: 311 RVA: 0x0000273A File Offset: 0x0000093A
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_209E8396;
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00008C88 File Offset: 0x00006E88
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num -= 1U);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		byte b = A_1.TitanVM_3BCABD76();
		if (((int)b == TitanVM_413328F0.TitanVM_D865C38A || (int)b == TitanVM_413328F0.TitanVM_AC1CF917) && titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_8690B415)
		{
			TitanVM_25A0D8C3[] titanVM_8DBD965D = A_1.TitanVM_8DBD965D;
			int num2 = (int)b;
			TitanVM_25A0D8C3 titanVM_25A0D8C2 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C2.TitanVM_6DD70EA7(((TitanVM_8690B415)titanVM_25A0D8C.TitanVM_AE0B16C2()).TitanVM_4F957670());
			titanVM_8DBD965D[num2] = titanVM_25A0D8C2;
		}
		else
		{
			A_1.TitanVM_8DBD965D[(int)b] = titanVM_25A0D8C;
		}
		A_2 = (TitanVM_887DE97C)0;
	}
}
