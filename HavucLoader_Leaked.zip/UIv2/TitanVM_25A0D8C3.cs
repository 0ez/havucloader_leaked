﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// Token: 0x0200007A RID: 122
[StructLayout(LayoutKind.Explicit)]
internal struct TitanVM_25A0D8C3
{
	// Token: 0x06000180 RID: 384 RVA: 0x000028D6 File Offset: 0x00000AD6
	public ulong TitanVM_6702A746()
	{
		return this.TitanVM_4CFDACB8;
	}

	// Token: 0x06000181 RID: 385 RVA: 0x000028DE File Offset: 0x00000ADE
	public void TitanVM_DC0D55ED(ulong A_1)
	{
		this.TitanVM_4CFDACB8 = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x06000182 RID: 386 RVA: 0x000028EE File Offset: 0x00000AEE
	public uint TitanVM_1D7DBE68()
	{
		return this.TitanVM_95194EAA;
	}

	// Token: 0x06000183 RID: 387 RVA: 0x000028F6 File Offset: 0x00000AF6
	public void TitanVM_6DD70EA7(uint A_1)
	{
		this.TitanVM_95194EAA = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x06000184 RID: 388 RVA: 0x00002906 File Offset: 0x00000B06
	public ushort TitanVM_EE803BDA()
	{
		return this.TitanVM_487A2F6C;
	}

	// Token: 0x06000185 RID: 389 RVA: 0x0000290E File Offset: 0x00000B0E
	public void TitanVM_4914D971(ushort A_1)
	{
		this.TitanVM_487A2F6C = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0000291E File Offset: 0x00000B1E
	public byte TitanVM_7D2A041C()
	{
		return this.TitanVM_3B1463DB;
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00002926 File Offset: 0x00000B26
	public void TitanVM_BBF050CB(byte A_1)
	{
		this.TitanVM_3B1463DB = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00002936 File Offset: 0x00000B36
	public double TitanVM_6BA6EFAE()
	{
		return this.TitanVM_161A08B7;
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0000293E File Offset: 0x00000B3E
	public void TitanVM_9F667335(double A_1)
	{
		this.TitanVM_161A08B7 = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x0600018A RID: 394 RVA: 0x0000294E File Offset: 0x00000B4E
	public float TitanVM_66B6EB10()
	{
		return this.TitanVM_92A9AE01;
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00002956 File Offset: 0x00000B56
	public void TitanVM_49F1432F(float A_1)
	{
		this.TitanVM_92A9AE01 = A_1;
		this.TitanVM_1CA4477E = null;
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00002966 File Offset: 0x00000B66
	public object TitanVM_AE0B16C2()
	{
		return this.TitanVM_1CA4477E;
	}

	// Token: 0x0600018D RID: 397 RVA: 0x0000296E File Offset: 0x00000B6E
	public void TitanVM_B7026739(object A_1)
	{
		this.TitanVM_1CA4477E = A_1;
		this.TitanVM_4CFDACB8 = 0UL;
	}

	// Token: 0x0600018E RID: 398 RVA: 0x00009E38 File Offset: 0x00008038
	public static TitanVM_25A0D8C3 TitanVM_913FE744(object A_0, Type A_1)
	{
		if (A_1.IsEnum)
		{
			Type underlyingType = Enum.GetUnderlyingType(A_1);
			return TitanVM_25A0D8C3.TitanVM_913FE744(Convert.ChangeType(A_0, underlyingType), underlyingType);
		}
		switch (Type.GetTypeCode(A_1))
		{
		case TypeCode.Boolean:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_3B1463DB = (((bool)A_0) ? 1 : 0)
			};
			return result;
		}
		case TypeCode.Char:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_487A2F6C = (ushort)((char)A_0)
			};
			return result;
		}
		case TypeCode.SByte:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_3B1463DB = (byte)((sbyte)A_0)
			};
			return result;
		}
		case TypeCode.Byte:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_3B1463DB = (byte)A_0
			};
			return result;
		}
		case TypeCode.Int16:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_487A2F6C = (ushort)((short)A_0)
			};
			return result;
		}
		case TypeCode.UInt16:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_487A2F6C = (ushort)A_0
			};
			return result;
		}
		case TypeCode.Int32:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_95194EAA = (uint)((int)A_0)
			};
			return result;
		}
		case TypeCode.UInt32:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_95194EAA = (uint)A_0
			};
			return result;
		}
		case TypeCode.Int64:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_4CFDACB8 = (ulong)((long)A_0)
			};
			return result;
		}
		case TypeCode.UInt64:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_4CFDACB8 = (ulong)A_0
			};
			return result;
		}
		case TypeCode.Single:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_92A9AE01 = (float)A_0
			};
			return result;
		}
		case TypeCode.Double:
		{
			TitanVM_25A0D8C3 result = new TitanVM_25A0D8C3
			{
				TitanVM_161A08B7 = (double)A_0
			};
			return result;
		}
		default:
		{
			TitanVM_25A0D8C3 result;
			if (A_0 is Pointer)
			{
				result = new TitanVM_25A0D8C3
				{
					TitanVM_4CFDACB8 = Pointer.Unbox(A_0)
				};
				return result;
			}
			if (A_0 is IntPtr)
			{
				result = new TitanVM_25A0D8C3
				{
					TitanVM_4CFDACB8 = (ulong)((long)((IntPtr)A_0))
				};
				return result;
			}
			if (A_0 is UIntPtr)
			{
				result = new TitanVM_25A0D8C3
				{
					TitanVM_4CFDACB8 = (ulong)((UIntPtr)A_0)
				};
				return result;
			}
			if (A_1.IsValueType)
			{
				result = new TitanVM_25A0D8C3
				{
					TitanVM_1CA4477E = TitanVM_B1328321.TitanVM_4F96868F(A_0, A_1)
				};
				return result;
			}
			result = new TitanVM_25A0D8C3
			{
				TitanVM_1CA4477E = A_0
			};
			return result;
		}
		}
	}

	// Token: 0x0600018F RID: 399 RVA: 0x0000297F File Offset: 0x00000B7F
	public unsafe void TitanVM_A876C9D3(TitanVM_505B4619 A_1)
	{
		*(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(A_1) = __makeref(this.TitanVM_95194EAA);
	}

	// Token: 0x06000190 RID: 400 RVA: 0x00002997 File Offset: 0x00000B97
	public unsafe void TitanVM_D47C4516(TitanVM_505B4619 A_1, Type A_2)
	{
		if (this.TitanVM_1CA4477E is ValueType && A_2.IsValueType)
		{
			TitanVM_934F86EE.TitanVM_D639CB6F(this.TitanVM_1CA4477E, A_1);
			return;
		}
		*(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(A_1) = __makeref(this.TitanVM_1CA4477E);
	}

	// Token: 0x06000191 RID: 401 RVA: 0x0000A05C File Offset: 0x0000825C
	public object TitanVM_496B397D(Type A_1)
	{
		if (A_1.IsEnum)
		{
			return Enum.ToObject(A_1, this.TitanVM_496B397D(Enum.GetUnderlyingType(A_1)));
		}
		switch (Type.GetTypeCode(A_1))
		{
		case TypeCode.Boolean:
			return this.TitanVM_3B1463DB > 0;
		case TypeCode.Char:
			return (char)this.TitanVM_487A2F6C;
		case TypeCode.SByte:
			return (sbyte)this.TitanVM_3B1463DB;
		case TypeCode.Byte:
			return this.TitanVM_3B1463DB;
		case TypeCode.Int16:
			return (short)this.TitanVM_487A2F6C;
		case TypeCode.UInt16:
			return this.TitanVM_487A2F6C;
		case TypeCode.Int32:
			return (int)this.TitanVM_95194EAA;
		case TypeCode.UInt32:
			return this.TitanVM_95194EAA;
		case TypeCode.Int64:
			return (long)this.TitanVM_4CFDACB8;
		case TypeCode.UInt64:
			return this.TitanVM_4CFDACB8;
		case TypeCode.Single:
			return this.TitanVM_92A9AE01;
		case TypeCode.Double:
			return this.TitanVM_161A08B7;
		default:
			if (A_1.IsPointer)
			{
				return Pointer.Box(this.TitanVM_4CFDACB8, A_1);
			}
			if (A_1 == typeof(IntPtr))
			{
				return TitanVM_57B74FAC.TitanVM_8248871B ? new IntPtr((long)this.TitanVM_4CFDACB8) : new IntPtr((int)this.TitanVM_95194EAA);
			}
			if (A_1 == typeof(UIntPtr))
			{
				return TitanVM_57B74FAC.TitanVM_8248871B ? new UIntPtr(this.TitanVM_4CFDACB8) : new UIntPtr(this.TitanVM_95194EAA);
			}
			return TitanVM_B1328321.TitanVM_11B84525(this.TitanVM_1CA4477E);
		}
	}

	// Token: 0x04000089 RID: 137
	[FieldOffset(0)]
	private ulong TitanVM_4CFDACB8;

	// Token: 0x0400008A RID: 138
	[FieldOffset(0)]
	private double TitanVM_161A08B7;

	// Token: 0x0400008B RID: 139
	[FieldOffset(0)]
	private uint TitanVM_95194EAA;

	// Token: 0x0400008C RID: 140
	[FieldOffset(0)]
	private float TitanVM_92A9AE01;

	// Token: 0x0400008D RID: 141
	[FieldOffset(0)]
	private ushort TitanVM_487A2F6C;

	// Token: 0x0400008E RID: 142
	[FieldOffset(0)]
	private byte TitanVM_3B1463DB;

	// Token: 0x0400008F RID: 143
	[FieldOffset(8)]
	private object TitanVM_1CA4477E;

	// Token: 0x04000090 RID: 144
	public static readonly TitanVM_25A0D8C3 TitanVM_2090C8C5;
}
