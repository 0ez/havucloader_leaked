﻿using System;

// Token: 0x0200003A RID: 58
internal class TitanVM_C25DF981 : TitanVM_300B3806
{
	// Token: 0x060000BB RID: 187 RVA: 0x0000261B File Offset: 0x0000081B
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_24BE35E0;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00006B54 File Offset: 0x00004D54
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		if ((titanVM_25A0D8C.TitanVM_1D7DBE68() & 2147483648U) != 0U)
		{
			titanVM_25A0D8C.TitanVM_DC0D55ED(18446744069414584320UL | (ulong)titanVM_25A0D8C.TitanVM_1D7DBE68());
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
