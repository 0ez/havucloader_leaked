﻿using System;

// Token: 0x0200001F RID: 31
internal class TitanVM_3558F461 : TitanVM_BF67496D
{
	// Token: 0x06000066 RID: 102 RVA: 0x0000255B File Offset: 0x0000075B
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_C52B7078;
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00004E4C File Offset: 0x0000304C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		int num2 = (int)A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_1D7DBE68();
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		if (num2 == 1)
		{
			A_2 = (TitanVM_887DE97C)3;
			return;
		}
		A_2 = (TitanVM_887DE97C)2;
	}
}
