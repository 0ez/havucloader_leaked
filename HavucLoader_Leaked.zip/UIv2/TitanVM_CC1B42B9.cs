﻿using System;

// Token: 0x02000032 RID: 50
internal class TitanVM_CC1B42B9 : TitanVM_300B3806
{
	// Token: 0x060000A3 RID: 163 RVA: 0x000025DE File Offset: 0x000007DE
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_6BD54F67;
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00006690 File Offset: 0x00004890
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		double num2 = titanVM_25A0D8C.TitanVM_6BA6EFAE();
		titanVM_25A0D8C.TitanVM_DC0D55ED((ulong)((long)num2));
		int num3 = (int)((byte)((int)A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C() & ~TitanVM_413328F0.TitanVM_26E47B9F));
		if ((num3 & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			if (num2 <= -1.0 || num2 >= 1.8446744073709552E+19)
			{
				num3 |= TitanVM_413328F0.TitanVM_26E47B9F;
			}
			if (num2 >= 9.223372036854776E+18)
			{
				titanVM_25A0D8C.TitanVM_DC0D55ED((ulong)((double)((long)num2) - 9.223372036854776E+18) + 9223372036854775808UL);
			}
		}
		else if (num2 <= -9.223372036854778E+18 || num2 >= 9.223372036854776E+18)
		{
			num3 |= TitanVM_413328F0.TitanVM_26E47B9F;
		}
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB((byte)(num3 & ~TitanVM_413328F0.TitanVM_E316D143));
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
