﻿using System;

// Token: 0x02000077 RID: 119
internal struct TitanVM_505B4619
{
	// Token: 0x06000172 RID: 370 RVA: 0x0000947C File Offset: 0x0000767C
	public unsafe static TitanVM_505B4619 TitanVM_877078A4(void* A_0)
	{
		return new TitanVM_505B4619
		{
			TitanVM_8DD7B4F9 = A_0
		};
	}

	// Token: 0x06000173 RID: 371 RVA: 0x0000284F File Offset: 0x00000A4F
	public unsafe static void* TitanVM_877078A4(TitanVM_505B4619 A_0)
	{
		return A_0.TitanVM_8DD7B4F9;
	}

	// Token: 0x04000082 RID: 130
	public unsafe void* TitanVM_8DD7B4F9;
}
