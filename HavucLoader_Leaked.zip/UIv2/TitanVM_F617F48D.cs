﻿using System;

// Token: 0x02000046 RID: 70
internal class TitanVM_F617F48D : TitanVM_300B3806
{
	// Token: 0x060000DF RID: 223 RVA: 0x0000266F File Offset: 0x0000086F
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_A1A39073;
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00007660 File Offset: 0x00005860
	private static ulong TitanVM_28DB8C88(ulong A_0, ulong A_1)
	{
		ulong num = A_0 & (ulong)-1;
		ulong num2 = A_0 >> 32;
		ulong num3 = A_1 & (ulong)-1;
		ulong num4 = A_1 >> 32;
		ulong num5 = num * num3;
		num5 = num2 * num3 + (num5 >> 32);
		ulong num6 = num5 & (ulong)-1;
		ulong num7 = num5 >> 32;
		num5 = num6 + num * num4;
		return num7 + num2 * num4 + (num5 >> 32);
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x000076B4 File Offset: 0x000058B4
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		byte b = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		ulong num2 = titanVM_25A0D8C.TitanVM_6702A746() * titanVM_25A0D8C2.TitanVM_6702A746();
		titanVM_25A0D8C3.TitanVM_DC0D55ED(num2);
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b2 = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_E316D143);
		byte b3 = (byte)(TitanVM_413328F0.TitanVM_51D19472 | TitanVM_413328F0.TitanVM_26E47B9F);
		byte b4 = 0;
		if (((int)b & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			if (TitanVM_F617F48D.TitanVM_28DB8C88(titanVM_25A0D8C.TitanVM_6702A746(), titanVM_25A0D8C2.TitanVM_6702A746()) != 0UL)
			{
				b4 = b3;
			}
		}
		else if (num2 >> 63 != (titanVM_25A0D8C.TitanVM_6702A746() ^ titanVM_25A0D8C2.TitanVM_6702A746()) >> 63)
		{
			b4 = b3;
		}
		b = ((b & ~b3) | b4);
		TitanVM_54A70E05.TitanVM_80151D2((ulong)titanVM_25A0D8C.TitanVM_1D7DBE68(), titanVM_25A0D8C2.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), titanVM_25A0D8C3.TitanVM_6702A746(), ref b, b2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b);
		A_2 = (TitanVM_887DE97C)0;
	}
}
