﻿using System;
using System.Reflection;

// Token: 0x0200006D RID: 109
internal class TitanVM_ECF5A04 : TitanVM_22F736AB
{
	// Token: 0x06000157 RID: 343 RVA: 0x00002797 File Offset: 0x00000997
	public TitanVM_ECF5A04(object A_1, FieldInfo A_2)
	{
		this.TitanVM_65381D93 = A_1;
		this.TitanVM_9F6C05D6 = A_2;
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00009180 File Offset: 0x00007380
	public TitanVM_25A0D8C3 TitanVM_A47D84F5(TitanVM_B53A6BB3 A_1, TitanVM_D977DC0E A_2)
	{
		object obj = this.TitanVM_65381D93;
		if (this.TitanVM_9F6C05D6.DeclaringType.IsValueType && this.TitanVM_65381D93 is TitanVM_22F736AB)
		{
			obj = ((TitanVM_22F736AB)this.TitanVM_65381D93).TitanVM_A47D84F5(A_1, (TitanVM_D977DC0E)4).TitanVM_496B397D(this.TitanVM_9F6C05D6.DeclaringType);
		}
		return TitanVM_25A0D8C3.TitanVM_913FE744(this.TitanVM_9F6C05D6.GetValue(obj), this.TitanVM_9F6C05D6.FieldType);
	}

	// Token: 0x06000159 RID: 345 RVA: 0x000091F8 File Offset: 0x000073F8
	public unsafe void TitanVM_95B551D0(TitanVM_B53A6BB3 A_1, TitanVM_25A0D8C3 A_2, TitanVM_D977DC0E A_3)
	{
		if (this.TitanVM_9F6C05D6.DeclaringType.IsValueType && this.TitanVM_65381D93 is TitanVM_22F736AB)
		{
			TypedReference obj;
			((TitanVM_22F736AB)this.TitanVM_65381D93).TitanVM_DAE9EB82(A_1, TitanVM_505B4619.TitanVM_877078A4((void*)(&obj)), this.TitanVM_9F6C05D6.DeclaringType);
			this.TitanVM_9F6C05D6.SetValueDirect(obj, A_2.TitanVM_496B397D(this.TitanVM_9F6C05D6.FieldType));
			return;
		}
		this.TitanVM_9F6C05D6.SetValue(this.TitanVM_65381D93, A_2.TitanVM_496B397D(this.TitanVM_9F6C05D6.FieldType));
	}

	// Token: 0x0600015A RID: 346 RVA: 0x000027AD File Offset: 0x000009AD
	public TitanVM_22F736AB TitanVM_128CFAEF(uint A_1)
	{
		return this;
	}

	// Token: 0x0600015B RID: 347 RVA: 0x000027AD File Offset: 0x000009AD
	public TitanVM_22F736AB TitanVM_128CFAEF(ulong A_1)
	{
		return this;
	}

	// Token: 0x0600015C RID: 348 RVA: 0x000027B0 File Offset: 0x000009B0
	public void TitanVM_DAE9EB82(TitanVM_B53A6BB3 A_1, TitanVM_505B4619 A_2, Type A_3)
	{
		TitanVM_934F86EE.TitanVM_F1DB5979(A_1, this.TitanVM_65381D93, this.TitanVM_9F6C05D6, A_2);
	}

	// Token: 0x0400006C RID: 108
	private object TitanVM_65381D93;

	// Token: 0x0400006D RID: 109
	private FieldInfo TitanVM_9F6C05D6;
}
