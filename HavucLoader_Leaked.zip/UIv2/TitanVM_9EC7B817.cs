﻿using System;
using System.Runtime.Serialization;

// Token: 0x0200001D RID: 29
internal class TitanVM_9EC7B817 : TitanVM_BF67496D
{
	// Token: 0x06000060 RID: 96 RVA: 0x0000254D File Offset: 0x0000074D
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_61A90F04;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00004C74 File Offset: 0x00002E74
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		Type type = (Type)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68());
		if (titanVM_25A0D8C2.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			TitanVM_22F736AB titanVM_22F736AB = (TitanVM_22F736AB)titanVM_25A0D8C2.TitanVM_AE0B16C2();
			TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
			if (type.IsValueType)
			{
				object obj = null;
				if (Nullable.GetUnderlyingType(type) == null)
				{
					obj = FormatterServices.GetUninitializedObject(type);
				}
				titanVM_25A0D8C3.TitanVM_B7026739(TitanVM_B1328321.TitanVM_4F96868F(obj, type));
			}
			else
			{
				titanVM_25A0D8C3.TitanVM_B7026739(null);
			}
			titanVM_22F736AB.TitanVM_95B551D0(A_1, titanVM_25A0D8C3, (TitanVM_D977DC0E)4);
			A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
			A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
			A_2 = (TitanVM_887DE97C)0;
			return;
		}
		throw new NotSupportedException();
	}
}
