﻿using System;

// Token: 0x0200006A RID: 106
internal class TitanVM_C0761EDC : TitanVM_300B3806
{
	// Token: 0x0600014B RID: 331 RVA: 0x00002764 File Offset: 0x00000964
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_E0C259EC;
	}

	// Token: 0x0600014C RID: 332 RVA: 0x00009000 File Offset: 0x00007200
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		ulong num2 = (ulong)A_1.TitanVM_3BCABD76();
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 8;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 16;
		num2 |= (ulong)A_1.TitanVM_3BCABD76() << 24;
		ulong num3 = ((num2 & (ulong)int.MinValue) != 0UL) ? 18446744069414584320UL : 0UL;
		TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
		uint num4 = num;
		TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C.TitanVM_DC0D55ED(num3 | num2);
		titanVM_A80DA.TitanVM_59168392(num4, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
