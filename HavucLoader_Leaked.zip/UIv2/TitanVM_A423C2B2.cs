﻿using System;

// Token: 0x02000060 RID: 96
internal class TitanVM_A423C2B2 : TitanVM_300B3806
{
	// Token: 0x0600012E RID: 302 RVA: 0x00002725 File Offset: 0x00000925
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_A080DBFA;
	}

	// Token: 0x0600012F RID: 303 RVA: 0x00008AB8 File Offset: 0x00006CB8
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		num -= 2U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		if (titanVM_25A0D8C2.TitanVM_6702A746() == 0UL)
		{
			A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_25A0D8C.TitanVM_6702A746());
		}
		A_2 = (TitanVM_887DE97C)0;
	}
}
