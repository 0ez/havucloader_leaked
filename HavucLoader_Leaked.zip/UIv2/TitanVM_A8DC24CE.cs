﻿using System;

// Token: 0x0200004C RID: 76
internal class TitanVM_A8DC24CE : TitanVM_300B3806
{
	// Token: 0x060000F2 RID: 242 RVA: 0x00002699 File Offset: 0x00000899
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_61D12C8C;
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00007CCC File Offset: 0x00005ECC
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 1U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		byte b = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_25A0D8C3 titanVM_25A0D8C3 = default(TitanVM_25A0D8C3);
		if (((int)b & TitanVM_413328F0.TitanVM_E316D143) != 0)
		{
			titanVM_25A0D8C3.TitanVM_6DD70EA7(titanVM_25A0D8C.TitanVM_1D7DBE68() % titanVM_25A0D8C2.TitanVM_1D7DBE68());
		}
		else
		{
			titanVM_25A0D8C3.TitanVM_6DD70EA7(titanVM_25A0D8C.TitanVM_1D7DBE68() % titanVM_25A0D8C2.TitanVM_1D7DBE68());
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C3);
		byte b2 = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_E316D143);
		TitanVM_54A70E05.TitanVM_80151D2(titanVM_25A0D8C.TitanVM_1D7DBE68(), titanVM_25A0D8C2.TitanVM_1D7DBE68(), titanVM_25A0D8C3.TitanVM_1D7DBE68(), titanVM_25A0D8C3.TitanVM_1D7DBE68(), ref b, b2);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b);
		A_2 = (TitanVM_887DE97C)0;
	}
}
