﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	static <Module>()
	{
		04D3Y5-SICMP6-SC4NPK-BHYNMO-BIN3HM-95EGW9.04D3Y5-SICMP6-SC4NPK-BHYNMO-BIN3HM-95EGW9();
	}
}
