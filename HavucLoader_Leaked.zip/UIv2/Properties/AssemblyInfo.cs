﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: InternalsVisibleTo("YullyVM.Runtime")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("UIv2")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("UIv2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
