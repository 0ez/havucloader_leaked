﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace UIv2.Properties
{
	// Token: 0x02000010 RID: 16
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	internal class Resources
	{
		// Token: 0x0600002B RID: 43 RVA: 0x000023D6 File Offset: 0x000005D6
		internal Resources()
		{
			TitanVM.TitanVM(40, new object[]
			{
				this
			});
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600002C RID: 44 RVA: 0x000023EA File Offset: 0x000005EA
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				return (ResourceManager)TitanVM.TitanVM(41, null);
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600002D RID: 45 RVA: 0x000023F9 File Offset: 0x000005F9
		// (set) Token: 0x0600002E RID: 46 RVA: 0x00002408 File Offset: 0x00000608
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return (CultureInfo)TitanVM.TitanVM(42, null);
			}
			set
			{
				TitanVM.TitanVM(43, new object[]
				{
					value
				});
			}
		}

		// Token: 0x0400005F RID: 95
		private static ResourceManager resourceMan;

		// Token: 0x04000060 RID: 96
		private static CultureInfo resourceCulture;
	}
}
