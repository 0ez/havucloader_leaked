﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace UIv2.Properties
{
	// Token: 0x02000011 RID: 17
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.1.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x06000030 RID: 48 RVA: 0x0000242B File Offset: 0x0000062B
		public Settings()
		{
			TitanVM.TitanVM(45, new object[]
			{
				this
			});
		}

		// Token: 0x06000031 RID: 49 RVA: 0x0000243F File Offset: 0x0000063F
		// Note: this type is marked as 'beforefieldinit'.
		static Settings()
		{
			TitanVM.TitanVM(46, null);
		}

		// Token: 0x04000061 RID: 97
		private static Settings defaultInstance;
	}
}
