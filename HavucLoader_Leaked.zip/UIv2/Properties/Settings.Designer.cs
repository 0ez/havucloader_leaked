﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace UIv2.Properties
{
	// Token: 0x02000011 RID: 17
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.1.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600002F RID: 47 RVA: 0x0000241C File Offset: 0x0000061C
		public static Settings Default
		{
			get
			{
				return (Settings)TitanVM.TitanVM(44, null);
			}
		}
	}
}
