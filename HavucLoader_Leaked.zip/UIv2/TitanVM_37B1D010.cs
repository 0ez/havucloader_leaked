﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000098 RID: 152
internal class TitanVM_37B1D010
{
	// Token: 0x06000202 RID: 514 RVA: 0x0000C7A4 File Offset: 0x0000A9A4
	internal unsafe static TitanVM_C6450551 TitanVM_3AECE42F(Module A_0)
	{
		if (!TitanVM_57B74FAC.TitanVM_F19591BE)
		{
			throw new PlatformNotSupportedException();
		}
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(A_0));
		string fullyQualifiedName = A_0.FullyQualifiedName;
		if (fullyQualifiedName.Length > 0 && fullyQualifiedName[0] == '<')
		{
			return new TitanVM_C6450551(A_0, TitanVM_37B1D010.TitanVM_72FBB039(ptr));
		}
		return new TitanVM_C6450551(A_0, TitanVM_37B1D010.TitanVM_E5F843C2(ptr));
	}

	// Token: 0x06000203 RID: 515 RVA: 0x0000C804 File Offset: 0x0000AA04
	private unsafe static void* TitanVM_E5F843C2(byte* A_0)
	{
		byte* ptr = A_0 + 60;
		ptr = A_0 + *(uint*)ptr;
		ptr += 6;
		ushort num = *(ushort*)ptr;
		ptr += 14;
		ushort num2 = *(ushort*)ptr;
		ptr = ptr + 4 + num2;
		byte* ptr2 = A_0 + *(uint*)(ptr - 16);
		byte* ptr3 = A_0 + *(uint*)(ptr2 + 8);
		ptr3 += 12;
		ptr3 += *(uint*)ptr3;
		ptr3 = (ptr3 + 7L & -4L);
		ptr3 += 2;
		ushort num3 = (ushort)(*ptr3);
		ptr3 += 2;
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < (int)num3; i++)
		{
			uint num4 = *(uint*)ptr3;
			uint num5 = *(uint*)(ptr3 + 4);
			ptr3 += 8;
			stringBuilder.Length = 0;
			for (int j = 0; j < 8; j++)
			{
				stringBuilder.Append((char)(*(ptr3++)));
				if (*ptr3 == 0)
				{
					ptr3 += 3;
					break;
				}
				stringBuilder.Append((char)(*(ptr3++)));
				if (*ptr3 == 0)
				{
					ptr3 += 2;
					break;
				}
				stringBuilder.Append((char)(*(ptr3++)));
				if (*ptr3 == 0)
				{
					ptr3++;
					break;
				}
				stringBuilder.Append((char)(*(ptr3++)));
				if (*ptr3 == 0)
				{
					break;
				}
			}
			if (stringBuilder.ToString() == "#Yully")
			{
				return TitanVM_37B1D010.TitanVM_4E43FAD3((void*)(A_0 + *(uint*)(ptr2 + 8) + num4), num5);
			}
		}
		return null;
	}

	// Token: 0x06000204 RID: 516 RVA: 0x0000C92C File Offset: 0x0000AB2C
	private unsafe static void* TitanVM_72FBB039(byte* A_0)
	{
		byte* ptr = A_0 + 60;
		ptr = A_0 + *(uint*)ptr;
		ptr += 6;
		ushort num = *(ushort*)ptr;
		ptr += 14;
		ushort num2 = *(ushort*)ptr;
		ptr = ptr + 4 + num2;
		uint num3 = *(uint*)(ptr - 16);
		uint[] array = new uint[(int)num];
		uint[] array2 = new uint[(int)num];
		uint[] array3 = new uint[(int)num];
		for (int i = 0; i < (int)num; i++)
		{
			array[i] = *(uint*)(ptr + 12);
			array2[i] = *(uint*)(ptr + 8);
			array3[i] = *(uint*)(ptr + 20);
			ptr += 40;
		}
		for (int j = 0; j < (int)num; j++)
		{
			if (array[j] <= num3 && num3 < array[j] + array2[j])
			{
				num3 = num3 - array[j] + array3[j];
				break;
			}
		}
		uint num4 = *(uint*)(A_0 + num3 + 8);
		for (int k = 0; k < (int)num; k++)
		{
			if (array[k] <= num4 && num4 < array[k] + array2[k])
			{
				num4 = num4 - array[k] + array3[k];
				break;
			}
		}
		byte* ptr2 = A_0 + num4;
		ptr2 += 12;
		ptr2 += *(uint*)ptr2;
		ptr2 = (ptr2 + 7L & -4L);
		ptr2 += 2;
		ushort num5 = (ushort)(*ptr2);
		ptr2 += 2;
		StringBuilder stringBuilder = new StringBuilder();
		for (int l = 0; l < (int)num5; l++)
		{
			uint num6 = *(uint*)ptr2;
			uint num7 = *(uint*)(ptr2 + 4);
			stringBuilder.Length = 0;
			ptr2 += 8;
			for (int m = 0; m < 8; m++)
			{
				stringBuilder.Append((char)(*(ptr2++)));
				if (*ptr2 == 0)
				{
					ptr2 += 3;
					break;
				}
				stringBuilder.Append((char)(*(ptr2++)));
				if (*ptr2 == 0)
				{
					ptr2 += 2;
					break;
				}
				stringBuilder.Append((char)(*(ptr2++)));
				if (*ptr2 == 0)
				{
					ptr2++;
					break;
				}
				stringBuilder.Append((char)(*(ptr2++)));
				if (*ptr2 == 0)
				{
					break;
				}
			}
			if (stringBuilder.ToString() == "#Yully")
			{
				return TitanVM_37B1D010.TitanVM_4E43FAD3((void*)(A_0 + num4 + num6), num7);
			}
		}
		return null;
	}

	// Token: 0x06000205 RID: 517
	[DllImport("kernel32.dll", EntryPoint = "CopyMemory")]
	private unsafe static extern void TitanVM_90FE9C44(void*, void*, uint);

	// Token: 0x06000206 RID: 518 RVA: 0x00002BB8 File Offset: 0x00000DB8
	private unsafe static void* TitanVM_4E43FAD3(void* A_0, uint A_1)
	{
		void* ptr = (void*)Marshal.AllocHGlobal((int)A_1);
		TitanVM_37B1D010.TitanVM_90FE9C44(ptr, A_0, A_1);
		return ptr;
	}
}
