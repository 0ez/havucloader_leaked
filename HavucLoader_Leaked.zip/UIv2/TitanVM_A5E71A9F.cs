﻿using System;
using System.Reflection;
using System.Reflection.Emit;

// Token: 0x02000025 RID: 37
internal class TitanVM_A5E71A9F : TitanVM_BF67496D
{
	// Token: 0x06000078 RID: 120 RVA: 0x0000258A File Offset: 0x0000078A
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_461EBDF5;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x000054D0 File Offset: 0x000036D0
	private static object TitanVM_574DA772(TitanVM_B53A6BB3 A_0, Type A_1, ref uint A_2)
	{
		TitanVM_2F04A360 titanVM_A80DA = A_0.TitanVM_A80DA418;
		uint num = A_2;
		A_2 = num - 1U;
		TitanVM_25A0D8C3 titanVM_25A0D8C = titanVM_A80DA.TitanVM_6D237F3F(num);
		if (Type.GetTypeCode(A_1) == TypeCode.String && titanVM_25A0D8C.TitanVM_AE0B16C2() == null)
		{
			return A_0.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_EB79B80F(titanVM_25A0D8C.TitanVM_1D7DBE68());
		}
		return titanVM_25A0D8C.TitanVM_496B397D(A_1);
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00005528 File Offset: 0x00003728
	private static TitanVM_22F736AB TitanVM_F639E029(TitanVM_B53A6BB3 A_0, Type A_1, ref uint A_2)
	{
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_0.TitanVM_A80DA418.TitanVM_6D237F3F(A_2);
		if (!A_1.IsByRef)
		{
			if (Type.GetTypeCode(A_1) == TypeCode.String && titanVM_25A0D8C.TitanVM_AE0B16C2() == null)
			{
				titanVM_25A0D8C.TitanVM_B7026739(A_0.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_EB79B80F(titanVM_25A0D8C.TitanVM_1D7DBE68()));
				A_0.TitanVM_A80DA418.TitanVM_59168392(A_2, titanVM_25A0D8C);
			}
			uint num = A_2;
			A_2 = num - 1U;
			return new TitanVM_8690B415(num);
		}
		A_2 -= 1U;
		A_1 = A_1.GetElementType();
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is Pointer)
		{
			return new TitanVM_4C81986E(Pointer.Unbox(titanVM_25A0D8C.TitanVM_AE0B16C2()));
		}
		if (titanVM_25A0D8C.TitanVM_AE0B16C2() is TitanVM_22F736AB)
		{
			return (TitanVM_22F736AB)titanVM_25A0D8C.TitanVM_AE0B16C2();
		}
		return new TitanVM_4C81986E(titanVM_25A0D8C.TitanVM_6702A746());
	}

	// Token: 0x0600007B RID: 123 RVA: 0x000055F0 File Offset: 0x000037F0
	private static bool TitanVM_B0B0AB74(TitanVM_B53A6BB3 A_0, uint A_1, MethodBase A_2, bool A_3)
	{
		if (!A_3 && !A_2.IsStatic && A_2.DeclaringType.IsValueType)
		{
			return true;
		}
		ParameterInfo[] parameters = A_2.GetParameters();
		for (int i = 0; i < parameters.Length; i++)
		{
			if (parameters[i].ParameterType.IsByRef)
			{
				return true;
			}
		}
		return A_2 is MethodInfo && ((MethodInfo)A_2).ReturnType.IsByRef;
	}

	// Token: 0x0600007C RID: 124 RVA: 0x0000565C File Offset: 0x0000385C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		uint num2 = titanVM_25A0D8C.TitanVM_1D7DBE68() & 1073741823U;
		byte b = (byte)(titanVM_25A0D8C.TitanVM_1D7DBE68() >> 30);
		MethodBase methodBase = (MethodBase)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(num2);
		bool flag = (int)b == TitanVM_413328F0.TitanVM_ED4CF552;
		if (!flag)
		{
			flag = TitanVM_A5E71A9F.TitanVM_B0B0AB74(A_1, num, methodBase, (int)b == TitanVM_413328F0.TitanVM_3A2307FF);
		}
		if (flag)
		{
			this.TitanVM_56EF08C6(A_1, methodBase, b, ref num, out A_2);
			return;
		}
		this.TitanVM_580BE043(A_1, methodBase, b, ref num, out A_2);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00005704 File Offset: 0x00003904
	private void TitanVM_580BE043(TitanVM_B53A6BB3 A_1, MethodBase A_2, byte A_3, ref uint A_4, out TitanVM_887DE97C A_5)
	{
		uint num = A_4;
		ParameterInfo[] parameters = A_2.GetParameters();
		object obj = null;
		object[] array = new object[parameters.Length];
		if ((int)A_3 == TitanVM_413328F0.TitanVM_8806C385 && A_2.IsVirtual)
		{
			int num2 = A_2.IsStatic ? 0 : 1;
			array = new object[parameters.Length + num2];
			for (int i = parameters.Length - 1; i >= 0; i--)
			{
				array[i + num2] = TitanVM_A5E71A9F.TitanVM_574DA772(A_1, parameters[i].ParameterType, ref A_4);
			}
			if (!A_2.IsStatic)
			{
				array[0] = TitanVM_A5E71A9F.TitanVM_574DA772(A_1, A_2.DeclaringType, ref A_4);
			}
			A_2 = TitanVM_EDB56334.TitanVM_443FB503(A_2);
		}
		else
		{
			array = new object[parameters.Length];
			for (int j = parameters.Length - 1; j >= 0; j--)
			{
				array[j] = TitanVM_A5E71A9F.TitanVM_574DA772(A_1, parameters[j].ParameterType, ref A_4);
			}
			if (!A_2.IsStatic && (int)A_3 != TitanVM_413328F0.TitanVM_3A2307FF)
			{
				obj = TitanVM_A5E71A9F.TitanVM_574DA772(A_1, A_2.DeclaringType, ref A_4);
				if (obj != null && !A_2.DeclaringType.IsInstanceOfType(obj))
				{
					this.TitanVM_56EF08C6(A_1, A_2, A_3, ref num, out A_5);
					return;
				}
			}
		}
		object obj2;
		if ((int)A_3 == TitanVM_413328F0.TitanVM_3A2307FF)
		{
			try
			{
				obj2 = ((ConstructorInfo)A_2).Invoke(array);
				goto IL_1B9;
			}
			catch (TargetInvocationException ex)
			{
				TitanVM_EDC6C255.TitanVM_7F506462(ex.InnerException, null);
				throw;
			}
		}
		if (!A_2.IsStatic && obj == null)
		{
			throw new NullReferenceException();
		}
		Type type;
		if (obj != null && (type = obj.GetType()).IsArray && A_2.Name == "SetValue")
		{
			Type type2;
			if (array[0] == null)
			{
				type2 = type.GetElementType();
			}
			else
			{
				type2 = array[0].GetType();
			}
			TitanVM_EC931000.TitanVM_95B551D0((Array)obj, (int)array[1], array[0], type2, type.GetElementType());
			obj2 = null;
		}
		else
		{
			try
			{
				obj2 = A_2.Invoke(obj, array);
			}
			catch (TargetInvocationException ex2)
			{
				TitanVM_5CFE68E1.TitanVM_E7386C0(A_1, ex2.InnerException);
				throw;
			}
		}
		IL_1B9:
		if (A_2 is MethodInfo && ((MethodInfo)A_2).ReturnType != typeof(void))
		{
			TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
			uint num3 = A_4 + 1U;
			A_4 = num3;
			titanVM_A80DA.TitanVM_59168392(num3, TitanVM_25A0D8C3.TitanVM_913FE744(obj2, ((MethodInfo)A_2).ReturnType));
		}
		else if ((int)A_3 == TitanVM_413328F0.TitanVM_3A2307FF)
		{
			TitanVM_2F04A360 titanVM_A80DA2 = A_1.TitanVM_A80DA418;
			uint num3 = A_4 + 1U;
			A_4 = num3;
			titanVM_A80DA2.TitanVM_59168392(num3, TitanVM_25A0D8C3.TitanVM_913FE744(obj2, A_2.DeclaringType));
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(A_4);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(A_4);
		A_5 = (TitanVM_887DE97C)0;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x0000598C File Offset: 0x00003B8C
	private void TitanVM_56EF08C6(TitanVM_B53A6BB3 A_1, MethodBase A_2, byte A_3, ref uint A_4, out TitanVM_887DE97C A_5)
	{
		ParameterInfo[] parameters = A_2.GetParameters();
		int num = parameters.Length;
		if (!A_2.IsStatic && (int)A_3 != TitanVM_413328F0.TitanVM_3A2307FF)
		{
			num++;
		}
		Type type = null;
		if ((int)A_3 == TitanVM_413328F0.TitanVM_ED4CF552)
		{
			TitanVM_C6450551 titanVM_C = A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D();
			TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
			uint num2 = A_4;
			A_4 = num2 - 1U;
			type = (Type)titanVM_C.TitanVM_20E5DB70(titanVM_A80DA.TitanVM_6D237F3F(num2).TitanVM_1D7DBE68());
		}
		if (!A_2.IsStatic)
		{
			int titanVM_3A2307FF = TitanVM_413328F0.TitanVM_3A2307FF;
		}
		TitanVM_22F736AB[] array = new TitanVM_22F736AB[num];
		Type[] array2 = new Type[num];
		for (int i = num - 1; i >= 0; i--)
		{
			Type type2;
			if (!A_2.IsStatic && (int)A_3 != TitanVM_413328F0.TitanVM_3A2307FF)
			{
				if (i == 0)
				{
					if (!A_2.IsStatic)
					{
						TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(A_4);
						if (titanVM_25A0D8C.TitanVM_AE0B16C2() is ValueType && !A_2.DeclaringType.IsValueType)
						{
							type = titanVM_25A0D8C.TitanVM_AE0B16C2().GetType();
						}
					}
					if (type != null)
					{
						type2 = type.MakeByRefType();
					}
					else if (A_2.DeclaringType.IsValueType)
					{
						type2 = A_2.DeclaringType.MakeByRefType();
					}
					else
					{
						type2 = A_2.DeclaringType;
					}
				}
				else
				{
					type2 = parameters[i - 1].ParameterType;
				}
			}
			else
			{
				type2 = parameters[i].ParameterType;
			}
			array[i] = TitanVM_A5E71A9F.TitanVM_F639E029(A_1, type2, ref A_4);
			if (type2.IsByRef)
			{
				type2 = type2.GetElementType();
			}
			array2[i] = type2;
		}
		OpCode opCode;
		Type type3;
		if ((int)A_3 == TitanVM_413328F0.TitanVM_8806C385)
		{
			opCode = OpCodes.Call;
			type3 = ((A_2 is MethodInfo) ? ((MethodInfo)A_2).ReturnType : typeof(void));
		}
		else if ((int)A_3 == TitanVM_413328F0.TitanVM_EEAADF20 || (int)A_3 == TitanVM_413328F0.TitanVM_ED4CF552)
		{
			opCode = OpCodes.Callvirt;
			type3 = ((A_2 is MethodInfo) ? ((MethodInfo)A_2).ReturnType : typeof(void));
		}
		else
		{
			if ((int)A_3 != TitanVM_413328F0.TitanVM_3A2307FF)
			{
				throw new InvalidProgramException();
			}
			opCode = OpCodes.Newobj;
			type3 = A_2.DeclaringType;
		}
		object obj = TitanVM_EDB56334.TitanVM_C3155686(A_2, opCode, type)(A_1, array, array2);
		if (type3 != typeof(void))
		{
			TitanVM_2F04A360 titanVM_A80DA2 = A_1.TitanVM_A80DA418;
			uint num2 = A_4 + 1U;
			A_4 = num2;
			titanVM_A80DA2.TitanVM_59168392(num2, TitanVM_25A0D8C3.TitanVM_913FE744(obj, type3));
		}
		else if ((int)A_3 == TitanVM_413328F0.TitanVM_3A2307FF)
		{
			TitanVM_2F04A360 titanVM_A80DA3 = A_1.TitanVM_A80DA418;
			uint num2 = A_4 + 1U;
			A_4 = num2;
			titanVM_A80DA3.TitanVM_59168392(num2, TitanVM_25A0D8C3.TitanVM_913FE744(obj, type3));
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(A_4);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(A_4);
		A_5 = (TitanVM_887DE97C)0;
	}
}
