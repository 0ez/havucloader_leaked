﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

// Token: 0x02000087 RID: 135
internal static class TitanVM_934F86EE
{
	// Token: 0x060001C3 RID: 451 RVA: 0x0000B248 File Offset: 0x00009448
	public unsafe static void TitanVM_9479A175(TitanVM_505B4619 A_0, Type A_1)
	{
		Type targetType = TypedReference.GetTargetType(*(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(A_0));
		KeyValuePair<Type, Type> keyValuePair = new KeyValuePair<Type, Type>(targetType, A_1);
		object obj = TitanVM_934F86EE.TitanVM_95B398F7[keyValuePair];
		if (obj == null)
		{
			Hashtable titanVM_95B398F = TitanVM_934F86EE.TitanVM_95B398F7;
			lock (titanVM_95B398F)
			{
				obj = TitanVM_934F86EE.TitanVM_95B398F7[keyValuePair];
				if (obj == null)
				{
					obj = TitanVM_934F86EE.TitanVM_A709B484(targetType, A_1);
					TitanVM_934F86EE.TitanVM_95B398F7[keyValuePair] = obj;
				}
			}
		}
		((TitanVM_934F86EE.TitanVM_37A88705)obj)(A_0);
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x0000B2E4 File Offset: 0x000094E4
	public unsafe static void TitanVM_15DC450(void* A_0, TitanVM_505B4619 A_1, Type A_2)
	{
		object obj = TitanVM_934F86EE.TitanVM_559F21EA[A_2];
		if (obj == null)
		{
			Hashtable titanVM_559F21EA = TitanVM_934F86EE.TitanVM_559F21EA;
			lock (titanVM_559F21EA)
			{
				obj = TitanVM_934F86EE.TitanVM_559F21EA[A_2];
				if (obj == null)
				{
					obj = TitanVM_934F86EE.TitanVM_36BDB613(A_2);
					TitanVM_934F86EE.TitanVM_559F21EA[A_2] = obj;
				}
			}
		}
		((TitanVM_934F86EE.TitanVM_6546CCA0)obj)(A_0, A_1);
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x00002AD6 File Offset: 0x00000CD6
	public static void TitanVM_D639CB6F(object A_0, TitanVM_505B4619 A_1)
	{
		TitanVM_934F86EE.TitanVM_D639CB6F(A_0, A_1, A_0.GetType());
		if (A_0 is TitanVM_36689CB6)
		{
			TitanVM_934F86EE.TitanVM_9479A175(A_1, ((TitanVM_36689CB6)A_0).TitanVM_FBF56C9D());
		}
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x0000B354 File Offset: 0x00009554
	public static void TitanVM_D639CB6F(object A_0, TitanVM_505B4619 A_1, Type A_2)
	{
		object obj = TitanVM_934F86EE.TitanVM_4CE0E841[A_2];
		if (obj == null)
		{
			Hashtable titanVM_4CE0E = TitanVM_934F86EE.TitanVM_4CE0E841;
			lock (titanVM_4CE0E)
			{
				obj = TitanVM_934F86EE.TitanVM_4CE0E841[A_2];
				if (obj == null)
				{
					obj = TitanVM_934F86EE.TitanVM_6277C456(A_2);
					TitanVM_934F86EE.TitanVM_4CE0E841[A_2] = obj;
				}
			}
		}
		((TitanVM_934F86EE.TitanVM_922F177F)obj)(A_0, A_1);
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x0000B3C4 File Offset: 0x000095C4
	public unsafe static void TitanVM_2438202(object A_0, TitanVM_505B4619 A_1)
	{
		Type targetType = TypedReference.GetTargetType(*(TypedReference*)TitanVM_505B4619.TitanVM_877078A4(A_1));
		object obj = TitanVM_934F86EE.TitanVM_6EBDA4AC[targetType];
		if (obj == null)
		{
			Hashtable titanVM_6EBDA4AC = TitanVM_934F86EE.TitanVM_6EBDA4AC;
			lock (titanVM_6EBDA4AC)
			{
				obj = TitanVM_934F86EE.TitanVM_6EBDA4AC[targetType];
				if (obj == null)
				{
					obj = TitanVM_934F86EE.TitanVM_21242FBD(targetType);
					TitanVM_934F86EE.TitanVM_6EBDA4AC[targetType] = obj;
				}
			}
		}
		((TitanVM_934F86EE.TitanVM_B796BED2)obj)(A_0, A_1);
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x0000B448 File Offset: 0x00009648
	public unsafe static void TitanVM_F1DB5979(TitanVM_B53A6BB3 A_0, object A_1, FieldInfo A_2, TitanVM_505B4619 A_3)
	{
		object obj = TitanVM_934F86EE.TitanVM_8078D81B[A_2];
		if (obj == null)
		{
			Hashtable titanVM_8078D81B = TitanVM_934F86EE.TitanVM_8078D81B;
			lock (titanVM_8078D81B)
			{
				obj = TitanVM_934F86EE.TitanVM_8078D81B[A_2];
				if (obj == null)
				{
					obj = TitanVM_934F86EE.TitanVM_FFBFADF8(A_2);
					TitanVM_934F86EE.TitanVM_8078D81B[A_2] = obj;
				}
			}
		}
		TypedReference typedReference;
		if (A_1 == null)
		{
			typedReference = default(TypedReference);
		}
		else if (A_1 is TitanVM_22F736AB)
		{
			((TitanVM_22F736AB)A_1).TitanVM_DAE9EB82(A_0, TitanVM_505B4619.TitanVM_877078A4((void*)(&typedReference)), A_2.DeclaringType);
		}
		else
		{
			typedReference = __makeref(A_1);
			TitanVM_934F86EE.TitanVM_9479A175(TitanVM_505B4619.TitanVM_877078A4((void*)(&typedReference)), A_1.GetType());
		}
		((TitanVM_934F86EE.TitanVM_41A05009)obj)(TitanVM_505B4619.TitanVM_877078A4((void*)(&typedReference)), A_3);
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0000B50C File Offset: 0x0000970C
	private static TitanVM_934F86EE.TitanVM_37A88705 TitanVM_A709B484(Type A_0, Type A_1)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
		{
			typeof(TitanVM_505B4619)
		}, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldarga, 0);
		ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
		ilgenerator.Emit(OpCodes.Dup);
		ilgenerator.Emit(OpCodes.Ldobj, typeof(TypedReference));
		ilgenerator.Emit(OpCodes.Refanyval, A_0);
		ilgenerator.Emit(OpCodes.Mkrefany, A_1);
		ilgenerator.Emit(OpCodes.Stobj, typeof(TypedReference));
		ilgenerator.Emit(OpCodes.Ret);
		return (TitanVM_934F86EE.TitanVM_37A88705)dynamicMethod.CreateDelegate(typeof(TitanVM_934F86EE.TitanVM_37A88705));
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0000B5D4 File Offset: 0x000097D4
	private unsafe static TitanVM_934F86EE.TitanVM_6546CCA0 TitanVM_36BDB613(Type A_0)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
		{
			typeof(void*),
			typeof(TitanVM_505B4619)
		}, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldarga, 1);
		ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
		ilgenerator.Emit(OpCodes.Ldarg_0);
		ilgenerator.Emit(OpCodes.Mkrefany, A_0);
		ilgenerator.Emit(OpCodes.Stobj, typeof(TypedReference));
		ilgenerator.Emit(OpCodes.Ret);
		return (TitanVM_934F86EE.TitanVM_6546CCA0)dynamicMethod.CreateDelegate(typeof(TitanVM_934F86EE.TitanVM_6546CCA0));
	}

	// Token: 0x060001CB RID: 459 RVA: 0x0000B688 File Offset: 0x00009888
	private static TitanVM_934F86EE.TitanVM_922F177F TitanVM_6277C456(Type A_0)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
		{
			typeof(object),
			typeof(TitanVM_505B4619)
		}, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldarga, 1);
		ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
		ilgenerator.Emit(OpCodes.Ldarg_0);
		ilgenerator.Emit(OpCodes.Unbox, A_0);
		ilgenerator.Emit(OpCodes.Mkrefany, A_0);
		ilgenerator.Emit(OpCodes.Stobj, typeof(TypedReference));
		ilgenerator.Emit(OpCodes.Ret);
		return (TitanVM_934F86EE.TitanVM_922F177F)dynamicMethod.CreateDelegate(typeof(TitanVM_934F86EE.TitanVM_922F177F));
	}

	// Token: 0x060001CC RID: 460 RVA: 0x0000B748 File Offset: 0x00009948
	private static TitanVM_934F86EE.TitanVM_B796BED2 TitanVM_21242FBD(Type A_0)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
		{
			typeof(object),
			typeof(TitanVM_505B4619)
		}, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Ldarga, 1);
		ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
		ilgenerator.Emit(OpCodes.Ldobj, typeof(TypedReference));
		ilgenerator.Emit(OpCodes.Refanyval, A_0);
		ilgenerator.Emit(OpCodes.Ldarg_0);
		ilgenerator.Emit(OpCodes.Unbox_Any, A_0);
		ilgenerator.Emit(OpCodes.Stobj, A_0);
		ilgenerator.Emit(OpCodes.Ret);
		return (TitanVM_934F86EE.TitanVM_B796BED2)dynamicMethod.CreateDelegate(typeof(TitanVM_934F86EE.TitanVM_B796BED2));
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000B814 File Offset: 0x00009A14
	private static TitanVM_934F86EE.TitanVM_41A05009 TitanVM_FFBFADF8(FieldInfo A_0)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
		{
			typeof(TitanVM_505B4619),
			typeof(TitanVM_505B4619)
		}, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		if (A_0.IsStatic)
		{
			ilgenerator.Emit(OpCodes.Ldarga, 1);
			ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
			ilgenerator.Emit(OpCodes.Ldsflda, A_0);
			ilgenerator.Emit(OpCodes.Mkrefany, A_0.FieldType);
			ilgenerator.Emit(OpCodes.Stobj, typeof(TypedReference));
			ilgenerator.Emit(OpCodes.Ret);
		}
		else
		{
			ilgenerator.Emit(OpCodes.Ldarga, 1);
			ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
			ilgenerator.Emit(OpCodes.Ldarga, 0);
			ilgenerator.Emit(OpCodes.Ldfld, TitanVM_934F86EE.TitanVM_34FAEBE);
			ilgenerator.Emit(OpCodes.Ldobj, typeof(TypedReference));
			ilgenerator.Emit(OpCodes.Refanyval, A_0.DeclaringType);
			if (!A_0.DeclaringType.IsValueType)
			{
				ilgenerator.Emit(OpCodes.Ldobj, A_0.DeclaringType);
			}
			ilgenerator.Emit(OpCodes.Ldflda, A_0);
			ilgenerator.Emit(OpCodes.Mkrefany, A_0.FieldType);
			ilgenerator.Emit(OpCodes.Stobj, typeof(TypedReference));
			ilgenerator.Emit(OpCodes.Ret);
		}
		return (TitanVM_934F86EE.TitanVM_41A05009)dynamicMethod.CreateDelegate(typeof(TitanVM_934F86EE.TitanVM_41A05009));
	}

	// Token: 0x040000A2 RID: 162
	private static Hashtable TitanVM_95B398F7 = new Hashtable();

	// Token: 0x040000A3 RID: 163
	private static Hashtable TitanVM_559F21EA = new Hashtable();

	// Token: 0x040000A4 RID: 164
	private static Hashtable TitanVM_4CE0E841 = new Hashtable();

	// Token: 0x040000A5 RID: 165
	private static Hashtable TitanVM_6EBDA4AC = new Hashtable();

	// Token: 0x040000A6 RID: 166
	private static Hashtable TitanVM_8078D81B = new Hashtable();

	// Token: 0x040000A7 RID: 167
	private static FieldInfo TitanVM_34FAEBE = typeof(TitanVM_505B4619).GetFields()[0];

	// Token: 0x02000088 RID: 136
	// (Invoke) Token: 0x060001D0 RID: 464
	private delegate void TitanVM_37A88705(TitanVM_505B4619);

	// Token: 0x02000089 RID: 137
	// (Invoke) Token: 0x060001D4 RID: 468
	private unsafe delegate void TitanVM_6546CCA0(void*, TitanVM_505B4619);

	// Token: 0x0200008A RID: 138
	// (Invoke) Token: 0x060001D8 RID: 472
	private delegate void TitanVM_922F177F(object, TitanVM_505B4619);

	// Token: 0x0200008B RID: 139
	// (Invoke) Token: 0x060001DC RID: 476
	private delegate void TitanVM_B796BED2(object, TitanVM_505B4619);

	// Token: 0x0200008C RID: 140
	// (Invoke) Token: 0x060001E0 RID: 480
	private delegate void TitanVM_41A05009(TitanVM_505B4619, TitanVM_505B4619);
}
