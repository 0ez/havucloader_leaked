﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x02000008 RID: 8
	public partial class register : Window
	{
		// Token: 0x06000012 RID: 18 RVA: 0x000021AF File Offset: 0x000003AF
		public register()
		{
			TitanVM.TitanVM(17, new object[]
			{
				this
			});
		}

		// Token: 0x06000013 RID: 19 RVA: 0x000021C3 File Offset: 0x000003C3
		public static string DYIjsUonSSKqZlzczWgxqJWqvybOOnsWGExbfhHECUxTWCTqfqEYHTxTbrNUSAzEAOJvOyXspBUwldtTFLJyJuoNgDZNuNMcuTtiSxCGsmIfYaHYXTpgRaVgAWokzjXCPSbsJlbhicfwLiOgWbPAyFluXnHVjrhiogqfYpoMRhYOUzvriioxuxejHHuwDgXRVWhERIhHMdIqHwzySpMbcJORcgyrUSiLkgSXrRAzbHKqOOCkiVEntWOlipBLkQMUVXfBDBhaPnZuZydoEoiYoUrnrHPcpPplUQvQIbGGODygWumKmmhWHOGaGSjWLeLaXOAicmGCHBjKwkqXufPcHtDgkvkQRKVKRxjiUdHaGEofEVEvBmCGoIsDktYHbQKWGzSYbidqxPwdeyCoROoFiovjeFXAfaYPUrzfcFusiliympzMRKQmBeOreJUvlClwRGjMYxmltWwWgWWPgkJukLoPChasKZhGaLHFgMNuyETFHSliMfpaTQmgsukQwTBu(string input)
		{
			return (string)TitanVM.TitanVM(18, new object[]
			{
				input
			});
		}

		// Token: 0x0400002E RID: 46
		internal Rectangle rectangle;

		// Token: 0x0400002F RID: 47
		internal Image image;

		// Token: 0x04000030 RID: 48
		internal Image image1;

		// Token: 0x04000031 RID: 49
		internal TextBox textBox;

		// Token: 0x04000032 RID: 50
		internal TextBox textBox1;

		// Token: 0x04000033 RID: 51
		internal Button button;

		// Token: 0x04000034 RID: 52
		internal Button button1;

		// Token: 0x04000035 RID: 53
		internal Button button2;

		// Token: 0x04000036 RID: 54
		private bool _contentLoaded;
	}
}
