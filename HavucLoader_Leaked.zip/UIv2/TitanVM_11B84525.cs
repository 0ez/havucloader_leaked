﻿using System;

// Token: 0x02000023 RID: 35
internal class TitanVM_11B84525 : TitanVM_BF67496D
{
	// Token: 0x06000072 RID: 114 RVA: 0x00002577 File Offset: 0x00000777
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_EBC84F2C;
	}

	// Token: 0x06000073 RID: 115 RVA: 0x000053BC File Offset: 0x000035BC
	public unsafe void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		bool flag = (titanVM_25A0D8C.TitanVM_1D7DBE68() & 2147483648U) > 0U;
		Type type = (Type)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68() & 2147483647U);
		if (flag)
		{
			TypedReference typedReference;
			TitanVM_934F86EE.TitanVM_D639CB6F(titanVM_25A0D8C2.TitanVM_AE0B16C2(), TitanVM_505B4619.TitanVM_877078A4((void*)(&typedReference)));
			new TitanVM_F124833D(typedReference);
			titanVM_25A0D8C2 = TitanVM_25A0D8C3.TitanVM_913FE744(titanVM_25A0D8C2.TitanVM_AE0B16C2(), type);
			A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
		}
		else
		{
			if (type == typeof(object) && titanVM_25A0D8C2.TitanVM_AE0B16C2() != null)
			{
				type = titanVM_25A0D8C2.TitanVM_AE0B16C2().GetType();
			}
			titanVM_25A0D8C2 = TitanVM_25A0D8C3.TitanVM_913FE744(titanVM_25A0D8C2.TitanVM_AE0B16C2(), type);
			A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
