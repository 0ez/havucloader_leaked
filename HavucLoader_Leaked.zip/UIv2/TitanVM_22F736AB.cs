﻿using System;

// Token: 0x02000074 RID: 116
internal interface TitanVM_22F736AB
{
	// Token: 0x06000165 RID: 357
	TitanVM_25A0D8C3 TitanVM_A47D84F5(TitanVM_B53A6BB3, TitanVM_D977DC0E);

	// Token: 0x06000166 RID: 358
	void TitanVM_95B551D0(TitanVM_B53A6BB3, TitanVM_25A0D8C3, TitanVM_D977DC0E);

	// Token: 0x06000167 RID: 359
	TitanVM_22F736AB TitanVM_128CFAEF(uint);

	// Token: 0x06000168 RID: 360
	TitanVM_22F736AB TitanVM_128CFAEF(ulong);

	// Token: 0x06000169 RID: 361
	void TitanVM_DAE9EB82(TitanVM_B53A6BB3, TitanVM_505B4619, Type);
}
