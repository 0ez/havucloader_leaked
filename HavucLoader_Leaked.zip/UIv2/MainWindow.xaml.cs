﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x0200000F RID: 15
	public partial class MainWindow : Window
	{
		// Token: 0x06000027 RID: 39 RVA: 0x00002375 File Offset: 0x00000575
		public MainWindow()
		{
			TitanVM.TitanVM(36, new object[]
			{
				this
			});
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00002389 File Offset: 0x00000589
		public static string CreateMD5(string input)
		{
			return (string)TitanVM.TitanVM(37, new object[]
			{
				input
			});
		}

		// Token: 0x04000056 RID: 86
		internal Rectangle rectangle;

		// Token: 0x04000057 RID: 87
		internal Image image;

		// Token: 0x04000058 RID: 88
		internal Image image1;

		// Token: 0x04000059 RID: 89
		internal TextBox textBox;

		// Token: 0x0400005A RID: 90
		internal TextBox textBox1;

		// Token: 0x0400005B RID: 91
		internal Button button;

		// Token: 0x0400005C RID: 92
		internal Button button1;

		// Token: 0x0400005D RID: 93
		internal Button button2;

		// Token: 0x0400005E RID: 94
		private bool _contentLoaded;
	}
}
