﻿using System;

// Token: 0x02000035 RID: 53
internal class TitanVM_2C070696 : TitanVM_300B3806
{
	// Token: 0x060000AC RID: 172 RVA: 0x000025F3 File Offset: 0x000007F3
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_EBC1DB4;
	}

	// Token: 0x060000AD RID: 173 RVA: 0x00006884 File Offset: 0x00004A84
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		titanVM_25A0D8C.TitanVM_9F667335((double)titanVM_25A0D8C.TitanVM_66B6EB10());
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C);
		A_2 = (TitanVM_887DE97C)0;
	}
}
