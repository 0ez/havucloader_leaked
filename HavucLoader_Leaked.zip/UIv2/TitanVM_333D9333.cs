﻿using System;

// Token: 0x02000019 RID: 25
internal class TitanVM_333D9333 : TitanVM_BF67496D
{
	// Token: 0x06000054 RID: 84 RVA: 0x00002531 File Offset: 0x00000731
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_7AFA1882;
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00004A54 File Offset: 0x00002C54
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		if (A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_1D7DBE68() != 0U)
		{
			throw new OverflowException();
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
