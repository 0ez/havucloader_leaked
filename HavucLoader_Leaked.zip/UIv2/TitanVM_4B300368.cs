﻿using System;
using System.Reflection;

// Token: 0x02000097 RID: 151
internal class TitanVM_4B300368
{
	// Token: 0x060001FF RID: 511 RVA: 0x0000C6A4 File Offset: 0x0000A8A4
	public unsafe TitanVM_4B300368(ref byte* A_1, Module A_2)
	{
		this.TitanVM_289BC709 = A_2;
		byte* ptr = A_1;
		A_1 = ptr + 1;
		this.TitanVM_F30AC35 = *ptr;
		this.TitanVM_85890271 = new int[TitanVM_54A70E05.TitanVM_76FDA7A0(ref A_1)];
		for (int i = 0; i < this.TitanVM_85890271.Length; i++)
		{
			this.TitanVM_85890271[i] = (int)TitanVM_54A70E05.TitanVM_B6BA367F(TitanVM_54A70E05.TitanVM_76FDA7A0(ref A_1));
		}
		this.TitanVM_D866191C = (int)TitanVM_54A70E05.TitanVM_B6BA367F(TitanVM_54A70E05.TitanVM_76FDA7A0(ref A_1));
	}

	// Token: 0x06000200 RID: 512 RVA: 0x0000C718 File Offset: 0x0000A918
	public Type[] TitanVM_84628FA7()
	{
		if (this.TitanVM_5B5B61CB != null)
		{
			return this.TitanVM_5B5B61CB;
		}
		Type[] array = new Type[this.TitanVM_85890271.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = this.TitanVM_289BC709.ResolveType(this.TitanVM_85890271[i]);
		}
		this.TitanVM_5B5B61CB = array;
		return array;
	}

	// Token: 0x06000201 RID: 513 RVA: 0x0000C770 File Offset: 0x0000A970
	public Type TitanVM_41FBC8DA()
	{
		Type result;
		if ((result = this.TitanVM_D5DCCCAE) == null)
		{
			result = (this.TitanVM_D5DCCCAE = this.TitanVM_289BC709.ResolveType(this.TitanVM_D866191C));
		}
		return result;
	}

	// Token: 0x04000136 RID: 310
	private Module TitanVM_289BC709;

	// Token: 0x04000137 RID: 311
	private readonly int[] TitanVM_85890271;

	// Token: 0x04000138 RID: 312
	private readonly int TitanVM_D866191C;

	// Token: 0x04000139 RID: 313
	private Type[] TitanVM_5B5B61CB;

	// Token: 0x0400013A RID: 314
	private Type TitanVM_D5DCCCAE;

	// Token: 0x0400013B RID: 315
	public byte TitanVM_F30AC35;
}
