﻿using System;

// Token: 0x02000049 RID: 73
internal class TitanVM_37DB1211 : TitanVM_300B3806
{
	// Token: 0x060000E9 RID: 233 RVA: 0x00002684 File Offset: 0x00000884
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_F76D33DC;
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00007A38 File Offset: 0x00005C38
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		ulong num2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_6702A746();
		int index = A_1.TitanVM_3AD9D897.Count - 1;
		TitanVM_E1C02F9B titanVM_E1C02F9B = A_1.TitanVM_3AD9D897[index];
		if (titanVM_E1C02F9B.TitanVM_40B7BA20 != num2)
		{
			throw new InvalidProgramException();
		}
		A_1.TitanVM_3AD9D897.RemoveAt(index);
		if ((int)titanVM_E1C02F9B.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_60E593CD)
		{
			A_1.TitanVM_A80DA418.TitanVM_59168392(num += 1U, A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61]);
			A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_BBF050CB(0);
			A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_E1C02F9B.TitanVM_40B7BA20);
		}
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
