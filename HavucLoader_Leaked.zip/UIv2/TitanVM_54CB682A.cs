﻿using System;

// Token: 0x02000039 RID: 57
internal class TitanVM_54CB682A : TitanVM_300B3806
{
	// Token: 0x060000B8 RID: 184 RVA: 0x0000260F File Offset: 0x0000080F
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_25644F27;
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x00002616 File Offset: 0x00000816
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		A_2 = (TitanVM_887DE97C)0;
	}
}
