﻿using System;

// Token: 0x02000071 RID: 113
internal class TitanVM_351C9F54
{
	// Token: 0x04000078 RID: 120
	public TitanVM_351C9F54.TitanVM_CB7D5C51 TitanVM_E59282A3;

	// Token: 0x04000079 RID: 121
	public object TitanVM_6D787A6;

	// Token: 0x0400007A RID: 122
	public TitanVM_25A0D8C3 TitanVM_B4A2FACD;

	// Token: 0x0400007B RID: 123
	public TitanVM_25A0D8C3 TitanVM_D6A85DC8;

	// Token: 0x0400007C RID: 124
	public int? TitanVM_60E16687;

	// Token: 0x0400007D RID: 125
	public int? TitanVM_F9E9F23A;

	// Token: 0x02000072 RID: 114
	public enum TitanVM_CB7D5C51
	{

	}
}
