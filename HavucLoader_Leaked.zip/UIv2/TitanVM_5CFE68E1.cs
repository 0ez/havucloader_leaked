﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000079 RID: 121
internal static class TitanVM_5CFE68E1
{
	// Token: 0x06000176 RID: 374 RVA: 0x00009508 File Offset: 0x00007708
	public static TitanVM_887DE97C TitanVM_6966EBBA(TitanVM_B53A6BB3 A_0)
	{
		TitanVM_887DE97C titanVM_887DE97C = (TitanVM_887DE97C)0;
		bool flag = true;
		do
		{
			try
			{
				titanVM_887DE97C = TitanVM_5CFE68E1.TitanVM_911CECCC(A_0);
				if (titanVM_887DE97C != (TitanVM_887DE97C)2)
				{
					if (titanVM_887DE97C == (TitanVM_887DE97C)3)
					{
						uint num = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
						TitanVM_25A0D8C3 titanVM_25A0D8C = A_0.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
						A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
						TitanVM_5CFE68E1.TitanVM_9921CBDE(A_0, titanVM_25A0D8C.TitanVM_AE0B16C2());
						return titanVM_887DE97C;
					}
				}
				else
				{
					uint num2 = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
					TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_0.TitanVM_A80DA418.TitanVM_6D237F3F(num2--);
					A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num2);
					TitanVM_5CFE68E1.TitanVM_E7386C0(A_0, titanVM_25A0D8C2.TitanVM_AE0B16C2());
				}
				flag = false;
			}
			catch (object ex)
			{
				TitanVM_5CFE68E1.TitanVM_412C41BB(A_0, ex);
				flag = false;
			}
			finally
			{
				if (flag)
				{
					TitanVM_5CFE68E1.TitanVM_10011DF2(A_0);
					titanVM_887DE97C = (TitanVM_887DE97C)1;
				}
				else if (A_0.TitanVM_2C8A1D0A.Count > 0)
				{
					do
					{
						TitanVM_5CFE68E1.TitanVM_28BD4B1F(A_0, ref titanVM_887DE97C);
					}
					while (titanVM_887DE97C == (TitanVM_887DE97C)3);
				}
			}
		}
		while (titanVM_887DE97C != (TitanVM_887DE97C)1);
		return titanVM_887DE97C;
	}

	// Token: 0x06000177 RID: 375 RVA: 0x00009630 File Offset: 0x00007830
	private static TitanVM_887DE97C TitanVM_911CECCC(TitanVM_B53A6BB3 A_0)
	{
		TitanVM_887DE97C titanVM_887DE97C;
		do
		{
			int num = (int)A_0.TitanVM_3BCABD76();
			A_0.TitanVM_3BCABD76();
			TitanVM_3E70E446.TitanVM_7FD46787(num).TitanVM_6966EBBA(A_0, out titanVM_887DE97C);
			if (A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_6702A746() == 1UL)
			{
				titanVM_887DE97C = (TitanVM_887DE97C)1;
			}
		}
		while (titanVM_887DE97C == (TitanVM_887DE97C)0);
		return titanVM_887DE97C;
	}

	// Token: 0x06000178 RID: 376 RVA: 0x00009678 File Offset: 0x00007878
	private static void TitanVM_412C41BB(TitanVM_B53A6BB3 A_0, object A_1)
	{
		TitanVM_351C9F54 titanVM_351C9F;
		if (A_0.TitanVM_2C8A1D0A.Count != 0)
		{
			titanVM_351C9F = A_0.TitanVM_2C8A1D0A[A_0.TitanVM_2C8A1D0A.Count - 1];
			if (titanVM_351C9F.TitanVM_60E16687 != null)
			{
				if (titanVM_351C9F.TitanVM_E59282A3 == (TitanVM_351C9F54.TitanVM_CB7D5C51)0)
				{
					A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_394C6FA2].TitanVM_BBF050CB(0);
					return;
				}
				if (titanVM_351C9F.TitanVM_E59282A3 == (TitanVM_351C9F54.TitanVM_CB7D5C51)1)
				{
					titanVM_351C9F.TitanVM_6D787A6 = A_1;
				}
				return;
			}
		}
		titanVM_351C9F = new TitanVM_351C9F54
		{
			TitanVM_B4A2FACD = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917],
			TitanVM_D6A85DC8 = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A],
			TitanVM_6D787A6 = A_1,
			TitanVM_E59282A3 = (TitanVM_351C9F54.TitanVM_CB7D5C51)0,
			TitanVM_60E16687 = null,
			TitanVM_F9E9F23A = null
		};
		A_0.TitanVM_2C8A1D0A.Add(titanVM_351C9F);
	}

	// Token: 0x06000179 RID: 377 RVA: 0x00002894 File Offset: 0x00000A94
	private static void TitanVM_9921CBDE(TitanVM_B53A6BB3 A_0, object A_1)
	{
		if (A_0.TitanVM_2C8A1D0A.Count > 0)
		{
			TitanVM_5CFE68E1.TitanVM_412C41BB(A_0, A_1);
			return;
		}
		TitanVM_5CFE68E1.TitanVM_E7386C0(A_0, A_1);
	}

	// Token: 0x0600017A RID: 378 RVA: 0x0000974C File Offset: 0x0000794C
	private static string TitanVM_630EC1A5(TitanVM_B53A6BB3 A_0)
	{
		uint num = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_6702A746() - A_0.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_CD47390E();
		uint num2 = A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917].TitanVM_1D7DBE68();
		StringBuilder stringBuilder = new StringBuilder();
		do
		{
			TitanVM_5CFE68E1.TitanVM_89BFE5F4 = TitanVM_5CFE68E1.TitanVM_89BFE5F4 * 1664525U + 1013904223U;
			ulong num3 = (ulong)(TitanVM_5CFE68E1.TitanVM_89BFE5F4 | 1U);
			stringBuilder.AppendFormat("|{0:x16}", (ulong)num * num3 << 32 | (num3 & 18446744073709551614UL));
			if (num2 <= 1U)
			{
				break;
			}
			num = A_0.TitanVM_A80DA418.TitanVM_6D237F3F(num2 - 1U).TitanVM_6702A746() - A_0.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_CD47390E();
			TitanVM_8690B415 titanVM_8690B = A_0.TitanVM_A80DA418.TitanVM_6D237F3F(num2).TitanVM_AE0B16C2() as TitanVM_8690B415;
			if (titanVM_8690B == null)
			{
				break;
			}
			num2 = titanVM_8690B.TitanVM_4F957670();
		}
		while (num2 > 0U);
		return stringBuilder.ToString(1, stringBuilder.Length - 1);
	}

	// Token: 0x0600017B RID: 379 RVA: 0x000028B3 File Offset: 0x00000AB3
	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void TitanVM_E7386C0(TitanVM_B53A6BB3 A_0, object A_1)
	{
		if (A_1 is Exception)
		{
			TitanVM_EDC6C255.TitanVM_7F506462((Exception)A_1, null);
		}
		throw A_1;
	}

	// Token: 0x0600017C RID: 380 RVA: 0x00009848 File Offset: 0x00007A48
	private static void TitanVM_28BD4B1F(TitanVM_B53A6BB3 A_0, ref TitanVM_887DE97C A_1)
	{
		TitanVM_351C9F54 titanVM_351C9F = A_0.TitanVM_2C8A1D0A[A_0.TitanVM_2C8A1D0A.Count - 1];
		TitanVM_351C9F54.TitanVM_CB7D5C51 titanVM_E59282A = titanVM_351C9F.TitanVM_E59282A3;
		int? titanVM_60E;
		if (titanVM_E59282A != (TitanVM_351C9F54.TitanVM_CB7D5C51)0)
		{
			if (titanVM_E59282A != (TitanVM_351C9F54.TitanVM_CB7D5C51)1)
			{
				throw new ExecutionEngineException();
			}
		}
		else
		{
			if (titanVM_351C9F.TitanVM_60E16687 != null)
			{
				if (A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_394C6FA2].TitanVM_7D2A041C() > 0)
				{
					titanVM_351C9F.TitanVM_E59282A3 = (TitanVM_351C9F54.TitanVM_CB7D5C51)1;
					titanVM_351C9F.TitanVM_F9E9F23A = titanVM_351C9F.TitanVM_60E16687;
					titanVM_351C9F.TitanVM_60E16687 = new int?(A_0.TitanVM_3AD9D897.Count);
					A_1 = (TitanVM_887DE97C)0;
					goto IL_2C8;
				}
				titanVM_351C9F.TitanVM_60E16687--;
			}
			else
			{
				titanVM_351C9F.TitanVM_60E16687 = new int?(A_0.TitanVM_3AD9D897.Count - 1);
			}
			Type type = titanVM_351C9F.TitanVM_6D787A6.GetType();
			int num;
			TitanVM_E1C02F9B titanVM_E1C02F9B;
			for (;;)
			{
				titanVM_60E = titanVM_351C9F.TitanVM_60E16687;
				num = 0;
				if (!(titanVM_60E.GetValueOrDefault() >= num & titanVM_60E != null) || titanVM_351C9F.TitanVM_F9E9F23A != null)
				{
					goto IL_260;
				}
				titanVM_E1C02F9B = A_0.TitanVM_3AD9D897[titanVM_351C9F.TitanVM_60E16687.Value];
				if ((int)titanVM_E1C02F9B.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_F38EF3A3)
				{
					break;
				}
				if ((int)titanVM_E1C02F9B.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_9F379454 && titanVM_E1C02F9B.TitanVM_E70C26FF.IsAssignableFrom(type))
				{
					goto Block_8;
				}
				titanVM_351C9F.TitanVM_60E16687--;
			}
			uint num2 = titanVM_351C9F.TitanVM_D6A85DC8.TitanVM_1D7DBE68();
			A_0.TitanVM_A80DA418.TitanVM_9441CDC9(num2 += 1U);
			TitanVM_2F04A360 titanVM_A80DA = A_0.TitanVM_A80DA418;
			uint num3 = num2;
			TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_B7026739(titanVM_351C9F.TitanVM_6D787A6);
			titanVM_A80DA.TitanVM_59168392(num3, titanVM_25A0D8C);
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_BBF050CB(0);
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num2);
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917] = titanVM_E1C02F9B.TitanVM_9E7D8852;
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_E1C02F9B.TitanVM_B7334A85);
			goto IL_260;
			Block_8:
			titanVM_351C9F.TitanVM_E59282A3 = (TitanVM_351C9F54.TitanVM_CB7D5C51)1;
			titanVM_351C9F.TitanVM_F9E9F23A = titanVM_351C9F.TitanVM_60E16687;
			titanVM_351C9F.TitanVM_60E16687 = new int?(A_0.TitanVM_3AD9D897.Count);
			goto IL_2C8;
			IL_260:
			titanVM_60E = titanVM_351C9F.TitanVM_60E16687;
			num = -1;
			if (!(titanVM_60E.GetValueOrDefault() == num & titanVM_60E != null) || titanVM_351C9F.TitanVM_F9E9F23A != null)
			{
				A_1 = (TitanVM_887DE97C)0;
				return;
			}
			A_0.TitanVM_2C8A1D0A.RemoveAt(A_0.TitanVM_2C8A1D0A.Count - 1);
			A_1 = (TitanVM_887DE97C)3;
			if (A_0.TitanVM_2C8A1D0A.Count == 0)
			{
				TitanVM_5CFE68E1.TitanVM_9921CBDE(A_0, titanVM_351C9F.TitanVM_6D787A6);
				return;
			}
			return;
		}
		IL_2C8:
		titanVM_351C9F.TitanVM_60E16687--;
		int i;
		for (i = titanVM_351C9F.TitanVM_60E16687.Value; i > titanVM_351C9F.TitanVM_F9E9F23A.Value; i--)
		{
			TitanVM_E1C02F9B titanVM_E1C02F9B2 = A_0.TitanVM_3AD9D897[i];
			A_0.TitanVM_3AD9D897.RemoveAt(i);
			if ((int)titanVM_E1C02F9B2.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_5AAF44A6 || (int)titanVM_E1C02F9B2.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_60E593CD)
			{
				TitanVM_5CFE68E1.TitanVM_6B0DE4A9(A_0, titanVM_E1C02F9B2);
				break;
			}
		}
		titanVM_351C9F.TitanVM_60E16687 = new int?(i);
		titanVM_60E = titanVM_351C9F.TitanVM_60E16687;
		int? titanVM_F9E9F23A = titanVM_351C9F.TitanVM_F9E9F23A;
		if (titanVM_60E.GetValueOrDefault() == titanVM_F9E9F23A.GetValueOrDefault() & titanVM_60E != null == (titanVM_F9E9F23A != null))
		{
			TitanVM_E1C02F9B titanVM_E1C02F9B3 = A_0.TitanVM_3AD9D897[titanVM_351C9F.TitanVM_F9E9F23A.Value];
			A_0.TitanVM_3AD9D897.RemoveAt(titanVM_351C9F.TitanVM_F9E9F23A.Value);
			uint num4 = titanVM_E1C02F9B3.TitanVM_9D218B89.TitanVM_1D7DBE68();
			titanVM_E1C02F9B3.TitanVM_9D218B89.TitanVM_6DD70EA7(num4 + 1U);
			A_0.TitanVM_A80DA418.TitanVM_9441CDC9(titanVM_E1C02F9B3.TitanVM_9D218B89.TitanVM_1D7DBE68());
			TitanVM_2F04A360 titanVM_A80DA2 = A_0.TitanVM_A80DA418;
			uint num5 = titanVM_E1C02F9B3.TitanVM_9D218B89.TitanVM_1D7DBE68();
			TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C.TitanVM_B7026739(titanVM_351C9F.TitanVM_6D787A6);
			titanVM_A80DA2.TitanVM_59168392(num5, titanVM_25A0D8C);
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_BBF050CB(0);
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A] = titanVM_E1C02F9B3.TitanVM_9D218B89;
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917] = titanVM_E1C02F9B3.TitanVM_9E7D8852;
			A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(titanVM_E1C02F9B3.TitanVM_40B7BA20);
			A_0.TitanVM_2C8A1D0A.RemoveAt(A_0.TitanVM_2C8A1D0A.Count - 1);
		}
		A_1 = (TitanVM_887DE97C)0;
	}

	// Token: 0x0600017D RID: 381 RVA: 0x00009D04 File Offset: 0x00007F04
	private static void TitanVM_10011DF2(TitanVM_B53A6BB3 A_0)
	{
		TitanVM_25A0D8C3[] titanVM_8DBD965D = A_0.TitanVM_8DBD965D;
		int titanVM_AC1CF = TitanVM_413328F0.TitanVM_AC1CF917;
		TitanVM_25A0D8C3[] titanVM_8DBD965D2 = A_0.TitanVM_8DBD965D;
		int titanVM_D865C38A = TitanVM_413328F0.TitanVM_D865C38A;
		for (int i = A_0.TitanVM_3AD9D897.Count - 1; i >= 0; i--)
		{
			TitanVM_E1C02F9B titanVM_E1C02F9B = A_0.TitanVM_3AD9D897[i];
			if ((int)titanVM_E1C02F9B.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_5AAF44A6 || (int)titanVM_E1C02F9B.TitanVM_EC4C203E == TitanVM_413328F0.TitanVM_60E593CD)
			{
				TitanVM_5CFE68E1.TitanVM_6B0DE4A9(A_0, titanVM_E1C02F9B);
				TitanVM_5CFE68E1.TitanVM_6966EBBA(A_0);
			}
		}
		A_0.TitanVM_3AD9D897.Clear();
	}

	// Token: 0x0600017E RID: 382 RVA: 0x00009D8C File Offset: 0x00007F8C
	private static void TitanVM_6B0DE4A9(TitanVM_B53A6BB3 A_0, TitanVM_E1C02F9B A_1)
	{
		uint num = A_1.TitanVM_9D218B89.TitanVM_1D7DBE68();
		A_1.TitanVM_9D218B89.TitanVM_6DD70EA7(num + 1U);
		A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D7052A3B].TitanVM_BBF050CB(0);
		A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A] = A_1.TitanVM_9D218B89;
		A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917] = A_1.TitanVM_9E7D8852;
		A_0.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_DDFCDD61].TitanVM_DC0D55ED(A_1.TitanVM_40B7BA20);
		TitanVM_2F04A360 titanVM_A80DA = A_0.TitanVM_A80DA418;
		uint num2 = A_1.TitanVM_9D218B89.TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = default(TitanVM_25A0D8C3);
		titanVM_25A0D8C.TitanVM_DC0D55ED(1UL);
		titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C);
	}

	// Token: 0x04000088 RID: 136
	private static uint TitanVM_89BFE5F4 = (uint)Environment.TickCount;
}
