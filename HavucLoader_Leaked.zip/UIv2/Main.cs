﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace UIv2
{
	// Token: 0x02000005 RID: 5
	public class Main : Window, IComponentConnector
	{
		// Token: 0x0600000A RID: 10 RVA: 0x0000210F File Offset: 0x0000030F
		public Main()
		{
			TitanVM.TitanVM(11, new object[]
			{
				this
			});
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002123 File Offset: 0x00000323
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			TitanVM.TitanVM(12, new object[]
			{
				this
			});
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002137 File Offset: 0x00000337
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			TitanVM.TitanVM(13, new object[]
			{
				this,
				connectionId,
				target
			});
		}

		// Token: 0x04000015 RID: 21
		internal Main window;

		// Token: 0x04000016 RID: 22
		internal Rectangle rectangle;

		// Token: 0x04000017 RID: 23
		internal Image image;

		// Token: 0x04000018 RID: 24
		private bool _contentLoaded;
	}
}
