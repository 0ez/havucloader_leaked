﻿using System;
using System.Collections.Generic;

// Token: 0x02000091 RID: 145
internal static class TitanVM_100022C8
{
	// Token: 0x060001EE RID: 494 RVA: 0x0000C3F8 File Offset: 0x0000A5F8
	static TitanVM_100022C8()
	{
		foreach (Type type in typeof(TitanVM_100022C8).Assembly.GetTypes())
		{
			if (typeof(TitanVM_BF67496D).IsAssignableFrom(type) && !type.IsAbstract)
			{
				TitanVM_BF67496D titanVM_BF67496D = (TitanVM_BF67496D)Activator.CreateInstance(type);
				TitanVM_100022C8.TitanVM_77A6FF3A[titanVM_BF67496D.TitanVM_64A7C2A2()] = titanVM_BF67496D;
			}
		}
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00002AFE File Offset: 0x00000CFE
	public static TitanVM_BF67496D TitanVM_7FD46787(int A_0)
	{
		return TitanVM_100022C8.TitanVM_77A6FF3A[A_0];
	}

	// Token: 0x04000124 RID: 292
	private static readonly Dictionary<int, TitanVM_BF67496D> TitanVM_77A6FF3A = new Dictionary<int, TitanVM_BF67496D>();
}
