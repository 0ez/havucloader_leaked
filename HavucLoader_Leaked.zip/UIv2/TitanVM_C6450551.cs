﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

// Token: 0x02000092 RID: 146
internal class TitanVM_C6450551
{
	// Token: 0x060001F0 RID: 496 RVA: 0x00002B0B File Offset: 0x00000D0B
	public Module TitanVM_52F77E7C()
	{
		return this.TitanVM_570A6F5D;
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x00002B13 File Offset: 0x00000D13
	private void TitanVM_6981C7AB(Module A_1)
	{
		this.TitanVM_570A6F5D = A_1;
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x0000C470 File Offset: 0x0000A670
	public unsafe TitanVM_C6450551(Module A_1, void* A_2)
	{
		if (((TitanVM_C6450551.TitanVM_34911997*)A_2)->TitanVM_37BE6A0A != 1752394086U)
		{
			throw new InvalidProgramException();
		}
		this.TitanVM_15180F19 = new Dictionary<uint, TitanVM_C6450551.TitanVM_883C68DE>();
		this.TitanVM_5E1CADA4 = new Dictionary<uint, string>();
		this.TitanVM_66171CB3 = new Dictionary<uint, TitanVM_B6BF0AF2>();
		byte* ptr = (byte*)A_2 + sizeof(TitanVM_C6450551.TitanVM_34911997);
		int num = 0;
		while ((long)num < (long)((ulong)((TitanVM_C6450551.TitanVM_34911997*)A_2)->TitanVM_4A5451E1))
		{
			uint key = TitanVM_54A70E05.TitanVM_76FDA7A0(ref ptr);
			int titanVM_CF712BC = (int)TitanVM_54A70E05.TitanVM_B6BA367F(TitanVM_54A70E05.TitanVM_76FDA7A0(ref ptr));
			this.TitanVM_15180F19[key] = new TitanVM_C6450551.TitanVM_883C68DE
			{
				TitanVM_289BC709 = A_1,
				TitanVM_CF712BC0 = titanVM_CF712BC
			};
			num++;
		}
		int num2 = 0;
		while ((long)num2 < (long)((ulong)((TitanVM_C6450551.TitanVM_34911997*)A_2)->TitanVM_9A4FC1CC))
		{
			uint key2 = TitanVM_54A70E05.TitanVM_76FDA7A0(ref ptr);
			uint num3 = TitanVM_54A70E05.TitanVM_76FDA7A0(ref ptr);
			this.TitanVM_5E1CADA4[key2] = new string((char*)ptr, 0, (int)num3);
			ptr += num3 << 1;
			num2++;
		}
		int num4 = 0;
		while ((long)num4 < (long)((ulong)((TitanVM_C6450551.TitanVM_34911997*)A_2)->TitanVM_C69F12BB))
		{
			this.TitanVM_66171CB3[TitanVM_54A70E05.TitanVM_76FDA7A0(ref ptr)] = new TitanVM_B6BF0AF2(ref ptr, A_1);
			num4++;
		}
		this.TitanVM_9C266D15((byte*)A_2);
		this.TitanVM_6981C7AB(A_1);
		TitanVM_C6450551.TitanVM_6E85BA76[A_1] = this;
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x0000C5A0 File Offset: 0x0000A7A0
	public static TitanVM_C6450551 TitanVM_6AA5CA23(Module A_0)
	{
		Dictionary<Module, TitanVM_C6450551> titanVM_6E85BA = TitanVM_C6450551.TitanVM_6E85BA76;
		TitanVM_C6450551 result;
		lock (titanVM_6E85BA)
		{
			if (!TitanVM_C6450551.TitanVM_6E85BA76.TryGetValue(A_0, out result))
			{
				result = (TitanVM_C6450551.TitanVM_6E85BA76[A_0] = TitanVM_37B1D010.TitanVM_3AECE42F(A_0));
			}
		}
		return result;
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00002B1C File Offset: 0x00000D1C
	public unsafe byte* TitanVM_CD47390E()
	{
		return this.TitanVM_B06AA918;
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00002B24 File Offset: 0x00000D24
	public unsafe void TitanVM_9C266D15(byte* A_1)
	{
		this.TitanVM_B06AA918 = A_1;
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x00002B2D File Offset: 0x00000D2D
	public MemberInfo TitanVM_20E5DB70(uint A_1)
	{
		return this.TitanVM_15180F19[A_1].TitanVM_76F6BAA5();
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x00002B40 File Offset: 0x00000D40
	public string TitanVM_EB79B80F(uint A_1)
	{
		if (A_1 == 0U)
		{
			return null;
		}
		return this.TitanVM_5E1CADA4[A_1];
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00002B53 File Offset: 0x00000D53
	public TitanVM_B6BF0AF2 TitanVM_AA6A4622(uint A_1)
	{
		return this.TitanVM_66171CB3[A_1];
	}

	// Token: 0x04000125 RID: 293
	private Dictionary<uint, TitanVM_C6450551.TitanVM_883C68DE> TitanVM_15180F19;

	// Token: 0x04000126 RID: 294
	private Dictionary<uint, string> TitanVM_5E1CADA4;

	// Token: 0x04000127 RID: 295
	private Dictionary<uint, TitanVM_B6BF0AF2> TitanVM_66171CB3;

	// Token: 0x04000128 RID: 296
	private static Dictionary<Module, TitanVM_C6450551> TitanVM_6E85BA76 = new Dictionary<Module, TitanVM_C6450551>();

	// Token: 0x04000129 RID: 297
	[CompilerGenerated]
	private Module TitanVM_570A6F5D;

	// Token: 0x0400012A RID: 298
	[CompilerGenerated]
	private unsafe byte* TitanVM_B06AA918;

	// Token: 0x02000093 RID: 147
	private struct TitanVM_34911997
	{
		// Token: 0x0400012B RID: 299
		public uint TitanVM_37BE6A0A;

		// Token: 0x0400012C RID: 300
		public uint TitanVM_4A5451E1;

		// Token: 0x0400012D RID: 301
		public uint TitanVM_9A4FC1CC;

		// Token: 0x0400012E RID: 302
		public uint TitanVM_C69F12BB;
	}

	// Token: 0x02000094 RID: 148
	private class TitanVM_883C68DE
	{
		// Token: 0x060001FA RID: 506 RVA: 0x0000C5F8 File Offset: 0x0000A7F8
		public MemberInfo TitanVM_76F6BAA5()
		{
			MemberInfo result;
			if ((result = this.TitanVM_225CAC1F) == null)
			{
				result = (this.TitanVM_225CAC1F = this.TitanVM_289BC709.ResolveMember(this.TitanVM_CF712BC0));
			}
			return result;
		}

		// Token: 0x0400012F RID: 303
		public Module TitanVM_289BC709;

		// Token: 0x04000130 RID: 304
		public int TitanVM_CF712BC0;

		// Token: 0x04000131 RID: 305
		public MemberInfo TitanVM_225CAC1F;
	}
}
