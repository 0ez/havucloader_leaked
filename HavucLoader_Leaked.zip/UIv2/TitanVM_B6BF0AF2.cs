﻿using System;
using System.Reflection;

// Token: 0x02000095 RID: 149
internal struct TitanVM_B6BF0AF2
{
	// Token: 0x060001FC RID: 508 RVA: 0x00002B6D File Offset: 0x00000D6D
	public unsafe TitanVM_B6BF0AF2(ref byte* A_1, Module A_2)
	{
		this.TitanVM_B420EDA9 = *A_1;
		A_1 += 4;
		if (this.TitanVM_B420EDA9 != 0U)
		{
			this.TitanVM_B64D5AF4 = *A_1;
			A_1 += 4;
		}
		else
		{
			this.TitanVM_B64D5AF4 = 0U;
		}
		this.TitanVM_326DC9C3 = new TitanVM_4B300368(ref A_1, A_2);
	}

	// Token: 0x04000132 RID: 306
	public readonly uint TitanVM_B420EDA9;

	// Token: 0x04000133 RID: 307
	public readonly uint TitanVM_B64D5AF4;

	// Token: 0x04000134 RID: 308
	public readonly TitanVM_4B300368 TitanVM_326DC9C3;
}
