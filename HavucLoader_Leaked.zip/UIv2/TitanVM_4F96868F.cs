﻿using System;

// Token: 0x02000016 RID: 22
internal class TitanVM_4F96868F : TitanVM_BF67496D
{
	// Token: 0x0600004B RID: 75 RVA: 0x0000251C File Offset: 0x0000071C
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_60B21CC1;
	}

	// Token: 0x0600004C RID: 76 RVA: 0x000047BC File Offset: 0x000029BC
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		Type type = (Type)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(titanVM_25A0D8C.TitanVM_1D7DBE68());
		if (Type.GetTypeCode(type) == TypeCode.String && titanVM_25A0D8C2.TitanVM_AE0B16C2() == null)
		{
			titanVM_25A0D8C2.TitanVM_B7026739(A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_EB79B80F(titanVM_25A0D8C2.TitanVM_1D7DBE68()));
		}
		else
		{
			titanVM_25A0D8C2.TitanVM_B7026739(titanVM_25A0D8C2.TitanVM_496B397D(type));
		}
		A_1.TitanVM_A80DA418.TitanVM_59168392(num, titanVM_25A0D8C2);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
