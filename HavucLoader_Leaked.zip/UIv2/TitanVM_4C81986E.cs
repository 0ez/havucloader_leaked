﻿using System;

// Token: 0x0200006C RID: 108
internal class TitanVM_4C81986E : TitanVM_22F736AB
{
	// Token: 0x06000151 RID: 337 RVA: 0x00002772 File Offset: 0x00000972
	public unsafe TitanVM_4C81986E(void* A_1)
	{
		this.TitanVM_8DD7B4F9 = A_1;
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00002781 File Offset: 0x00000981
	public TitanVM_25A0D8C3 TitanVM_A47D84F5(TitanVM_B53A6BB3 A_1, TitanVM_D977DC0E A_2)
	{
		throw new NotSupportedException();
	}

	// Token: 0x06000153 RID: 339 RVA: 0x00002781 File Offset: 0x00000981
	public void TitanVM_95B551D0(TitanVM_B53A6BB3 A_1, TitanVM_25A0D8C3 A_2, TitanVM_D977DC0E A_3)
	{
		throw new NotSupportedException();
	}

	// Token: 0x06000154 RID: 340 RVA: 0x00002781 File Offset: 0x00000981
	public TitanVM_22F736AB TitanVM_128CFAEF(uint A_1)
	{
		throw new NotSupportedException();
	}

	// Token: 0x06000155 RID: 341 RVA: 0x00002781 File Offset: 0x00000981
	public TitanVM_22F736AB TitanVM_128CFAEF(ulong A_1)
	{
		throw new NotSupportedException();
	}

	// Token: 0x06000156 RID: 342 RVA: 0x00002788 File Offset: 0x00000988
	public void TitanVM_DAE9EB82(TitanVM_B53A6BB3 A_1, TitanVM_505B4619 A_2, Type A_3)
	{
		TitanVM_934F86EE.TitanVM_15DC450(this.TitanVM_8DD7B4F9, A_2, A_3);
	}

	// Token: 0x0400006B RID: 107
	private unsafe void* TitanVM_8DD7B4F9;
}
