﻿using System;

// Token: 0x0200004A RID: 74
internal class TitanVM_1F6AA43C : TitanVM_300B3806
{
	// Token: 0x060000EC RID: 236 RVA: 0x0000268B File Offset: 0x0000088B
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_BF329831;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x00007B30 File Offset: 0x00005D30
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		byte b = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_7D2A041C();
		TitanVM_E1C02F9B item = default(TitanVM_E1C02F9B);
		item.TitanVM_EC4C203E = b;
		if ((int)b == TitanVM_413328F0.TitanVM_9F379454)
		{
			item.TitanVM_E70C26FF = (Type)A_1.TitanVM_6AA5CA23.TitanVM_A00F2E4D().TitanVM_20E5DB70(A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_1D7DBE68());
		}
		else if ((int)b == TitanVM_413328F0.TitanVM_F38EF3A3)
		{
			item.TitanVM_B7334A85 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_6702A746();
		}
		item.TitanVM_40B7BA20 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num--).TitanVM_6702A746();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		item.TitanVM_9E7D8852 = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_AC1CF917];
		item.TitanVM_9D218B89 = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A];
		A_1.TitanVM_3AD9D897.Add(item);
		A_2 = (TitanVM_887DE97C)0;
	}
}
