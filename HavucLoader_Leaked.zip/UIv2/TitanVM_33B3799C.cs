﻿using System;

// Token: 0x0200002B RID: 43
internal class TitanVM_33B3799C : TitanVM_300B3806
{
	// Token: 0x0600008E RID: 142 RVA: 0x000025AD File Offset: 0x000007AD
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_26207566;
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00006114 File Offset: 0x00004314
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 2U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		uint num2 = titanVM_25A0D8C.TitanVM_1D7DBE68() - titanVM_25A0D8C2.TitanVM_1D7DBE68();
		byte b = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_26E47B9F | TitanVM_413328F0.TitanVM_51D19472);
		byte b2 = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C();
		TitanVM_54A70E05.TitanVM_80151D2(num2, titanVM_25A0D8C2.TitanVM_1D7DBE68(), titanVM_25A0D8C.TitanVM_1D7DBE68(), num2, ref b2, b);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB(b2);
		A_2 = (TitanVM_887DE97C)0;
	}
}
