﻿using System;
using System.Reflection;
using System.Reflection.Emit;

// Token: 0x0200007D RID: 125
internal class TitanVM_EDC6C255
{
	// Token: 0x0600019E RID: 414 RVA: 0x0000A508 File Offset: 0x00008708
	private static bool TitanVM_7B41AFB0(Type A_0)
	{
		try
		{
			MethodInfo method = A_0.GetMethod("Capture");
			MethodInfo method2 = A_0.GetMethod("Throw");
			DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
			{
				typeof(Exception),
				typeof(string),
				typeof(bool)
			});
			ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Call, method);
			ilgenerator.Emit(OpCodes.Call, method2);
			ilgenerator.Emit(OpCodes.Ret);
			TitanVM_EDC6C255.TitanVM_89151859 = (TitanVM_EDC6C255.TitanVM_AD7537F3)dynamicMethod.CreateDelegate(typeof(TitanVM_EDC6C255.TitanVM_AD7537F3));
		}
		catch
		{
			return false;
		}
		return true;
	}

	// Token: 0x0600019F RID: 415 RVA: 0x0000A5D4 File Offset: 0x000087D4
	private static bool TitanVM_D2F4FF4F(Type A_0)
	{
		try
		{
			string text = (string)typeof(Environment).InvokeMember("GetResourceString", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, null, new object[]
			{
				"Word_At"
			});
			MethodInfo method = A_0.GetMethod("InternalPreserveStackTrace", BindingFlags.Instance | BindingFlags.NonPublic);
			FieldInfo field = A_0.GetField("_remoteStackTraceString", BindingFlags.Instance | BindingFlags.NonPublic);
			MethodInfo getMethod = A_0.GetProperty("StackTrace", BindingFlags.Instance | BindingFlags.Public).GetGetMethod();
			MethodInfo method2 = typeof(string).GetMethod("Format", new Type[]
			{
				typeof(string),
				typeof(object),
				typeof(object)
			});
			DynamicMethod dynamicMethod = new DynamicMethod("", typeof(void), new Type[]
			{
				typeof(Exception),
				typeof(string),
				typeof(bool)
			}, true);
			ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
			Label label = ilgenerator.DefineLabel();
			Label label2 = ilgenerator.DefineLabel();
			Label label3 = ilgenerator.DefineLabel();
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldfld, field);
			ilgenerator.Emit(OpCodes.Brtrue, label2);
			ilgenerator.Emit(OpCodes.Callvirt, getMethod);
			ilgenerator.Emit(OpCodes.Br, label3);
			ilgenerator.MarkLabel(label2);
			ilgenerator.Emit(OpCodes.Ldfld, field);
			ilgenerator.MarkLabel(label3);
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Call, method);
			ilgenerator.Emit(OpCodes.Stfld, field);
			ilgenerator.Emit(OpCodes.Ldarg_1);
			ilgenerator.Emit(OpCodes.Brfalse, label);
			ilgenerator.Emit(OpCodes.Ldarg_2);
			ilgenerator.Emit(OpCodes.Brtrue, label);
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldstr, string.Concat(new string[]
			{
				"{1}",
				Environment.NewLine,
				"   ",
				text,
				" KoiVM [{0}]",
				Environment.NewLine
			}));
			ilgenerator.Emit(OpCodes.Ldarg_1);
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Ldfld, field);
			ilgenerator.Emit(OpCodes.Call, method2);
			ilgenerator.Emit(OpCodes.Stfld, field);
			ilgenerator.Emit(OpCodes.Throw);
			ilgenerator.MarkLabel(label);
			ilgenerator.Emit(OpCodes.Ldarg_0);
			ilgenerator.Emit(OpCodes.Throw);
			TitanVM_EDC6C255.TitanVM_89151859 = (TitanVM_EDC6C255.TitanVM_AD7537F3)dynamicMethod.CreateDelegate(typeof(TitanVM_EDC6C255.TitanVM_AD7537F3));
		}
		catch (Exception value)
		{
			Console.WriteLine(value);
			return false;
		}
		return true;
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000A8CC File Offset: 0x00008ACC
	static TitanVM_EDC6C255()
	{
		if (TitanVM_EDC6C255.TitanVM_D2F4FF4F(typeof(Exception)))
		{
			return;
		}
		Type type = Type.GetType("System.Runtime.ExceptionServices.ExceptionDispatchInfo");
		if (type != null && TitanVM_EDC6C255.TitanVM_7B41AFB0(type))
		{
			return;
		}
		TitanVM_EDC6C255.TitanVM_89151859 = null;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000A914 File Offset: 0x00008B14
	public static void TitanVM_7F506462(Exception A_0, string A_1)
	{
		if (A_1 == null)
		{
			throw A_0;
		}
		bool flag = A_0.Data.Contains(TitanVM_EDC6C255.TitanVM_FAE5A5E4);
		if (!flag)
		{
			A_0.Data[TitanVM_EDC6C255.TitanVM_FAE5A5E4] = TitanVM_EDC6C255.TitanVM_FAE5A5E4;
		}
		if (TitanVM_EDC6C255.TitanVM_89151859 != null)
		{
			TitanVM_EDC6C255.TitanVM_89151859(A_0, A_1, flag);
		}
		throw A_0;
	}

	// Token: 0x04000097 RID: 151
	private static TitanVM_EDC6C255.TitanVM_AD7537F3 TitanVM_89151859;

	// Token: 0x04000098 RID: 152
	private static readonly object TitanVM_FAE5A5E4 = new object();

	// Token: 0x0200007E RID: 126
	// (Invoke) Token: 0x060001A4 RID: 420
	private delegate void TitanVM_AD7537F3(Exception, string, bool);
}
