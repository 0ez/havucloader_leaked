﻿using System;

// Token: 0x0200002E RID: 46
internal class TitanVM_3D7ED6B5 : TitanVM_300B3806
{
	// Token: 0x06000097 RID: 151 RVA: 0x000025C2 File Offset: 0x000007C2
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_7B5D4747;
	}

	// Token: 0x06000098 RID: 152 RVA: 0x000063B8 File Offset: 0x000045B8
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num - 1U);
		TitanVM_25A0D8C3 titanVM_25A0D8C2 = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		num -= 2U;
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		double num2 = titanVM_25A0D8C.TitanVM_6BA6EFAE() - titanVM_25A0D8C2.TitanVM_6BA6EFAE();
		byte b = (byte)(TitanVM_413328F0.TitanVM_645AE929 | TitanVM_413328F0.TitanVM_52F42074 | TitanVM_413328F0.TitanVM_26E47B9F | TitanVM_413328F0.TitanVM_51D19472);
		int num3 = (int)(A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_7D2A041C() & ~(int)b);
		if (num2 == 0.0)
		{
			num3 |= TitanVM_413328F0.TitanVM_645AE929;
		}
		else if (num2 < 0.0)
		{
			num3 |= TitanVM_413328F0.TitanVM_52F42074;
		}
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_E0F3D74C].TitanVM_BBF050CB((byte)num3);
		A_2 = (TitanVM_887DE97C)0;
	}
}
