﻿using System;
using System.Collections;
using System.Reflection.Emit;

// Token: 0x02000082 RID: 130
internal class TitanVM_2A77C20C
{
	// Token: 0x060001B0 RID: 432 RVA: 0x0000A964 File Offset: 0x00008B64
	public static int TitanVM_F0095FB(Type A_0)
	{
		object obj = TitanVM_2A77C20C.TitanVM_C0815FE5[A_0];
		if (obj == null)
		{
			Hashtable titanVM_C0815FE = TitanVM_2A77C20C.TitanVM_C0815FE5;
			lock (titanVM_C0815FE)
			{
				obj = TitanVM_2A77C20C.TitanVM_C0815FE5[A_0];
				if (obj == null)
				{
					obj = TitanVM_2A77C20C.TitanVM_E0BB931E(A_0);
					TitanVM_2A77C20C.TitanVM_C0815FE5[A_0] = obj;
				}
			}
		}
		return (int)obj;
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x0000A9D4 File Offset: 0x00008BD4
	private static int TitanVM_E0BB931E(Type A_0)
	{
		DynamicMethod dynamicMethod = new DynamicMethod("", typeof(int), Type.EmptyTypes, TitanVM_425799D4.TitanVM_87E03B23, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ilgenerator.Emit(OpCodes.Sizeof, A_0);
		ilgenerator.Emit(OpCodes.Ret);
		return (int)dynamicMethod.Invoke(null, null);
	}

	// Token: 0x0400009A RID: 154
	private static Hashtable TitanVM_C0815FE5 = new Hashtable();
}
