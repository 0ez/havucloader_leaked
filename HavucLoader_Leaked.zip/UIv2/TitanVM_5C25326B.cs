﻿using System;

// Token: 0x0200004B RID: 75
internal class TitanVM_5C25326B : TitanVM_300B3806
{
	// Token: 0x060000EF RID: 239 RVA: 0x00002692 File Offset: 0x00000892
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_74F6059A;
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00007C60 File Offset: 0x00005E60
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_A80DA418.TitanVM_6D237F3F(num);
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num -= 1U);
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		TitanVM_100022C8.TitanVM_7FD46787((int)titanVM_25A0D8C.TitanVM_7D2A041C()).TitanVM_6966EBBA(A_1, out A_2);
	}
}
