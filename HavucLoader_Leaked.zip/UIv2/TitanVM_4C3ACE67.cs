﻿using System;

// Token: 0x02000067 RID: 103
internal class TitanVM_4C3ACE67 : TitanVM_300B3806
{
	// Token: 0x06000142 RID: 322 RVA: 0x0000274F File Offset: 0x0000094F
	public int TitanVM_64A7C2A2()
	{
		return TitanVM_413328F0.TitanVM_A564352A;
	}

	// Token: 0x06000143 RID: 323 RVA: 0x00008E4C File Offset: 0x0000704C
	public void TitanVM_6966EBBA(TitanVM_B53A6BB3 A_1, out TitanVM_887DE97C A_2)
	{
		uint num = A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_1D7DBE68();
		A_1.TitanVM_A80DA418.TitanVM_9441CDC9(num += 1U);
		byte b = A_1.TitanVM_3BCABD76();
		TitanVM_25A0D8C3 titanVM_25A0D8C = A_1.TitanVM_8DBD965D[(int)b];
		if ((int)b == TitanVM_413328F0.TitanVM_D865C38A || (int)b == TitanVM_413328F0.TitanVM_AC1CF917)
		{
			TitanVM_2F04A360 titanVM_A80DA = A_1.TitanVM_A80DA418;
			uint num2 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C2 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C2.TitanVM_B7026739(new TitanVM_8690B415(titanVM_25A0D8C.TitanVM_1D7DBE68()));
			titanVM_A80DA.TitanVM_59168392(num2, titanVM_25A0D8C2);
		}
		else
		{
			TitanVM_2F04A360 titanVM_A80DA2 = A_1.TitanVM_A80DA418;
			uint num3 = num;
			TitanVM_25A0D8C3 titanVM_25A0D8C2 = default(TitanVM_25A0D8C3);
			titanVM_25A0D8C2.TitanVM_6DD70EA7(titanVM_25A0D8C.TitanVM_1D7DBE68());
			titanVM_A80DA2.TitanVM_59168392(num3, titanVM_25A0D8C2);
		}
		A_1.TitanVM_8DBD965D[TitanVM_413328F0.TitanVM_D865C38A].TitanVM_6DD70EA7(num);
		A_2 = (TitanVM_887DE97C)0;
	}
}
